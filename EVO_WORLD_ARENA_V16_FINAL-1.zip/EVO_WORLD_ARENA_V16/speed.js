// EVO — vitesse : service worker, pré-chargement des pages avant le clic, mesure réelle du temps de chargement.
(function () {
  'use strict';
  var vus = {};
  function lent() {
    try { var c = navigator.connection; return !!(c && (c.saveData || /(^|-)2g$/.test(c.effectiveType || ''))); } catch (e) { return false; }
  }
  // 1) service worker (HTTPS ou localhost seulement)
  try {
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
    }
  } catch (e) {}
  // 2) pré-charger une page dès que le doigt touche le lien (le clic arrive ~100 ms plus tard)
  function pre(href) {
    if (!href || vus[href] || lent()) return; vus[href] = 1;
    try { fetch(href, { credentials: 'same-origin' }).catch(function () {}); } catch (e) {}
  }
  function lien(ev) {
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null; if (!a) return;
    var u; try { u = new URL(a.getAttribute('href'), location.href); } catch (e) { return; }
    if (u.origin !== location.origin || !/\.html$/i.test(u.pathname) || u.pathname === location.pathname || /admin/i.test(u.pathname)) return;
    pre(u.href);
  }
  document.addEventListener('touchstart', lien, { passive: true, capture: true });
  document.addEventListener('mouseover', lien, { passive: true, capture: true });
  // 3) quand le téléphone est au repos, charger en avance les pages principales (elles s'ouvriront instantanément)
  function enAvance() {
    if (lent() || document.hidden) return;
    ['index.html', 'saucial.html', 'clans.html', 'live.html', 'Top_100.html', 'profil.html', 'messages.html'].forEach(function (p) {
      if (location.pathname.slice(-p.length) !== p) pre(new URL(p, location.href).href);
    });
  }
  window.addEventListener('load', function () { (window.requestIdleCallback || function (f) { setTimeout(f, 2500); })(enAvance, { timeout: 5000 }); });
  // 4) mesure RÉELLE (visible dans ⚙️ › Vitesse de chargement)
  function mesurer() {
    try {
      var n = performance.getEntriesByType('navigation')[0]; if (!n) return;
      var fcp = 0; (performance.getEntriesByType('paint') || []).forEach(function (p) { if (p.name === 'first-contentful-paint') fcp = Math.round(p.startTime); });
      var r = { page: location.pathname.split('/').pop() || 'index.html', dcl: Math.round(n.domContentLoadedEventEnd), load: Math.round(n.loadEventEnd), fcp: fcp, cache: n.transferSize === 0, sw: !!(navigator.serviceWorker && navigator.serviceWorker.controller), t: Date.now() };
      var l = JSON.parse(localStorage.getItem('evo_vitesse') || '[]'); l.push(r); localStorage.setItem('evo_vitesse', JSON.stringify(l.slice(-12)));
    } catch (e) {}
  }
  window.addEventListener('load', function () { setTimeout(mesurer, 600); });
  window.EvoSpeed = {
    resume: function () {
      try {
        var l = JSON.parse(localStorage.getItem('evo_vitesse') || '[]'); if (!l.length) return 'Pas encore de mesure';
        var d = l[l.length - 1]; return 'Dernière page : affichage ' + d.fcp + ' ms · prête ' + d.dcl + ' ms' + (d.sw ? ' · cache actif' : '');
      } catch (e) { return ''; }
    }
  };
})();
