# EVO ARENA v14i — Application native + studio de création façon TikTok

## Ce qui est nouveau
1. **Studio de création** (bouton « + » flottant, ou « Créer » dans Social, ou « Créer un story »)
   - **Caméra** : 60 s / 15 s / Photo / Texte, plusieurs segments, minuteur 3-10 s, flash, retourner, filtres en direct, « Ajouter un son » en haut.
   - **Galerie** : Tous / Vidéos / Photos, **sélection multiple** (jusqu'à 10 clips, numérotés), bouton « Texte ».
   - **Montage** : rogner (début/fin), durée des photos, **texte déplaçable** (couleurs + fond), 8 filtres, volume son d'origine / musique, plusieurs clips mis bout à bout. Tout est « cuit » dans la vidéo finale (MP4 si le téléphone le permet).
   - **Sons** : liste avec covers, aperçu ▶, « Utiliser », recherche, **importer son audio**. 8 sons intégrés (générés dans le téléphone, libres de droits) + collection Firestore `sons`.
   - **Publier** : description + #hashtags, **couverture** (8 images à choisir ou une photo de la galerie), Publication ou **Story 24 h**, visibilité (tous / abonnés / moi), commentaires on/off, **brouillons**.
2. **Application native** : autorisations (notifications, caméra, micro) demandées au bon moment, bouton Retour, vibrations, hors-ligne, clavier, etc. (`evo-native.js`).
3. Le fil Social affiche maintenant le **son** (♫), la **couverture** de la vidéo, respecte la **visibilité** et le réglage des **commentaires**.

## À faire de ton côté
- Remplacer tout le site par ce zip, **republier `firestore.rules`** (règle `sons` ajoutée).
- Pour ajouter tes propres sons : Firestore › collection `sons` › un document par son avec `Titre`, `Artiste`, `Audio_url` (lien Appwrite du MP3), `Cover_url`, `Duree` (secondes). N'utilise que des musiques dont tu as les droits (tes morceaux Valker Boy, par exemple).
- Si l'app ne propose pas le bouton « + » sur une page : elle est chargée sur index, saucial et profil.

## Limites connues
- Le navigateur ne peut pas lister toute la galerie du téléphone : « Importer » ouvre le sélecteur Android (comme TikTok sur le web), puis tes choix s'affichent dans la grille.
- Le montage se fait en temps réel : une vidéo de 30 s prend ~30 s à préparer (garde l'écran allumé, c'est géré automatiquement).
- Les filtres ne sont pas appliqués au rendu final sur Safari/iPhone (limite du navigateur) ; ils le sont sur Chrome/Android.
