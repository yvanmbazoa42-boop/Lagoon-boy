#!/usr/bin/env bash
# Déploiement EVO WORLD ARENA V16 — à lancer sur TON ordinateur (npm i -g firebase-tools ; firebase login). Lis DEPLOY_GUIDE.md avant.
set -e
PROJECT=evo-world-arena-7319b
cd "$(dirname "$0")/functions" && npm install && npm test && cd ..
echo ">> 1/5 secret de signature des factures (≥ 32 caractères aléatoires, ne le partage JAMAIS)"
firebase functions:secrets:set INVOICE_SECRET --project $PROJECT
echo ">> 2/5 fonctions + index"
firebase deploy --only functions,firestore:indexes --project $PROJECT
echo ">> 3/5 MIGRATION des données privées (simulation d'abord). Il faut GOOGLE_APPLICATION_CREDENTIALS (compte de service, jamais dans Git)."
if [ -n "$GOOGLE_APPLICATION_CREDENTIALS" ]; then node scripts/migrate-private.js; read -p "Appliquer la migration ? (oui/non) " r; [ "$r" = "oui" ] && node scripts/migrate-private.js --apply; else echo "   GOOGLE_APPLICATION_CREDENTIALS absent : migration à faire à la main (voir DEPLOY_GUIDE.md)"; fi
echo ">> 4/5 mets maintenant en ligne le dossier du site (HTML/JS) sur ton hébergement, PUIS continue."
read -p "Site publié ? (Entrée pour continuer)" _
echo ">> 5/5 règles Firestore + Storage (en dernier)"
firebase deploy --only firestore:rules,storage --project $PROJECT
