// EVO ARENA — performance & options (chargé sur toutes les pages, sans risque : s'il échoue, le site marche comme avant)
(function () {
  'use strict';
  function ls(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  var F = { eco: 'evo_eco', flou: 'evo_flou', fond: 'evo_fond' };
  function eco() {
    if (ls(F.eco, null) !== null) return ls(F.eco, '0') === '1';
    try { return !!(navigator.connection && navigator.connection.saveData); } catch (e) { return false; } // mode économie auto si « économiseur de données » du téléphone
  }
  // 1) Pause des rafraîchissements automatiques quand l'app est en arrière-plan (économise batterie, données, quota Firebase)
  var _si = window.setInterval;
  window.setInterval = function (fn, ms) {
    var a = Array.prototype.slice.call(arguments, 2);
    if (typeof fn !== 'function') return _si.apply(window, arguments);
    return _si.apply(window, [function () {
      if (document.hidden && ls(F.fond, '0') !== '1') return;
      return fn.apply(null, arguments);
    }, ms].concat(a));
  };
  // 2) CSS d'options
  var st = document.createElement('style');
  st.textContent = 'html.evo-flou *{-webkit-backdrop-filter:none!important;backdrop-filter:none!important}' +
    'html.evo-eco video{max-height:60vh}' +
    /* Réactivité maximale sur TOUT le site : pas de flou GPU, transitions 80 ms, taps immédiats, pas d'animation d'entrée */
    '*{-webkit-backdrop-filter:none!important;backdrop-filter:none!important;scroll-behavior:auto!important}' +
    'button,a,.btn,.card,.clan-card,.post,.post-card,.nav-btn,[onclick]{touch-action:manipulation;-webkit-tap-highlight-color:transparent;transition-duration:.08s!important}' +
    '.fade-in,.fade-in-up{animation:none!important;opacity:1!important;transform:none!important}' +
    'img[loading="lazy"]{opacity:1!important;transition:none!important}' +
    '.card,.clan-card,.post,.post-card,.player-row,.match-card{contain:layout paint}' +
    'button:active:not(:disabled),.btn:active,.card:active{transition-duration:.05s!important}';
  (document.head || document.documentElement).appendChild(st);
  function appliquer() {
    var h = document.documentElement;
    h.classList.toggle('evo-flou', ls(F.flou, '0') === '1');
    h.classList.toggle('evo-eco', eco());
    traiterMedias(document);
  }
  // 3) Images en lazy, vidéos qui ne se chargent pas d'avance, vidéos hors écran mises en pause
  var io = null;
  try {
    io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (!e.isIntersecting && e.target.tagName === 'VIDEO' && !e.target.paused) { try { e.target.pause(); } catch (x) {} } });
    }, { threshold: 0.1 });
  } catch (e) {}
  function traiterMedias(root) {
    try {
      var imgs = root.querySelectorAll ? root.querySelectorAll('img') : [];
      for (var i = 0; i < imgs.length; i++) { var m = imgs[i]; if (!m.getAttribute('loading')) m.setAttribute('loading', 'lazy'); if (!m.getAttribute('decoding')) m.setAttribute('decoding', 'async'); }
      var vs = root.querySelectorAll ? root.querySelectorAll('video') : [];
      for (var j = 0; j < vs.length; j++) {
        var v = vs[j];
        if (!v.dataset.evoPerf) { v.dataset.evoPerf = '1'; if (io) io.observe(v); }
        if (eco() && !v.dataset.evoUser) { v.preload = 'none'; if (v.autoplay && !v.closest('#livePlayer,.evp')) { v.autoplay = false; v.removeAttribute('autoplay'); } }
        else if (!v.getAttribute('preload')) v.preload = 'metadata';
      }
    } catch (e) {}
  }
  document.addEventListener('DOMContentLoaded', function () {
    appliquer();
    try {
      new MutationObserver(function (ms) {
        ms.forEach(function (mu) { mu.addedNodes.forEach(function (n) { if (n.nodeType === 1) { if (n.tagName === 'IMG' || n.tagName === 'VIDEO') traiterMedias(n.parentNode || document); else traiterMedias(n); } }); });
      }).observe(document.body, { childList: true, subtree: true });
    } catch (e) {}
  });
  // 5) Précharge les autres pages pendant que le téléphone est au repos : le changement de page devient quasi instantané
  function precharger() {
    try {
      if (eco()) return;
      var c = navigator.connection; if (c && /(^|-)2g$/.test(c.effectiveType || '')) return;
      var cur = location.pathname.split('/').pop() || 'index.html';
      ['index.html', 'live.html', 'saucial.html', 'clans.html', 'profil.html', 'Top_100.html', 'messages.html'].forEach(function (p) {
        if (p === cur) return;
        var l = document.createElement('link'); l.rel = 'prefetch'; l.href = p; document.head.appendChild(l);
      });
    } catch (e) {}
  }
  (window.requestIdleCallback || function (f) { setTimeout(f, 1500); })(precharger);
  // 6) Retour visuel INSTANTANÉ au toucher (même si le réseau met 200 ms+ à répondre) : le bouton réagit dès le doigt posé
  var st2 = document.createElement('style');
  st2.textContent = '.evo-tap{transform:scale(.96)!important;filter:brightness(1.2)!important;transition:none!important}' +
    '.evo-busy{opacity:.65!important;pointer-events:none!important}';
  (document.head || document.documentElement).appendChild(st2);
  document.addEventListener('pointerdown', function (e) {
    try {
      var b = e.target && e.target.closest && e.target.closest('button,.btn,.card,a,[onclick]');
      if (!b || b.disabled) return;
      b.classList.add('evo-tap');
      var off = function () { b.classList.remove('evo-tap'); };
      b.addEventListener('pointerup', off, { once: true }); b.addEventListener('pointercancel', off, { once: true }); b.addEventListener('pointerleave', off, { once: true });
      setTimeout(off, 600);
    } catch (x) {}
  }, { passive: true, capture: true });
  // Boutons d'action (S'inscrire, Publier, Envoyer…) : grisés 0,8 s après le clic = pas de double-clic, retour immédiat
  document.addEventListener('click', function (e) {
    try {
      var b = e.target && e.target.closest && e.target.closest('button.btn-join,button.btn,button[type=submit]');
      if (!b || b.disabled || b.dataset.evoBusy) return;
      b.dataset.evoBusy = '1'; b.classList.add('evo-busy');
      setTimeout(function () { b.classList.remove('evo-busy'); delete b.dataset.evoBusy; }, 800);
    } catch (x) {}
  }, true);
  document.addEventListener('play', function (e) { if (e.target && e.target.dataset) e.target.dataset.evoUser = '1'; }, true);
  appliquer();
  // 4) Journal d'erreurs local (30 dernières) — visible/copiable dans ⚙️ → Journal d'erreurs
  function ajouter(m) {
    try {
      var l = JSON.parse(ls('evo_log', '[]')); l.push({ t: new Date().toISOString(), p: location.pathname.split('/').pop(), m: String(m).slice(0, 300) });
      localStorage.setItem('evo_log', JSON.stringify(l.slice(-30)));
    } catch (e) {}
  }
  window.addEventListener('error', function (e) { ajouter(e.message || 'erreur'); });
  window.addEventListener('unhandledrejection', function (e) { ajouter((e.reason && e.reason.message) || e.reason || 'promesse rejetée'); });
  window.evoPerf = {
    appliquer: appliquer,
    log: function () { try { return JSON.parse(ls('evo_log', '[]')); } catch (e) { return []; } },
    effacerLog: function () { try { localStorage.removeItem('evo_log'); } catch (e) {} }
  };
})();
