// EVO ARENA — onglet admin « 🌳 ARBRE » : génération selon les inscrits, avancement des vainqueurs, corrections.
// Utilise les variables de admin.html : currentTournament, currentTournamentId, allPlayers.
(function () {
  'use strict';
  let A = null;
  const $ = function (id) { return document.getElementById(id); };
  const esc = window.escapeHtml;
  const T = function () { try { return currentTournament || null; } catch (e) { return null; } };
  const TID = function () { try { return currentTournamentId || null; } catch (e) { return null; } };
  const joueurs = function () { try { return (allPlayers || []).map(function (p) { return { id: p.id, p: p.Psuedo || 'Joueur' }; }); } catch (e) { return []; } };
  const msg = function (m, t) { try { showToast(m, t || 'info'); } catch (e) { alert(m); } };

  // Applique une modification sur une copie, l'enregistre, puis seulement alors l'affiche (rien n'est perdu en cas d'erreur réseau)
  async function agir(fn, ok) {
    const B = Arbre.clone(A);
    try {
      fn(B); B.maj = new Date().toISOString();
      const txt = JSON.stringify(B);
      await EvoDB.update(COLLECTIONS.TOURNAMENTS, TID(), { Arbre: txt });
      T().Arbre = txt; A = B; fermer(); afficher();
      if (ok) msg(ok, 'success');
    } catch (e) { msg('❌ ' + (e.message || e), 'error'); }
  }
  async function generer(melange) {
    const L = joueurs();
    if (L.length < 2) return msg('⚠️ Il faut au moins 2 joueurs inscrits dans ce tournoi.', 'error');
    if (A && Arbre.stats(A).faits > 0 && !confirm('⚠️ Des résultats existent déjà. Régénérer efface tout l\'arbre. Continuer ?')) return;
    try {
      const pf = $('abPf') ? $('abPf').checked : !!(A && A.pf);
      const N = Arbre.construire(L, { melange: melange, petite: pf });
      await EvoDB.update(COLLECTIONS.TOURNAMENTS, TID(), { Arbre: JSON.stringify(N), Arbre_visible: true });
      T().Arbre = JSON.stringify(N); T().Arbre_visible = true; A = N; afficher();
      msg('✅ Arbre créé pour ' + L.length + ' joueurs (' + N.size + ' places)', 'success');
    } catch (e) { A = Arbre.lire(T()); msg('❌ ' + (e.message || e), 'error'); }
  }
  function nouveaux() { const p = Arbre.presents(A); return joueurs().filter(function (j) { return !p[j.id]; }); }
  function ajouterNouveaux() {
    const L = nouveaux(); let places = 0;
    agir(function (B) { L.forEach(function (j) { if (Arbre.ajouter(B, j.id, j.p)) places++; }); if (!places) throw new Error('Plus de place libre : régénère l\'arbre (aucun résultat à perdre) ou retire un joueur.'); }, '✅ Joueur(s) ajouté(s) à l\'arbre');
  }
  async function supprimer() {
    if (!confirm('🗑️ Supprimer l\'arbre de ce tournoi ?')) return;
    try { await EvoDB.update(COLLECTIONS.TOURNAMENTS, TID(), { Arbre: '' }); T().Arbre = ''; A = null; afficher(); } catch (e) { msg('❌ ' + e.message, 'error'); }
  }

  // ----- Feuille de match (modifier un match) -----
  function fermer() { const o = $('abSheet'); if (o) o.remove(); }
  function feuille(r, i) {
    fermer();
    const m = r < 0 ? A.pf : A.r[r][i], nom = function (id) { return id ? esc(A.noms[id] || 'Joueur') : '—'; };
    const o = document.createElement('div'); o.id = 'abSheet';
    o.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:99999;display:flex;align-items:flex-end;justify-content:center';
    const btn = 'width:100%;padding:12px;border:0;border-radius:10px;font-weight:700;cursor:pointer;margin-top:8px;';
    let h = '<div style="background:#0d0d24;border:1px solid var(--c1,#00ff88);border-radius:18px 18px 0 0;padding:18px;width:100%;max-width:480px;max-height:88vh;overflow:auto;color:#e5e7eb">'
      + '<h3 style="margin:0 0 4px;color:var(--c1,#00ff88)">' + Arbre.nomTour(A, r) + (r < 0 ? '' : ' — match ' + (i + 1)) + '</h3>'
      + '<div style="font-size:.85rem;margin-bottom:10px"><b>' + nom(m.a) + '</b> <span style="color:#64748b">VS</span> <b>' + nom(m.b) + '</b></div>';
    if (m.a && m.b && !m.bye) {
      h += '<div style="display:flex;gap:8px"><input id="abSa" type="number" min="0" placeholder="Score ' + nom(m.a) + '" value="' + (m.sa == null ? '' : m.sa) + '" style="flex:1;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;min-width:0">'
        + '<input id="abSb" type="number" min="0" placeholder="Score ' + nom(m.b) + '" value="' + (m.sb == null ? '' : m.sb) + '" style="flex:1;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;min-width:0"></div>'
        + '<button id="abWa" style="' + btn + 'background:var(--c1,#00ff88);color:#000">🏆 ' + nom(m.a) + ' gagne</button>'
        + '<button id="abWb" style="' + btn + 'background:var(--c1,#00ff88);color:#000">🏆 ' + nom(m.b) + ' gagne</button>';
    } else if (!m.bye) h += '<div style="color:#fbbf24;font-size:.8rem">⏳ En attente des vainqueurs des tours précédents.</div>';
    else h += '<div style="color:#94a3b8;font-size:.8rem">BYE : le joueur passe directement au tour suivant.</div>';
    if (m.a && m.b && !m.bye) {
      const hv = m.h ? new Date(new Date(m.h) - new Date(m.h).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
      h += '<div style="margin-top:12px;font-size:.72rem;color:#94a3b8">📅 PLANNING + MESSAGE AUX JOUEURS</div>'
        + '<input id="abH" type="datetime-local" value="' + esc(hv) + '" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;margin-top:6px">'
        + '<input id="abLien" placeholder="Lien de la salle (facultatif)" value="' + esc(typeof genererLienSalle === 'function' ? genererLienSalle() : '') + '" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;margin-top:6px">'
        + '<input id="abMdp" placeholder="Mot de passe de la salle" value="' + esc(typeof genererMotDePasse === 'function' ? genererMotDePasse() : '') + '" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;margin-top:6px">'
        + '<button id="abPlan" style="' + btn + 'background:#6366f1;color:#fff">📅 Enregistrer l\'horaire (visible par tous)</button>'
        + '<div style="display:flex;gap:6px"><button id="abWa1" style="' + btn + 'background:#25D366;color:#000">📱 ' + nom(m.a) + '</button><button id="abWa2" style="' + btn + 'background:#25D366;color:#000">📱 ' + nom(m.b) + '</button></div>';
    }
    if (m.w && !m.bye) h += '<button id="abUndo" style="' + btn + 'background:#f59e0b;color:#000">↩️ Annuler ce résultat (et les suites)</button>';
    if (r === 0 && (!m.w || m.bye)) {
      const libres = nouveaux(), cases = ['a', 'b'].map(function (k) {
        return '<select id="abRp' + k + '" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#111827;color:#fff;margin-top:6px"><option value="">Changer ' + nom(m[k]) + ' par…</option><option value="-">❌ Laisser vide (BYE)</option>'
          + libres.map(function (j) { return '<option value="' + esc(j.id) + '">' + esc(j.p) + '</option>'; }).join('') + '</select>';
      });
      h += '<div style="margin-top:12px;font-size:.72rem;color:#94a3b8">REMPLACER UN JOUEUR (joueurs inscrits pas encore placés)</div>' + cases.join('')
        + '<button id="abRp" style="' + btn + 'background:#3b82f6;color:#fff">🔁 Appliquer le remplacement</button>';
    }
    h += '<button id="abNo" style="' + btn + 'background:none;color:#94a3b8">Fermer</button></div>';
    o.innerHTML = h; document.body.appendChild(o);
    o.onclick = function (e) { if (e.target === o) fermer(); };
    const on = function (id, f) { const b = $(id); if (b) b.onclick = f; };
    const gagne = function (id) { return function () { const sa = $('abSa').value, sb = $('abSb').value; agir(function (B) { Arbre.poser(B, r, i, id, sa, sb); }, '✅ ' + (A.noms[id] || 'Joueur') + ' avance !'); }; };
    const prevenir = function (k) {
      return function () {
        const id = m[k], adv = m[k === 'a' ? 'b' : 'a'], p = (typeof allPlayers !== 'undefined' ? allPlayers : []).find(function (q) { return q.id === id; });
        const h = $('abH').value, d = h ? new Date(h) : null, lien = $('abLien').value.trim(), mdp = $('abMdp').value.trim();
        const texte = '🎮 *MATCH EVO ARENA* 🎮\n\n🏆 ' + (T().Nom || 'Tournoi') + ' — *' + Arbre.nomTour(A, r) + '*\n👥 *' + (A.noms[id] || '') + '* VS *' + (A.noms[adv] || '') + '*\n'
          + (d ? '\n📅 *' + d.toLocaleDateString('fr-FR') + '* à *' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) + '*\n' : '')
          + (lien ? '\n🔗 Salle : ' + lien : '') + (mdp ? '\n🔑 Mot de passe : ' + mdp : '') + '\n\n🤝 Soyez à l\'heure ! Le gagnant envoie une capture au CEO.';
        if (typeof envoyerWhatsApp === 'function') envoyerWhatsApp((p && (p.WhatsApp || p.Tel)) || '', texte);
      };
    };
    on('abWa1', prevenir('a')); on('abWa2', prevenir('b'));
    on('abPlan', function () { const v = $('abH').value; agir(function (B) { Arbre.planifier(B, r, i, v ? new Date(v).toISOString() : null); }, '📅 Horaire enregistré'); });
    on('abNo', fermer); on('abWa', gagne(m.a)); on('abWb', gagne(m.b));
    on('abUndo', function () { agir(function (B) { Arbre.vider(B, r, i); }, '↩️ Résultat annulé'); });
    on('abRp', function () {
      const ra = $('abRpa').value, rb = $('abRpb').value;
      if (!ra && !rb) return msg('⚠️ Choisis un remplaçant', 'error');
      agir(function (B) {
        [['a', ra], ['b', rb]].forEach(function (x) {
          if (!x[1]) return;
          const j = joueurs().find(function (q) { return q.id === x[1]; });
          Arbre.remplacer(B, i, x[0], x[1] === '-' ? null : x[1], j && j.p);
        });
      }, '✅ Joueur remplacé');
    });
  }

  function afficher() {
    const box = $('arbreAdmin'); if (!box) return;
    const t = T();
    if (!t) { box.innerHTML = '<div style="color:#555;padding:15px;text-align:center">Sélectionne un tournoi en haut de la page.</div>'; return; }
    const L = joueurs(), btn = 'padding:10px 14px;border:0;border-radius:8px;font-weight:700;cursor:pointer;font-size:.75rem;margin:3px;';
    if (!A) {
      const size = L.length >= 2 ? (function () { let s = 2; while (s < L.length) s *= 2; return s; })() : 0;
      box.innerHTML = '<div class="info-box">👥 <b>' + L.length + '</b> joueur(s) inscrit(s)' + (size ? ' → arbre de <b>' + size + '</b> places (' + (size - L.length) + ' BYE)' : ' — il en faut au moins 2') + '</div>'
        + '<label style="display:block;margin:8px 0;font-size:.8rem"><input type="checkbox" id="abPf" checked> 🥉 Ajouter une petite finale (match pour la 3e place)</label>'
        + '<button style="' + btn + 'background:var(--c1,#00ff88);color:#000" onclick="ArbreAdmin.generer(true)">🎲 GÉNÉRER (tirage au sort)</button>'
        + '<button style="' + btn + 'background:#3b82f6;color:#fff" onclick="ArbreAdmin.generer(false)">📋 GÉNÉRER (ordre d\'inscription)</button>';
      return;
    }
    const s = Arbre.stats(A), nv = nouveaux().length;
    box.innerHTML = '<div class="info-box">📊 ' + s.joueurs + ' joueurs • ' + s.faits + '/' + s.total + ' matchs joués' + (s.champion ? ' • 🏆 <b>' + esc(A.noms[s.champion] || '') + '</b>' : '') + '</div>'
      + '<div class="info-box">👆 Touche un match pour désigner le vainqueur, saisir le score, corriger ou remplacer un joueur. Les matchs prêts clignotent en jaune.</div>'
      + (nv ? '<button style="' + btn + 'background:#22c55e;color:#000" onclick="ArbreAdmin.ajouterNouveaux()">➕ AJOUTER ' + nv + ' NOUVEAU(X) INSCRIT(S)</button>' : '')
      + '<button style="' + btn + 'background:' + (t.Arbre_visible === false ? '#64748b' : '#0ea5e9') + ';color:#fff" onclick="ArbreAdmin.visibilite()">' + (t.Arbre_visible === false ? '🙈 Masqué aux joueurs — PUBLIER' : '👁️ Visible par les joueurs — MASQUER') + '</button>'
      + '<button style="' + btn + 'background:#a855f7;color:#fff" onclick="ArbreAdmin.image()">📸 Image à partager</button>'
      + (s.champion ? '<button style="' + btn + 'background:#fbbf24;color:#000" onclick="ArbreAdmin.cloturer()">🏁 CLÔTURER + PODIUM</button>' : '')
      + '<button style="' + btn + 'background:#f59e0b;color:#000" onclick="ArbreAdmin.generer(true)">🔀 Régénérer</button>'
      + '<button style="' + btn + 'background:#ef4444;color:#fff" onclick="ArbreAdmin.supprimer()">🗑️ Supprimer</button>'
      + '<div id="abBox"></div>';
    Arbre.rendre($('abBox'), A, { admin: true, onMatch: feuille });
  }
  async function visibilite() {
    const v = T().Arbre_visible === false;
    try { await EvoDB.update(COLLECTIONS.TOURNAMENTS, TID(), { Arbre_visible: v }); T().Arbre_visible = v; afficher(); msg(v ? '✅ Arbre publié' : '🙈 Arbre masqué aux joueurs', 'success'); } catch (e) { msg('❌ ' + e.message, 'error'); }
  }
  function image() { try { Arbre.telecharger(A, T().Nom || 'EVO ARENA'); } catch (e) { msg('❌ ' + e.message, 'error'); } }
  // Clôture : podium de l'arbre + même partage que l'onglet PAYOUT (CEO 50 %, 1er 25 %, 2e 15 %, 3e 10 %)
  async function cloturer() {
    const P = Arbre.podium(A), t = T();
    if (!P.c) return msg('⚠️ L\'arbre n\'a pas encore de champion.', 'error');
    if (A.pf && !P.t && !confirm('La petite finale n\'est pas jouée : clôturer sans 3e place ?')) return;
    if (!confirm('🏁 Clôturer « ' + (t.Nom || '') + ' » avec ce podium ?')) return;
    const cag = (typeof calculerCagnotte === 'function') ? calculerCagnotte(t) : 0, nom = function (id) { return A.noms[id] || ''; };
    const pod = { c: { id: P.c, nom: nom(P.c), gain: Math.floor(cag * .25) }, f: P.f ? { id: P.f, nom: nom(P.f), gain: Math.floor(cag * .15) } : null, t: P.t ? { id: P.t, nom: nom(P.t), gain: Math.floor(cag * .10) } : null, ceo: Math.floor(cag * .5), ts: new Date().toISOString() };
    try {
      await EvoDB.update(COLLECTIONS.TOURNAMENTS, TID(), { Statut: 'termine', Podium: JSON.stringify(pod) });
      t.Statut = 'termine'; t.Podium = JSON.stringify(pod);
      const l = function (e, x) { return x ? e + ' <b>' + esc(x.nom) + '</b> → ' + x.gain.toLocaleString() + ' FCFA<br>' : ''; };
      if (typeof showModalInfo === 'function') showModalInfo('🏁 PODIUM', '👑 CEO : ' + pod.ceo.toLocaleString() + ' FCFA<br>' + l('🥇', pod.c) + l('🥈', pod.f) + l('🥉', pod.t));
      afficher();
    } catch (e) { msg('❌ ' + (e.message || e), 'error'); }
  }
  function ouvrir() { const t = T(); A = t ? Arbre.lire(t) : null; afficher(); }

  // Quand l'admin change de tournoi, l'arbre suit
  try { const _c = chargerTournoi; chargerTournoi = async function (id) { const r = await _c(id); ouvrir(); return r; }; } catch (e) { /* l'onglet rafraîchit aussi à l'ouverture */ }
  window.ArbreAdmin = { visibilite: visibilite, image: image, cloturer: cloturer, ouvrir: ouvrir, generer: generer, ajouterNouveaux: ajouterNouveaux, supprimer: supprimer };
})();
