// FAUX SDK Firebase pour les tests d'interface hors ligne. Ce N'EST PAS Firebase : base mémoire pilotée par window.__FAKE.
(function () {
  const F = window.__FAKE || { uid: null, docs: {}, fns: {} }; window.__CALLS = [];
  const clone = (x) => x === undefined ? undefined : JSON.parse(JSON.stringify(x));
  const snap = (id, v) => ({ id, exists: v !== undefined, data: () => clone(v), ref: null });
  function query(col, filters, lim) {
    const q = {
      where(f, op, v) { return query(col, filters.concat([[f, v]]), lim); }, orderBy() { return q; }, limit(n) { return query(col, filters, n); },
      async get() {
        const docs = Object.keys(F.docs).filter((k) => k.startsWith(col + '/') && !k.slice(col.length + 1).includes('/') && filters.every(([f, v]) => F.docs[k][f] === v))
          .map((k) => snap(k.slice(col.length + 1), F.docs[k])); return { docs: lim ? docs.slice(0, lim) : docs, empty: !docs.length, size: docs.length };
      }
    }; return q;
  }
  const fs = {
    settings() {}, enablePersistence() { return Promise.resolve(); },
    collection(col) { return Object.assign(query(col, [], null), { doc(id) { id = id || ('auto' + Math.random().toString(36).slice(2, 8)); const p = col + '/' + id;
      return { id, async get() { return snap(id, F.docs[p]); }, async set(d, o) { F.docs[p] = o && o.merge ? Object.assign({}, F.docs[p] || {}, d) : d; }, async update(d) { if (!F.docs[p]) throw Object.assign(new Error('not-found'), { code: 'not-found' }); F.docs[p] = Object.assign({}, F.docs[p], d); }, async delete() { delete F.docs[p]; } }; } }); },
    doc(path) { return { async get() { return snap(path.split('/').pop(), F.docs[path]); } }; }
  };
  const user = F.uid ? { uid: F.uid, displayName: F.name || 'Testeur', email: '', phoneNumber: '' } : null;
  const auth = { currentUser: user, languageCode: 'fr', onAuthStateChanged(cb) { setTimeout(() => cb(user), 0); return () => {}; }, getRedirectResult() { return Promise.resolve({}); }, signOut() { return Promise.resolve(); } };
  const functions = { httpsCallable(name) { return async (data) => { window.__CALLS.push({ name, data: clone(data) }); const h = (F.fns || {})[name]; if (!h) throw new Error('Fonction non simulée : ' + name); return { data: typeof h === 'function' ? h(data) : h }; }; } };
  const storage = { ref(path) { return { async put(file, meta) { window.__CALLS.push({ name: 'storage.put', path, type: meta && meta.contentType, size: file && file.size }); return {}; }, async getDownloadURL() { return 'about:blank'; } }; } };
  const fb = { initializeApp() {}, apps: [{}], auth: Object.assign(() => auth, { GoogleAuthProvider: function () { this.setCustomParameters = () => {}; }, PhoneAuthProvider: { credential() {} }, EmailAuthProvider: { credential() {} }, RecaptchaVerifier: function () {} }),
    firestore: Object.assign(() => fs, { FieldValue: { delete: () => ({}) } }), functions: () => functions, storage: () => storage };
  window.firebase = fb;
})();
