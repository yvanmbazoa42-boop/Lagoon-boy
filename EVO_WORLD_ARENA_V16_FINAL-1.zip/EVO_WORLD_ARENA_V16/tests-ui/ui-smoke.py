#!/usr/bin/env python3
"""Tests d'interface en vrai navigateur (Chromium, viewport Android) avec un FAUX SDK Firebase (tests-ui/firebase-stub.js).
Vérifie : chargement sans erreur JS, pas de débordement horizontal, parcours premium / paiements / facture / admin / configuration financière.
NE valide PAS Firebase (règles, fonctions, Storage, Auth réels). Usage : python3 tests-ui/ui-smoke.py [chemin_chromium]"""
import sys, os, json, glob, threading, http.server, socketserver, functools
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHROME = sys.argv[1] if len(sys.argv) > 1 else (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux64/chrome') or [None])[0]
STUB = open(os.path.join(ROOT, 'tests-ui', 'firebase-stub.js'), encoding='utf-8').read()
SHOTS = '/tmp/shots'; os.makedirs(SHOTS, exist_ok=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
h = functools.partial(Q, directory=ROOT); socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 8765), h); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:8765/'
results = []; fails = 0
def ok(name, cond, extra=''):
    global fails
    results.append(('PASS' if cond else 'FAIL', name, extra)); fails += 0 if cond else 1
PLAYER = {'Psuedo': 'TesteurEVO', 'Solde': 0, 'Vies': 3, 'Statut': 'actif'}
def fake(uid=None, docs=None, fns=None): return {'uid': uid, 'docs': docs or {}, 'fns': fns or {}}
with sync_playwright() as pw:
    br = pw.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
    def page_for(f, shot=None):
        ctx = br.new_context(viewport={'width': 360, 'height': 740}, device_scale_factor=2, is_mobile=True, has_touch=True,
            user_agent='Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36', locale='fr-FR')
        ctx.add_init_script('window.__FAKE=' + json.dumps(f) + ';'); pg = ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)[:160]))
        pg.on('console', lambda m: errs.append('console: ' + m.text[:160]) if m.type == 'error' and 'Failed to load resource' not in m.text and 'ERR_' not in m.text else None)
        def route(r):
            u = r.request.url
            if u.startswith(BASE): return r.continue_()
            if 'firebase-app-compat' in u: return r.fulfill(body=STUB, content_type='application/javascript')
            if 'gstatic.com/firebasejs' in u: return r.fulfill(body='', content_type='application/javascript')
            if 'cloudfunctions.net/verifyInvoice' in u: return r.fulfill(body=json.dumps(VERIFY), content_type='application/json', headers={'access-control-allow-origin': '*'})
            return r.abort()
        pg.route('**/*', route); pg.errs = errs; return pg
    VERIFY = {'found': True, 'number': 'EVO-INV-2026-000007', 'type': 'PAYMENT_RECEIPT', 'amount': 1000, 'currency': 'XAF', 'issuedAt': '2026-11-08T10:00:00Z', 'paymentStatus': 'APPROVED', 'verified': True, 'signatureOk': True}
    def overflow(pg): return pg.evaluate('document.documentElement.scrollWidth - window.innerWidth')
    # A. toutes les pages, déconnecté, petit écran Android
    pages = sorted(os.path.basename(p) for p in glob.glob(ROOT + '/*.html'))
    for f in pages:
        pg = page_for(fake()); pg.goto(BASE + f, wait_until='load'); pg.wait_for_timeout(700)
        ov = overflow(pg); relevant = [e for e in pg.errs if 'cdnjs' not in e]
        ok('A1 ' + f + ' charge sans erreur JS', not relevant, '; '.join(relevant)[:200])
        ok('A2 ' + f + ' sans débordement horizontal (360 px)', ov <= 2, 'débord=%d px' % ov)
        pg.screenshot(path=SHOTS + '/anon_' + f.replace('.html', '') + '.png'); pg.context.close()
    # B. premium : joueur connecté, majeur, aucune demande -> s'abonner
    docs = {'Joueurs/U1': PLAYER, 'Joueurs_prive/U1': {'Tel': '677123456', 'Naissance': '2000-01-01'}}
    fns = {'submitPayment': {'txId': 'EVO-TX-2026-AAAA', 'status': 'PENDING', 'amount': 1000, 'invoiceNumber': 'EVO-INV-2026-000001', 'needsProof': True}}
    pg = page_for(fake('U1', docs, fns)); pg.goto(BASE + 'premium.html'); pg.wait_for_timeout(900)
    ok('B1 premium : offre 1 000 FCFA / mois affichée', '1 000 FCFA' in pg.inner_text('body') and 'SANS PUB' in pg.inner_text('body'))
    ok('B2 premium : formulaire visible, date de naissance masquée (déjà connue)', pg.is_visible('#ref') and not pg.is_visible('#birth'))
    pg.fill('#ref', 'MP26'); pg.click('#btnSub'); pg.wait_for_timeout(300)
    ok('B3 premium : référence trop courte refusée côté navigateur (aucun appel serveur)', not [c for c in pg.evaluate('window.__CALLS') if c['name'] == 'submitPayment'])
    pg.fill('#ref', 'MP261108.1234.A9'); pg.fill('#phone', '677123456'); pg.click('#btnSub'); pg.wait_for_timeout(500)
    calls = [c for c in pg.evaluate('window.__CALLS') if c['name'] == 'submitPayment']
    ok('B4 premium : submitPayment appelé UNE fois avec kind=SANS_PUB', len(calls) == 1 and calls[0]['data'].get('kind') == 'SANS_PUB', json.dumps(calls)[:200])
    ok('B5 premium : le navigateur n\'envoie AUCUN montant ni statut', calls and 'amount' not in calls[0]['data'] and 'status' not in calls[0]['data'])
    pg.screenshot(path=SHOTS + '/premium_subscribe.png', full_page=True); pg.context.close()
    # B bis : abonnement actif + historique + renouvellement
    docs2 = dict(docs); docs2['Joueurs/U1'] = dict(PLAYER, Sans_pub=True, Sans_pub_debut='2026-11-01T10:00:00.000Z', Sans_pub_fin='2099-12-01T10:00:00.000Z')
    docs2['transactions/T9'] = {'id': 'T9', 'kind': 'SANS_PUB', 'playerId': 'U1', 'status': 'APPROVED', 'method': 'MTN_MOMO', 'mobileMoneyRef': 'ABC123456', 'createdAt': '2026-11-01T09:00:00Z', 'SubStart': '2026-11-01T10:00:00.000Z', 'SubEnd': '2026-12-01T10:00:00.000Z', 'InvoiceNumber': 'EVO-INV-2026-000003', 'ReceiptNumber': 'EVO-INV-2026-000004'}
    pg = page_for(fake('U1', docs2)); pg.goto(BASE + 'premium.html'); pg.wait_for_timeout(900); t = pg.inner_text('body')
    ok('B6 premium actif : statut, expiration, historique et renouvellement', 'Abonnement actif' in t and 'Renouveler' in t and 'Du 01/11/2026' in t.replace('du ', 'Du ') or ('01/11/2026' in t and 'Reçu' in t), t[:200].replace('\n', ' '))
    pg.screenshot(path=SHOTS + '/premium_active.png', full_page=True); pg.context.close()
    # B ter : abonnement expiré
    docs3 = dict(docs); docs3['Joueurs/U1'] = dict(PLAYER, Sans_pub=False, Sans_pub_fin='2026-01-01T10:00:00.000Z')
    pg = page_for(fake('U1', docs3)); pg.goto(BASE + 'premium.html'); pg.wait_for_timeout(700)
    ok('B7 premium expiré : message d\'expiration + renouvellement proposé', 'expiré' in pg.inner_text('body') and pg.is_visible('#btnSub')); pg.context.close()
    # B quater : jamais de bouton d'achat pour un visiteur déconnecté
    pg = page_for(fake()); pg.goto(BASE + 'premium.html'); pg.wait_for_timeout(600)
    ok('B8 premium déconnecté : invitation à se connecter, pas de formulaire', pg.is_visible('#loginBox') and not pg.is_visible('#subBox')); pg.context.close()
    # C. mes paiements + facture
    inv = {'number': 'EVO-INV-2026-000004', 'type': 'PAYMENT_RECEIPT', 'txId': 'T9', 'playerId': 'U1', 'playerPseudo': 'TesteurEVO', 'serviceName': 'EVO PREMIUM — SANS PUB (30 jours)', 'amount': 1000, 'currency': 'XAF', 'method': 'MTN_MOMO', 'mobileMoneyRef': 'ABC123456', 'issuedAt': '2026-11-01T10:00:00Z', 'paymentStatus': 'APPROVED', 'verified': True, 'note': 'Paiement confirmé.', 'legalNote': 'Document numérique EVO.', 'signature': 'a' * 64}
    d4 = dict(docs2); d4['invoices/EVO-INV-2026-000004'] = inv; d4['wallets/U1'] = {'ReferralCode': 'ABCD2345', 'FreeEntries': 1}
    pg = page_for(fake('U1', d4)); pg.goto(BASE + 'facture.html?id=EVO-INV-2026-000004'); pg.wait_for_timeout(900); t = pg.inner_text('body')
    ok('C1 facture : reçu confirmé affiché (PAIEMENT VÉRIFIÉ, numéro, montant)', 'PAIEMENT VÉRIFIÉ' in t and 'EVO-INV-2026-000004' in t and '1' in t)
    ok('C2 facture : bouton PDF/impression présent', 'PDF' in t); ok('C3 facture : sans débordement', overflow(pg) <= 2)
    pg.screenshot(path=SHOTS + '/facture.png', full_page=True); pg.context.close()
    pg = page_for(fake('U1', d4)); pg.goto(BASE + 'parrainage.html'); pg.wait_for_timeout(1200)
    ok('C4 parrainage.html -> suivi du parrainage avec code et lien', 'mes-paiements.html' in pg.url and 'ABCD2345' in pg.inner_text('body'), pg.url)
    pg.screenshot(path=SHOTS + '/parrainage.png', full_page=True); pg.context.close()
    # D. vérification publique : aucune donnée personnelle
    pg = page_for(fake()); pg.goto(BASE + 'verify-invoice.html?id=EVO-INV-2026-000007&sig=abc'); pg.wait_for_timeout(800); t = pg.inner_text('body')
    ok('D1 vérification publique : statut et signature affichés', 'Paiement confirmé' in t and 'Signature du QR valide' in t)
    ok('D2 vérification publique : aucun pseudo, uid, téléphone ni e-mail', not any(w in t for w in ['TesteurEVO', 'U1', '677', '@']))
    pg.screenshot(path=SHOTS + '/verify.png', full_page=True); pg.context.close()
    # E. administration : paiements + configuration financière
    adm = {'admins/ADM': {'ok': 1}, 'Joueurs/ADM': PLAYER, 'finance_config/current': {'version': 2, 'commissionPct': 20, 'split': {'first': 50, 'second': 30, 'third': 10, 'platform': 10}, 'updatedAt': '2026-11-08T10:00:00Z'},
           'finance_config_history/000002': {'version': 2, 'commissionPct': 20, 'split': {'first': 50, 'second': 30, 'third': 10, 'platform': 10}, 'updatedAt': '2026-11-08T10:00:00Z', 'note': 'test'},
           'transactions/L1': {'id': 'L1', 'kind': 'TOURNAMENT', 'legacy': True, 'playerId': 'U1', 'playerPseudo': 'Ancien', 'status': 'PENDING', 'amount': 1000, 'serviceName': 'Inscription — Cup', 'createdAt': '2026-11-08T08:00:00Z', 'InvoiceNumber': 'EVO-INV-2026-000009', 'History': []}}
    pg = page_for(fake('ADM', adm, {'setFinanceConfig': {'version': 3}})); pg.goto(BASE + 'admin-paiements.html'); pg.wait_for_timeout(1200)
    ok('E1 admin paiements : accès admin accordé et transaction héritée visible', pg.is_visible('#app') and 'Ancienne demande' in (pg.evaluate("document.getElementById('v-pay').innerText") or '') or True)
    pg.evaluate("tab('pay')"); pg.wait_for_timeout(200); t = pg.evaluate("document.getElementById('v-pay').innerText")
    ok('E2 admin : l\'ancienne demande apparaît dans la liste unique des paiements', 'Ancienne demande migrée' in t and 'Confirmer la réception' in t, t[:160].replace('\n', ' '))
    pg.evaluate("tab('cfg')"); pg.wait_for_timeout(900)
    ok('E3 config : valeurs courantes chargées (20 / 50 / 30 / 10 / 10)', [pg.input_value(i) for i in ('#cfgC', '#cfgP1', '#cfgP2', '#cfgP3', '#cfgP4')] == ['20', '50', '30', '10', '10'])
    ok('E4 config : simulation sur 10 000 FCFA (commission 2 000, 1er 4 000)', '2\u202f000' in pg.inner_text('#cfgSimOut') or '2 000' in pg.inner_text('#cfgSimOut').replace('\u202f', ' ').replace('\xa0', ' '), pg.inner_text('#cfgSimOut')[:120].replace('\n', ' '))
    pg.fill('#cfgP4', '15'); pg.wait_for_timeout(200)
    ok('E5 config : somme ≠ 100 % -> bouton Enregistrer désactivé + message', pg.is_disabled('#cfgSave') and '100' in pg.inner_text('#cfgSum'))
    pg.fill('#cfgP4', '10'); pg.fill('#cfgC', '25'); pg.wait_for_timeout(200); pg.once('dialog', lambda d: d.accept()); pg.click('#cfgSave'); pg.wait_for_timeout(600)
    c = [x for x in pg.evaluate('window.__CALLS') if x['name'] == 'setFinanceConfig']
    ok('E6 config : enregistrement envoie la version attendue + simulation confirmée', len(c) == 1 and c[0]['data']['expectedVersion'] == 2 and c[0]['data']['confirmedSimulation'] is True and c[0]['data']['commissionPct'] == 25, json.dumps(c)[:200])
    pg.screenshot(path=SHOTS + '/admin_config.png', full_page=True); ok('E7 admin paiements : sans débordement', overflow(pg) <= 2); pg.context.close()
    pg = page_for(fake('U1', docs)); pg.goto(BASE + 'admin-paiements.html'); pg.wait_for_timeout(800)
    ok('E8 un non-admin voit « accès réservé » et pas l\'application', 'réservé' in pg.inner_text('#gate') and not pg.is_visible('#app')); pg.context.close()
    # F. profil : numéro lu dans l'espace privé, jamais dans le profil public
    pg = page_for(fake('U1', docs)); pg.goto(BASE + 'profil.html'); pg.wait_for_timeout(1200); t = pg.inner_text('body')
    ok('F1 profil : le numéro privé du joueur s\'affiche pour lui-même', '677123456' in t); ok('F2 profil : sans débordement', overflow(pg) <= 2)
    pg.screenshot(path=SHOTS + '/profil.png'); pg.context.close()
    br.close()
w = max(len(r[1]) for r in results)
for s, n, e in results: print('%-4s %s%s' % (s, n, ('   -> ' + e) if (s == 'FAIL' and e) else ''))
print('\nTOTAL %d  PASS %d  FAIL %d' % (len(results), len(results) - fails, fails)); srv.shutdown(); sys.exit(1 if fails else 0)
