# DEPLOY_GUIDE — EVO WORLD ARENA V16

Légende : ✅ déjà exécuté dans l'environnement de développement · 🧑 **à faire par toi** (identifiants / décision).
Rien de ce guide n'a été exécuté contre ton vrai projet Firebase (`evo-world-arena-7319b`). Aucun paiement réel n'a été lancé.

## 0. Prérequis (🧑)
Node 20+, Java 11+ (émulateurs), `npm i -g firebase-tools`, `firebase login`, forfait **Blaze** (obligatoire pour les Cloud Functions et l'expiration planifiée des abonnements).

## 1. Configurer Firebase (🧑, console Firebase)
1. **Authentication** → activer *E-mail/Mot de passe*, *Google*, *Téléphone* (déjà utilisés par le site).
2. **Firestore** : base en mode production. **Storage** : *Commencer* (active le bucket) — nécessaire pour les captures de paiement.
3. **IAM (Google Cloud)** : donner le rôle **Créateur de jetons du compte de service** (*Service Account Token Creator*) au compte de service d'exécution des fonctions (`evo-world-arena-7319b@appspot.gserviceaccount.com`). Sans lui, la connexion par numéro (jeton personnalisé) échoue.
4. (Recommandé) **App Check** : enregistrer l'application web avec reCAPTCHA v3. Le code serveur lit `ENFORCE_APPCHECK=1` mais **le client n'initialise pas encore App Check** : n'active l'application stricte qu'après avoir ajouté `firebase.appCheck().activate(CLE_SITE)` dans `firebase-config.js`.

## 2. Secrets (🧑)
```
firebase functions:secrets:set INVOICE_SECRET --project evo-world-arena-7319b   # ≥ 32 caractères aléatoires, jamais dans le site ni dans Git
```
`functions/.env` ne contient que `WEB_API_KEY` = clé Web Firebase, **publique par conception** (déjà dans `firebase-config.js`). Aucune clé privée n'est dans le ZIP.

## 3. Tester en local
```
cd functions && npm install && npm test                      # ✅ 39/39 (base mémoire)
cd functions && npm install && npm run test:rules            # 🧑 émulateurs Firestore+Storage : règles et accès aux preuves
firebase emulators:start                                      # 🧑 UI émulateur : http://localhost:4000
pip install playwright && playwright install chromium && python3 tests-ui/ui-smoke.py   # ✅ 68/68 (faux SDK Firebase)
```
`@firebase/rules-unit-testing` s'installe via `npm install` (devDependency). Les règles ne sont **validées par Firebase** que lorsque `test:rules` réussit chez toi.

## 4. Déployer — ORDRE IMPORTANT (🧑)
1. **Fonctions** : `firebase deploy --only functions --project evo-world-arena-7319b`
2. **Index** : `firebase deploy --only firestore:indexes`
3. **Migration des données privées** (compte de service local, ne jamais le committer) :
   ```
   export GOOGLE_APPLICATION_CREDENTIALS=/chemin/cle-service.json
   node scripts/migrate-private.js            # simulation : n'écrit rien
   node scripts/migrate-private.js --apply    # copie, vérifie, puis retire du profil public
   ```
4. **Site (frontend)** : publier le dossier sur ton hébergement (le HTML v16 lit `Joueurs_prive`).
5. **Relancer** `node scripts/migrate-private.js --apply` (rattrape les comptes créés entre-temps), puis **règles** : `firebase deploy --only firestore:rules,storage`.
   ⚠️ Déployer les règles AVANT la migration empêcherait les joueurs non migrés de modifier leur profil.
6. **Anciennes demandes « En attente »** : ouvrir *Admin → un tournoi* ; si une bannière jaune apparaît, cliquer *Migrer*, puis valider chaque demande dans *Gestion des paiements* (référence Mobile Money à saisir).

## 5. Créer le premier administrateur (🧑)
Console Firestore → collection `admins` → document dont l'ID = l'**UID Firebase Auth** du compte admin (Authentication → Utilisateurs) → champ `ok: true`. Les règles interdisent de créer un admin depuis le site.

## 6. Configurer commission et répartitions (🧑, dans le site)
*Admin → Finances (admin-paiements.html) → ⚙️ Configuration* : commission (%), 1er/2e/3e/plateforme (somme = 100 %), regarder la simulation, noter un motif, **Enregistrer**. S'applique aux tournois dont aucune inscription payante n'est encore confirmée ; un tournoi déjà engagé garde ses règles figées.

## 7. Activer les abonnements Sans pub
Rien à activer côté code : `premium.html` est livré (accessible via *Profil → Retirer les pubs*). 🧑 Ajoute si tu veux un lien direct dans ton menu. L'expiration automatique (`expireSubscriptions`, tous les jours 01:00 Douala) exige Blaze ; sans elle, l'accès reste refusé par la date (`sansPubActif`).

## 8. Vérifier après déploiement (🧑)
Inscription test → profil public ne montre aucun numéro → connexion par numéro → paiement test d'**un compte de test** (aucun paiement réel) → validation admin → facture + reçu + QR → page `verify-invoice.html`.
