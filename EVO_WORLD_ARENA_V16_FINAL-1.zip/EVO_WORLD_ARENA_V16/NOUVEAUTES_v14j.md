# EVO ARENA v14j — mise à jour du 8 novembre 2026

## Ce qui a changé
1. **Fonds animés en direct plus visibles** : plus d'éléments (pétales, flocons, braises, étoiles, lucioles), plus gros et plus lumineux, lueurs renforcées, Matrice plus nette. Fichier : `fonds.js`.
2. **Barre de navigation du bas permanente** : elle ne se cache plus jamais (même avec le clavier), reste fixée en bas sur toutes les pages. L'icône 🌳 Arbre n'est plus dans la barre ; le bouton « Voir les arbres des tournois » reste en haut de l'accueil. Fichiers : `evo-native.js` + pages.
3. **Studio de création** : correction de l'erreur « Cannot set properties of null (setting 'clips') ». Fichier : `creer.js`.
4. **Stockage** : photos et vidéos envoyées uniquement sur **Appwrite** (bucket `evo-media`). Cloudinary est supprimé du code, de la config de l'app Android et de la documentation. Fichier : `firebase-config.js`.
5. **Publicité** : script Monetag (pub classique + pub plein écran) supprimé. Fichier : `evo-config.js`.
6. **Paiements** : inchangés (Orange Money / MTN MoMo par code USSD, validation par un admin). Aucune mention Monetbil dans le site.
7. **Infos de version** : version « 14j · 8 nov. 2026 » affichée dans ⚙️ Paramètres, nouveau cache du service worker, application Android en version 1.2.0.

## À faire de ton côté
- Remplacer tout le site par ce zip, puis fermer complètement l'app et la rouvrir (vider le cache si l'ancienne version reste).
- Appwrite : bucket › Settings › autoriser la création pour tout le monde et régler la taille max des fichiers pour les vidéos.
- `firestore.rules` : pas de changement cette fois.

## À surveiller
- Si une vidéo du studio reste noire (0:00), me le dire avec le message d'erreur : le format d'enregistrement du téléphone est à corriger.
- La pub « Retirer les pubs » (1 000 FCFA/mois) est toujours dans l'app alors qu'il n'y a plus de pubs.
