# EVO WORLD ARENA — V16 (préproduction) — README

> V16 = v15 + protection des données privées, paiements unifiés, configuration financière, abonnement EVO PREMIUM, parrainage antifraude, tests.
> Lis dans cet ordre : **DEPLOY_GUIDE.md** (installer/déployer) → **FINAL_REPORT.md** (ce qui est fait / non testé / à ta charge) → **TEST_REPORT.md** → **SECURITY_REPORT.md**.

## Nouveautés V16
| Domaine | Ce qui change | Où |
|---|---|---|
| Données privées | E-mail, téléphone, WhatsApp, naissance → `Joueurs_prive/{uid}` (lecture : le joueur + admins ; écriture : serveur). Le profil public (`Joueurs`) n'en contient plus. Connexion par numéro et mot de passe oublié passent par le serveur (`phoneSignIn`, `requestPasswordReset`) sans exposer l'e-mail. | `firestore.rules`, `functions/lib/core.js`, `evo-config.js`, `scripts/migrate-private.js` |
| Contacts entre joueurs | Plus aucun numéro affiché ; on se contacte par la messagerie interne. | `messages.html`, `clans.html` |
| Paiements | Source unique = collection `transactions`. L'ancien « En attente » n'a plus de boutons Valider/Refuser : bannière de migration (`importLegacyPending`, archive conservée). | `admin.html`, `admin-paiements.html` |
| Finances | Onglet ⚙️ Configuration : commission, répartition 1er/2e/3e/plateforme = 100 %, simulation, historique versionné. Règles **figées** à la 1re inscription payante confirmée d'un tournoi. | `admin-paiements.html`, `functions/lib/finance-calc.js` |
| Abonnement | Page `premium.html` (EVO PREMIUM — SANS PUB, 1 000 FCFA/mois) : transaction, capture, validation admin, dates début/fin, renouvellement, historique, expiration quotidienne (`expireSubscriptions`). | `premium.html` |
| Parrainage | Plafond de filleuls, contrôle numéro du parrain (compte ou paiement), validation admin = récompense une seule fois, journal d'audit. Suivi : `parrainage.html` → onglet Parrainage. | `core.js`, `mes-paiements.html` |
| Tests | 39 tests serveur, 68 contrôles navigateur (Android 360 px), tests de règles Firestore/Storage **écrits pour l'émulateur**. | `functions/test/`, `tests-ui/` |

## Structure
- Site statique : `*.html`, `*.js` (hébergement au choix). Cloud Functions : `functions/` (`index.js` = enveloppes, `lib/core.js` = logique testée).
- `firestore.rules`, `storage.rules`, `firestore.indexes.json`, `firebase.json` (émulateurs).
- `scripts/migrate-private.js` (migration), `deploy.sh`, `tests-ui/` (navigateur), `functions/test/` (serveur + règles).

## Commandes utiles
```
cd functions && npm install && npm test          # 39 tests serveur (base mémoire)
cd functions && npm run test:rules               # règles Firestore/Storage (émulateurs, nécessite firebase-tools + Java)
pip install playwright && playwright install chromium && python3 tests-ui/ui-smoke.py   # interface Android (faux SDK Firebase)
```

---
# Historique v15 (conservé)

# EVO ARENA v15 — paiements, factures, parrainage, gains

Base : v14k (design et fonctions existantes conservés). Firebase conservé.

## Nouveautés
- **Paiements** (Cloud Functions) : le joueur paie par Mobile Money, saisit la référence du SMS, envoie sa demande (statut PENDING), joint une capture (UNDER_REVIEW). L'admin confirme **avoir reçu l'argent** (montant exact) → APPROVED + inscription + reçu. Sinon REJECTED (raison obligatoire). REFUNDED seulement après confirmation du vrai transfert.
- **Anti-fraude** : montant décidé par le serveur ; une référence Mobile Money = une seule transaction ; double validation impossible (transaction Firestore) ; historique de chaque changement de statut ; journal admin.
- **Factures** : EVO-INV-AAAA-NNNNNN, 6 types, signature HMAC, QR vers verify-invoice.html (page publique minimale).
- **Mineurs** : paiement (tournoi ou Sans pub) refusé si < 18 ans (date de naissance déclarée, non vérifiée).
- **Admin** : admin-paiements.html (bouton dans admin.html) : tableau de bord, paiements, preuves, remboursements, gains, parrainage, export CSV.
- **Joueur** : mes-paiements.html (bouton dans le profil) : transactions, factures, reçus, remboursements, gains, parrainage.
- **Pages légales** : cgu, confidentialite, remboursement, reglement (liens dans le pied de page).

## Installation (≈ 30 min, sur ton ordinateur)
1. **Passe le projet Firebase en offre Blaze** (obligatoire pour Cloud Functions et Storage ; quota gratuit conservé, carte bancaire demandée). Active **Storage** (console → Storage → Commencer).
2. \`npm i -g firebase-tools\` puis \`firebase login\`.
3. \`./deploy.sh\` : installe, lance les tests, te demande le secret **INVOICE_SECRET** (chaîne aléatoire ≥ 32 caractères que tu inventes et ne donnes à personne), déploie règles, index, Storage, fonctions.
4. Console Firebase → Authentication → Settings → Authorized domains : ajoute ton domaine.
5. **Configure chaque tournoi payant** dans Firestore (collection Tournois, champs à ajouter à la main — le formulaire admin ne les a pas encore) : \`Commission_pct\` (nombre, ex. 20) et \`Repartition\` (texte JSON, ex. \`[50,30,20]\`). Sans eux, le calcul des gains refuse de s'exécuter (rien n'est inventé).
6. Mets en ligne le dossier du site. Si ton hébergeur n'est pas Netlify, l'adresse \`/verify-invoice\` n'existe pas : utilise \`verify-invoice.html\` (le QR l'utilise déjà).
7. **Teste avec l'émulateur avant d'ouvrir au public** : \`firebase emulators:start\` ; règles : voir functions/test/rules.emulator.test.js.
8. Recommandé : activer **App Check** (console Firebase) puis \`ENFORCE_APPCHECK=1\` ; restreindre la clé API à ton domaine (Google Cloud → Identifiants).

## Configurations Firebase nécessaires
Blaze · Storage activé · secret INVOICE_SECRET · règles Firestore + Storage publiées · index déployés · domaines autorisés · (option) App Check · ton UID dans la collection \`admins\`.

## Collections (noms adaptés à l'existant)
Joueurs (public) · **Joueurs_prive** (date de naissance) · **transactions** (+ Proof, History) · **invoices** · **invoice_public** · **invoice_counters** · **payment_refs** · **registrations** (verrous anti-doublon) · **refunds** · **wallets** (entrées gratuites, code) · **referral_codes / referrals / referral_rewards** · **prize_distributions** · **tournament_finance** · admin_logs · preuves : Storage \`payment_proofs/{uid}/{txId}/\`. Toutes ces collections sont **en écriture serveur uniquement**.

## Limites connues (honnêtes)
- **Numéro/WhatsApp/e-mail encore publics** dans Joueurs : les séparer casserait deux fonctions existantes (contact WhatsApp entre joueurs dans clans/messages, connexion par numéro). C'est une décision produit à prendre ; non fait.
- L'ancien onglet admin « En attente » (admin.html) existe encore pour les anciennes demandes : il ne crée ni transaction ni facture. À retirer une fois les anciennes demandes traitées. Les autres actions de admin.html (résultats, vies, solde) restent côté navigateur, protégées seulement par les règles « admin ».
- Pas d'écran joueur pour acheter « Sans pub » : le serveur le gère (kind SANS_PUB), le bouton reste à ajouter.
- Détection de comptes multiples : uniquement même numéro de téléphone. Âge : déclaratif.
- Documents numériques non fiscaux ; règles des compétitions payantes à faire valider par un juriste au Cameroun.
