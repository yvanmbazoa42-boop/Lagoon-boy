// ============================================================
// EVO — FONDS D'ÉCRAN ANIMÉS EN DIRECT (chargé sur toutes les pages)
// 🌸 Sakura · 💚 Matrice · ✨ Galaxie · 🔥 Braises · ❄️ Neige · 🟡 Lucioles
// Choix du joueur : ⚙️ Paramètres › Fond animé. Fond par défaut du site : choisi par l'admin
// (onglet 🎨 FOND de l'admin, stocké dans Config/fond). Le choix du joueur est prioritaire.
// Respecte « Animations réduites », se met en pause quand l'app est cachée.
// ============================================================
(function () {
  'use strict';
  var CLE = 'evo_fond_anime', CLE_DEF = 'evo_fond_defaut';
  var LISTE = {
    aucun:   { nom: 'Original EVO', ico: '🎮' },
    vagues:  { nom: 'Vagues PS', ico: '🌊' },
    sakura:  { nom: 'Sakura',   ico: '🌸' },
    matrice: { nom: 'Matrice',  ico: '💚' },
    galaxie: { nom: 'Galaxie',  ico: '✨' },
    braises: { nom: 'Braises',  ico: '🔥' },
    neige:   { nom: 'Neige',    ico: '❄️' },
    lucioles:{ nom: 'Lucioles', ico: '🟡' }
  };
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function couleurTheme() {
    var c = getComputedStyle(document.documentElement).getPropertyValue('--c1').trim();
    return /^#[0-9a-f]{6}$/i.test(c) ? c : '#00ff88';
  }
  function couleurTheme2() {
    var c = getComputedStyle(document.documentElement).getPropertyValue('--c2').trim();
    return /^#[0-9a-f]{6}$/i.test(c) ? c : '#7c3aed';
  }
  function rgb(h) { var n = parseInt(h.replace('#', ''), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

  var cv = null, ctx = null, W = 0, H = 0, dpr = 1, actif = 'aucun', parts = [], raf = 0, dernier = 0, pasMs = 16;
  var faible = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 2);

  function calme() {
    return document.documentElement.classList.contains('evo-calme') ||
      (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  }
  function creerCanvas() {
    if (cv) return;
    cv = document.createElement('canvas'); cv.id = 'evoFondAnime';
    cv.setAttribute('aria-hidden', 'true');
    cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none;display:block;filter:brightness(1.3) saturate(1.35)';
    document.body.insertBefore(cv, document.body.firstChild);
    ctx = cv.getContext('2d');
    redim();
  }
  function redim() {
    if (!cv) return;
    dpr = Math.min(window.devicePixelRatio || 1, faible ? 1 : 1.5);
    W = Math.max(1, Math.floor(window.innerWidth)); H = Math.max(1, Math.floor(window.innerHeight));
    cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (actif !== 'aucun') init(actif);
  }
  function nb(base) { var n = Math.round(base * (W * H) / (390 * 800)); n = Math.max(8, Math.min(n, 220)); return faible ? Math.round(n * .55) : n; }

  // ---------- 🌸 SAKURA ----------
  function petale(haut) {
    return { x: rnd(0, W), y: haut ? rnd(-H * .2, -10) : rnd(0, H), r: rnd(8, 16), vy: rnd(.35, .9), vx: rnd(-.25, .35),
      ph: rnd(0, 6.28), sw: rnd(.01, .025), rot: rnd(0, 6.28), vr: rnd(-.025, .025), tilt: rnd(0, 6.28), a: rnd(.8, 1), t: Math.floor(rnd(0, 3)) };
  }
  function dessinPetale(p) {
    var cols = ['#ffc1d9', '#ffadc9', '#ffe0ec'];
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.scale(1, .55 + .45 * Math.abs(Math.sin(p.tilt)));
    ctx.globalAlpha = p.a; ctx.fillStyle = cols[p.t];
    ctx.beginPath(); ctx.moveTo(0, -p.r);
    ctx.bezierCurveTo(p.r * .95, -p.r * .9, p.r * .9, p.r * .5, 0, p.r);
    ctx.bezierCurveTo(-p.r * .9, p.r * .5, -p.r * .95, -p.r * .9, 0, -p.r);
    ctx.closePath(); ctx.fill();
    ctx.globalAlpha = p.a * .5; ctx.fillStyle = '#ff7fae'; ctx.beginPath(); ctx.arc(0, -p.r * .55, p.r * .16, 0, 6.28); ctx.fill();
    ctx.restore();
  }
  // ---------- ❄️ NEIGE ----------
  function flocon(haut) { return { x: rnd(0, W), y: haut ? rnd(-H * .1, -5) : rnd(0, H), r: rnd(2, 5), vy: rnd(.4, 1.3), ph: rnd(0, 6.28), sw: rnd(.008, .02), a: rnd(.75, 1) }; }
  // ---------- 🔥 BRAISES ----------
  function braise(bas) { return { x: rnd(0, W), y: bas ? H + rnd(0, 30) : rnd(0, H), r: rnd(2, 4.5), vy: rnd(.5, 1.7), ph: rnd(0, 6.28), sw: rnd(.01, .03), life: rnd(.4, 1), fl: rnd(0, 6.28) }; }
  // ---------- ✨ GALAXIE ----------
  function etoile() { return { x: rnd(0, W), y: rnd(0, H), r: rnd(.9, 2.8), ph: rnd(0, 6.28), v: rnd(.008, .035), z: rnd(.05, .4) }; }
  // ---------- 🟡 LUCIOLES ----------
  function lucio() { return { x: rnd(0, W), y: rnd(0, H), r: rnd(2.6, 5), ang: rnd(0, 6.28), v: rnd(.15, .5), ph: rnd(0, 6.28), pv: rnd(.01, .03) }; }
  // ---------- 💚 MATRICE ----------
  var CARS = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789'.split('');
  var colw = 16, cols = [];

  var etoilesFil = [], eclair = 0, colA = [0, 255, 136], colB = [124, 58, 237];
  var COUCHES = [
    { b: .50, a: .07, f: .60, s: .00042, p: 0, al: .40, c: 0 },
    { b: .60, a: .08, f: .45, s: -.00031, p: 2, al: .36, c: 1 },
    { b: .70, a: .06, f: .90, s: .00055, p: 4, al: .32, c: 0 },
    { b: .42, a: .05, f: .50, s: .00025, p: 1, al: .28, c: 1 },
    { b: .80, a: .05, f: 1.10, s: -.00045, p: 3, al: .28, c: 0 }
  ];

  function init(id) {
    parts = []; etoilesFil = [];
    var i, n;
    if (id === 'sakura') { n = nb(55); for (i = 0; i < n; i++) parts.push(petale(false)); }
    else if (id === 'neige') { n = nb(95); for (i = 0; i < n; i++) parts.push(flocon(false)); }
    else if (id === 'braises') { n = nb(75); for (i = 0; i < n; i++) parts.push(braise(false)); }
    else if (id === 'galaxie') { n = nb(140); for (i = 0; i < n; i++) parts.push(etoile()); }
    else if (id === 'lucioles') { n = nb(48); for (i = 0; i < n; i++) parts.push(lucio()); }
    else if (id === 'vagues') { colA = rgb(couleurTheme()); colB = rgb(couleurTheme2()); }
    else if (id === 'matrice') { colw = W < 500 ? 14 : 18; n = Math.ceil(W / colw); cols = []; for (i = 0; i < n; i++) cols.push({ y: rnd(-H, 0), v: rnd(2, 5.5), l: Math.floor(rnd(8, 22)) }); ctx.fillStyle = '#000'; }
    if (ctx) ctx.clearRect(0, 0, W, H);
  }

  function image(t) {
    var i, p, c;
    if (actif === 'matrice') {
      var rg = rgb(couleurTheme());
      ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = 'rgba(0,0,0,.09)'; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = 'source-over';
      ctx.font = (colw - 2) + 'px monospace';
      for (i = 0; i < cols.length; i++) {
        c = cols[i]; ctx.fillStyle = 'rgba(' + rg[0] + ',' + rg[1] + ',' + rg[2] + ',.95)';
        ctx.fillText(CARS[Math.floor(Math.random() * CARS.length)], i * colw, c.y);
        ctx.fillStyle = 'rgba(255,255,255,.95)'; ctx.fillText(CARS[Math.floor(Math.random() * CARS.length)], i * colw, c.y + colw);
        c.y += c.v; if (c.y > H + c.l * colw) { c.y = rnd(-200, 0); c.v = rnd(2, 5.5); }
      }
      return;
    }
    if (actif === 'vagues') {
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';
      var gl0 = ctx.createRadialGradient(W * .5, H * .15, 10, W * .5, H * .15, H * .75);
      gl0.addColorStop(0, 'rgba(' + colB[0] + ',' + colB[1] + ',' + colB[2] + ',.30)'); gl0.addColorStop(1, 'rgba(' + colB[0] + ',' + colB[1] + ',' + colB[2] + ',0)');
      ctx.fillStyle = gl0; ctx.fillRect(0, 0, W, H);
      for (var li = 0; li < COUCHES.length; li++) {
        var L = COUCHES[li], col = L.c ? colB : colA, pas = faible ? 16 : 9, y0 = H * L.b, am = H * L.a, x, y;
        ctx.beginPath();
        for (x = 0; x <= W + pas; x += pas) {
          var u = x / W * 6.2832;
          y = y0 + am * Math.sin(u * L.f + t * L.s * 2 + L.p) + am * .30 * Math.sin(u * L.f * 1.7 - t * L.s * 1.4 + L.p * 1.7);
          if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',' + Math.min(.9, L.al * 2.2 + .15) + ')'; ctx.lineWidth = 2.4; ctx.shadowColor = 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',.9)'; ctx.shadowBlur = faible ? 0 : 10; ctx.stroke(); ctx.shadowBlur = 0;
        ctx.lineTo(W + pas, H); ctx.lineTo(0, H); ctx.closePath();
        var gv = ctx.createLinearGradient(0, y0 - am * 1.5, 0, H);
        gv.addColorStop(0, 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',' + L.al + ')'); gv.addColorStop(1, 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',0)');
        ctx.fillStyle = gv; ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
      return;
    }
    ctx.clearRect(0, 0, W, H);
    if (actif === 'sakura') {
      var g = ctx.createRadialGradient(W * .5, 0, 10, W * .5, 0, H * .9); g.addColorStop(0, 'rgba(255,170,205,.28)'); g.addColorStop(1, 'rgba(255,170,205,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      for (i = 0; i < parts.length; i++) {
        p = parts[i]; p.ph += p.sw * 3; p.x += p.vx + Math.sin(p.ph) * .6; p.y += p.vy; p.rot += p.vr; p.tilt += .03;
        if (p.y > H + 20 || p.x > W + 30 || p.x < -30) parts[i] = petale(true); else dessinPetale(p);
      }
    } else if (actif === 'neige') {
      ctx.fillStyle = '#fff';
      for (i = 0; i < parts.length; i++) {
        p = parts[i]; p.ph += p.sw * 3; p.x += Math.sin(p.ph) * .5; p.y += p.vy;
        if (p.y > H + 6) { parts[i] = flocon(true); continue; }
        ctx.globalAlpha = p.a; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.28); ctx.fill();
      }
      ctx.globalAlpha = 1;
    } else if (actif === 'braises') {
      var gb = ctx.createLinearGradient(0, H, 0, H * .45); gb.addColorStop(0, 'rgba(255,90,0,.30)'); gb.addColorStop(1, 'rgba(255,90,0,0)');
      ctx.fillStyle = gb; ctx.fillRect(0, H * .45, W, H * .55);
      for (i = 0; i < parts.length; i++) {
        p = parts[i]; p.ph += p.sw * 3; p.fl += .2; p.x += Math.sin(p.ph) * .7; p.y -= p.vy; p.life -= .0035;
        if (p.life <= 0 || p.y < -10) { parts[i] = braise(true); continue; }
        var al = Math.max(0, p.life) * (.65 + .35 * Math.sin(p.fl));
        ctx.globalAlpha = al; ctx.fillStyle = p.life > .6 ? '#ffd27a' : (p.life > .3 ? '#ff8a1f' : '#ff4a12');
        ctx.shadowColor = '#ff7a1a'; ctx.shadowBlur = faible ? 0 : 14;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.28); ctx.fill();
      }
      ctx.shadowBlur = 0; ctx.globalAlpha = 1;
    } else if (actif === 'galaxie') {
      var gg = ctx.createRadialGradient(W * .75, H * .25, 10, W * .75, H * .25, H * .7); gg.addColorStop(0, 'rgba(140,80,255,.30)'); gg.addColorStop(1, 'rgba(140,80,255,0)');
      ctx.fillStyle = gg; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#fff';
      for (i = 0; i < parts.length; i++) {
        p = parts[i]; p.ph += p.v * 3; p.y += p.z * .35; if (p.y > H) { p.y = 0; p.x = rnd(0, W); }
        ctx.globalAlpha = .35 + .65 * Math.abs(Math.sin(p.ph)); ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.28); ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (t > eclair && etoilesFil.length < 2 && Math.random() < .012) etoilesFil.push({ x: rnd(W * .2, W), y: rnd(0, H * .4), vx: -rnd(7, 11), vy: rnd(3, 5), l: 1 });
      for (i = etoilesFil.length - 1; i >= 0; i--) {
        p = etoilesFil[i]; p.x += p.vx; p.y += p.vy; p.l -= .018;
        if (p.l <= 0) { etoilesFil.splice(i, 1); continue; }
        var gs = ctx.createLinearGradient(p.x, p.y, p.x - p.vx * 7, p.y - p.vy * 7); gs.addColorStop(0, 'rgba(255,255,255,' + p.l + ')'); gs.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.strokeStyle = gs; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 7, p.y - p.vy * 7); ctx.stroke();
      }
    } else if (actif === 'lucioles') {
      var rg2 = rgb('#d8ff5a');
      for (i = 0; i < parts.length; i++) {
        p = parts[i]; p.ph += p.pv; p.ang += rnd(-.12, .12); p.x += Math.cos(p.ang) * p.v; p.y += Math.sin(p.ang) * p.v;
        if (p.x < -10) p.x = W + 10; if (p.x > W + 10) p.x = -10; if (p.y < -10) p.y = H + 10; if (p.y > H + 10) p.y = -10;
        var a = .15 + .85 * Math.max(0, Math.sin(p.ph));
        var gl = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 6);
        gl.addColorStop(0, 'rgba(' + rg2[0] + ',' + rg2[1] + ',' + rg2[2] + ',' + (a * .9) + ')'); gl.addColorStop(1, 'rgba(' + rg2[0] + ',' + rg2[1] + ',' + rg2[2] + ',0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 6, 0, 6.28); ctx.fill();
      }
    }
  }

  function boucle(t) {
    raf = 0;
    if (actif === 'aucun' || document.hidden) return;
    raf = requestAnimationFrame(boucle);
    if (t - dernier < pasMs) return;
    dernier = t;
    try { image(t); } catch (e) { arreter(); }
  }
  function demarrer() { if (!raf && actif !== 'aucun' && !document.hidden) { pasMs = faible ? 45 : (actif === 'matrice' ? 55 : (actif === 'vagues' ? 33 : 24)); raf = requestAnimationFrame(boucle); } }
  function arreter() { if (raf) cancelAnimationFrame(raf); raf = 0; }

  (function () { var st = document.createElement('style'); st.textContent = 'html.evo-fond-actif .ps-bg{display:none!important}'; document.head.appendChild(st); })();
  function appliquer(id) {
    if (!LISTE[id]) id = 'aucun';
    if (calme()) id = 'aucun';
    actif = id; arreter();
    document.documentElement.classList.toggle('evo-fond-actif', id !== 'aucun');
    if (id === 'aucun') { if (cv) { ctx.clearRect(0, 0, W, H); cv.style.display = 'none'; } return; }
    creerCanvas(); cv.style.display = 'block'; init(id); demarrer();
  }
  function choixEffectif() {
    var c = lsGet(CLE, '');          // '' = pas de choix du joueur → fond par défaut du site
    if (c && LISTE[c]) return c;
    var d = lsGet(CLE_DEF, 'aucun'); return LISTE[d] ? d : 'aucun';
  }
  function definir(id) {             // choix du joueur
    if (!LISTE[id]) return;
    lsSet(CLE, id); appliquer(id);
    try { window.dispatchEvent(new CustomEvent('evo-fond-change', { detail: id })); } catch (e) {}
  }
  function prevoir(id) { appliquer(id); }               // aperçu sans enregistrer (admin)
  function remettreChoix() { appliquer(choixEffectif()); }

  document.addEventListener('visibilitychange', function () { if (document.hidden) arreter(); else demarrer(); });
  var tmr = 0; window.addEventListener('resize', function () { clearTimeout(tmr); tmr = setTimeout(redim, 200); });
  // quand le joueur change de thème de couleur, la matrice reprend sa couleur
  window.addEventListener('evo-theme-change', function () { if (actif === 'matrice' || actif === 'vagues') init(actif); });

  window.EvoFonds = { liste: LISTE, actuel: function () { return actif; }, choixJoueur: function () { return lsGet(CLE, ''); }, definir: definir, apercu: prevoir, restaurer: remettreChoix };

  function demarrage() {
    appliquer(choixEffectif());
    // fond par défaut choisi par l'admin (Config/fond) — utilisé seulement si le joueur n'a rien choisi
    try {
      if (typeof EvoDB !== 'undefined' && EvoDB.getFast) {
        EvoDB.getFast('Config', 'fond').then(function (d) {
          var v = d && LISTE[d.Id] ? d.Id : 'aucun'; lsSet(CLE_DEF, v);
          if (!lsGet(CLE, '')) appliquer(v);
        }).catch(function () {});
      }
    } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(demarrage, 150); }); else setTimeout(demarrage, 150);
})();
