#!/usr/bin/env node
'use strict';
// Migration v15 -> v16 : déplace Tel / WhatsApp / Email / Tel_norm de Joueurs/{uid} (PUBLIC) vers Joueurs_prive/{uid} (PRIVÉ)
// et crée phone_index. SÛR : par défaut simulation (--apply pour écrire) ; copie d'abord, VÉRIFIE la copie, puis seulement supprime du public.
// Usage (sur TON ordinateur, avec un compte de service) :
//   export GOOGLE_APPLICATION_CREDENTIALS=/chemin/cle-service.json     # NE JAMAIS committer ce fichier
//   node scripts/migrate-private.js            # simulation
//   node scripts/migrate-private.js --apply    # exécution
const core = require('../functions/lib/core');
async function migrate(db, { apply, FieldValue }) {
  const snap = await db.collection('Joueurs').get();
  const out = { scanned: 0, toMigrate: 0, migrated: 0, verified: 0, skippedNoPrivate: 0, conflicts: [] };
  for (const d of snap.docs) {
    out.scanned++;
    const { priv, remove } = core.splitPlayerDoc(d.data());
    if (!remove.length) { out.skippedNoPrivate++; continue; }
    out.toMigrate++;
    if (!apply) continue;
    const privRef = db.doc('Joueurs_prive/' + d.id);
    await privRef.set(Object.assign({}, priv, { MigratedAt: new Date().toISOString() }), { merge: true });
    const key = priv.Tel_norm;
    if (key) {
      const idxRef = db.doc('phone_index/' + key); const idx = await idxRef.get();
      if (!idx.exists || idx.data().uid === d.id) await idxRef.set({ uid: d.id, at: new Date().toISOString() });
      else out.conflicts.push({ uid: d.id, key, owner: idx.data().uid });
    }
    out.migrated++;
    const check = (await privRef.get()).data() || {};
    const ok = Object.keys(priv).every((f) => check[f] === priv[f]);
    if (!ok) { console.error('VÉRIFICATION ÉCHOUÉE, champs publics conservés pour', d.id); continue; }
    out.verified++;
    const del = {}; remove.forEach((f) => { del[f] = FieldValue.delete(); });
    await db.doc('Joueurs/' + d.id).update(del);
  }
  return out;
}
module.exports = { migrate };
if (require.main === module) {
  const admin = require('../functions/node_modules/firebase-admin');
  admin.initializeApp();
  const apply = process.argv.includes('--apply');
  migrate(admin.firestore(), { apply, FieldValue: admin.firestore.FieldValue })
    .then((r) => { console.log(apply ? 'MIGRATION TERMINÉE' : 'SIMULATION (rien écrit)', JSON.stringify(r, null, 2)); })
    .catch((e) => { console.error(e); process.exit(1); });
}
