# EVO — nouveautés v13

## Cartes tournoi
+28 % de largeur, +24 % de hauteur (accueil). Pour ajuster : `index.html`, en haut du bloc CSS, `--carte-fw:1.28` (largeur) et `--carte-fh:1.24` (hauteur).

## Côté joueur (fichier `evo-pro.js`, chargé sur toutes les pages joueur)
- **Filtres** sur l'accueil : Tous / Ouverts / Presque pleins (≥50 %) / Mes favoris.
- **⭐ Favoris** sur chaque carte (gardés sur le téléphone).
- **📅 Ajouter au calendrier** : fichier .ics avec rappel 30 min avant le tournoi.
- **📤 Partage** : feuille de partage du téléphone (WhatsApp en tête), sinon lien WhatsApp.
- **Tirer pour actualiser** (comme une vraie app) + **vibration** légère sur les boutons.
- **📲 Installer l'app** : invite Android, mode d'emploi sur iPhone (réapparaît après 7 jours si fermée).
- **📣 Annonce officielle** : bandeau en haut des pages, fermable.
- Styles « app native » : zones sûres iPhone, pas de rebond, pas de sélection de texte sur les boutons.

## Côté admin (fichier `admin-pro.js`)
- **📊 STATS** : joueurs, tournois, inscriptions, demandes en attente, cagnottes, soldes, inscrits par jeu, top 5 victoires + export CSV joueurs et inscriptions (protégé contre les formules Excel).
- **📣 ANNONCE** : texte, type (info / promo / alerte), lien, durée en jours, retrait en un clic.

## À faire pour que l'annonce marche
Republier `firestore.rules` (nouvelle règle `Config` : lecture publique, écriture admin seulement).

## Prochaines étapes pour une vraie app native (non faites ici, ça demande un compte/serveur)
1. **Application Android/iOS** : emballer le site avec Capacitor (ou TWA/Bubblewrap pour Android) — le site est déjà installable (manifest + icônes).
2. **Notifications push** (tournoi qui démarre, match prêt, paiement validé) : Firebase Cloud Messaging + une Cloud Function.
3. **Paiement automatique** Orange/MTN avec webhook (voir RAPPORT_AUDIT.md) — c'est la priorité n°1 avant de gérer plus d'argent.
4. **Mode hors-ligne** : un service worker propre (l'ancien a été volontairement supprimé car il venait d'une pub).
5. Idées reprises des apps esport : parrainage avec code, saisons/ligues, succès et badges, replays/clips des finales, statistiques par jeu.
