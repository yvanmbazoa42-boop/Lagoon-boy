// EVO ARENA — Arbre de tournoi (élimination directe), partagé admin + client.
// Données : champ texte JSON « Arbre » dans le document du tournoi (collection Tournois).
// {v,size,noms:{id:pseudo},r:[[{a,b,w,sa,sb,bye}…]…]} — a/b = id joueur ou null, w = id du vainqueur.
(function () {
  'use strict';
  const esc = window.escapeHtml || function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  const vide = function () { return { a: null, b: null, w: null, sa: null, sb: null }; };
  const pow2 = function (n) { let s = 2; while (s < n) s *= 2; return s; };
  // ordre des têtes de série standard (1 contre le dernier, etc.) : les BYE vont aux meilleures têtes
  function ordre(size) { let o = [1]; while (o.length < size) { const m = o.length * 2 + 1; o = o.flatMap(function (x) { return [x, m - x]; }); } return o; }
  function melanger(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  const get = function (A, r, i) { return r < 0 ? A.pf : A.r[r][i]; };
  const clone = function (A) { return JSON.parse(JSON.stringify(A)); };

  // Efface le résultat d'un match et tout ce qui en découlait dans les tours suivants
  function vider_(A, r, i) {
    const m = get(A, r, i);
    if (!m || (!m.w && m.sa == null && m.sb == null && !m.bye)) return;
    m.w = null; m.sa = null; m.sb = null; m.bye = 0;
    if (r < 0) return;
    const nx = A.r[r + 1] && A.r[r + 1][i >> 1];
    if (nx) { nx[(i & 1) ? 'b' : 'a'] = null; vider_(A, r + 1, i >> 1); }
    if (r === A.r.length - 2) petite(A);
  }
  // Petite finale : les 2 perdants des demi-finales (3e place)
  function petite(A) {
    if (!A.pf || A.r.length < 2) return;
    const S = A.r[A.r.length - 2], lose = function (m) { return m.w ? (m.a === m.w ? m.b : m.a) : null; };
    const a = lose(S[0]), b = lose(S[1]);
    if (A.pf.a !== a || A.pf.b !== b) { A.pf.a = a; A.pf.b = b; A.pf.w = null; A.pf.sa = null; A.pf.sb = null; }
  }
  // Enregistre un vainqueur (et fait avancer le joueur)
  function poser(A, r, i, w, sa, sb) {
    const m = get(A, r, i);
    if (!m || (w !== m.a && w !== m.b) || !w) throw new Error('Vainqueur invalide pour ce match.');
    if (m.w && m.w !== w) vider_(A, r, i);
    m.w = w; m.sa = (sa === '' || sa == null) ? null : Number(sa); m.sb = (sb === '' || sb == null) ? null : Number(sb);
    if (r < 0) return A;
    if (r === A.r.length - 2) petite(A);
    const nx = A.r[r + 1] && A.r[r + 1][i >> 1];
    if (nx) { const k = (i & 1) ? 'b' : 'a'; if (nx[k] !== w) { nx[k] = w; vider_(A, r + 1, i >> 1); } }
    return A;
  }
  // BYE automatiques : un joueur sans adversaire au 1er tour passe directement
  function auto(A) {
    A.r[0].forEach(function (m, i) {
      const seul = (m.a && !m.b) ? m.a : ((!m.a && m.b) ? m.b : null);
      if (seul) { if (!m.w || m.bye) { poser(A, 0, i, seul); m.bye = 1; } }
      else if (m.bye) vider_(A, 0, i);
    });
    petite(A); A.maj = new Date().toISOString();
    return A;
  }
  // Crée l'arbre pour n joueurs : la taille s'adapte (2, 4, 8, 16, 32, 64, 128…) et les places libres deviennent des BYE
  function construire(joueurs, opt) {
    opt = opt || {};
    if (!joueurs || joueurs.length < 2) throw new Error('Il faut au moins 2 joueurs inscrits.');
    const size = pow2(joueurs.length), noms = {};
    joueurs.forEach(function (j) { noms[j.id] = j.p; });
    const ids = joueurs.map(function (j) { return j.id; });
    const liste = opt.melange === false ? ids : melanger(ids);
    const o = ordre(size), r0 = [];
    for (let i = 0; i < size / 2; i++) { const m = vide(); m.a = liste[o[2 * i] - 1] || null; m.b = liste[o[2 * i + 1] - 1] || null; r0.push(m); }
    const r = [r0];
    for (let n = size / 4; n >= 1; n /= 2) r.push(Array.from({ length: n }, vide));
    const A = { v: 1, size: size, noms: noms, r: r };
    if (opt.petite && size >= 4) A.pf = vide();
    return auto(A);
  }
  function presents(A) { const s = {}; A.r[0].forEach(function (m) { if (m.a) s[m.a] = 1; if (m.b) s[m.b] = 1; }); return s; }
  // Remplace (ou place) un joueur dans une case du 1er tour — possible tant que le match n'est pas joué
  function remplacer(A, i, cote, id, nom) {
    const m = A.r[0][i];
    if (!m) throw new Error('Match introuvable.');
    if (m.w && !m.bye) throw new Error('Ce match est déjà joué : annule d\'abord son résultat.');
    if (id && presents(A)[id]) throw new Error('Ce joueur est déjà dans l\'arbre.');
    if (m.w) vider_(A, 0, i);
    m[cote] = id || null; if (id) A.noms[id] = nom || A.noms[id] || 'Joueur';
    return auto(A);
  }
  // Ajoute un nouvel inscrit dans une place libre (BYE) ; renvoie false s'il n'y a plus de place
  function ajouter(A, id, nom) {
    if (presents(A)[id]) return true;
    for (let i = 0; i < A.r[0].length; i++) {
      const m = A.r[0][i];
      if (!m.a || !m.b) { try { remplacer(A, i, m.a ? 'b' : 'a', id, nom); return true; } catch (e) { /* case suivante */ } }
    }
    return false;
  }
  function nomTour(A, r) { if (r < 0) return 'PETITE FINALE (3e PLACE)'; const m = A.r[r].length; return m === 1 ? 'FINALE' : m === 2 ? 'DEMI-FINALES' : m === 4 ? 'QUARTS DE FINALE' : '1/' + m + ' DE FINALE'; }
  function stats(A) {
    const n = Object.keys(presents(A)).length; let faits = 0;
    A.r.forEach(function (rd) { rd.forEach(function (m) { if (m.w && !m.bye) faits++; }); });
    if (A.pf && A.pf.w) faits++;
    const champ = A.r[A.r.length - 1][0].w || null;
    return { joueurs: n, total: Math.max(0, n - 1) + ((A.pf && n >= 4) ? 1 : 0), faits: faits, champion: champ, tours: A.r.length };
  }
  // Situation d'un joueur : prochain match, éliminé, champion
  function pour(A, id) {
    if (!id || !presents(A)[id]) return null;
    if (A.r[A.r.length - 1][0].w === id) return { etat: 'champion' };
    if (A.pf && (A.pf.a === id || A.pf.b === id)) {
      if (A.pf.w) return { etat: A.pf.w === id ? 'troisieme' : 'quatrieme' };
      return A.pf.a && A.pf.b ? { etat: 'prochain', r: -1, i: 0, contre: A.pf.a === id ? A.pf.b : A.pf.a } : { etat: 'attente', r: -1, i: 0 };
    }
    for (let r = 0; r < A.r.length; r++) for (let i = 0; i < A.r[r].length; i++) {
      const m = A.r[r][i];
      if ((m.a === id || m.b === id) && !m.w) return m.a && m.b ? { etat: 'prochain', r: r, i: i, contre: m.a === id ? m.b : m.a } : { etat: 'attente', r: r, i: i };
      if (m.w && m.w !== id && (m.a === id || m.b === id)) return { etat: 'elimine', r: r };
    }
    return null;
  }
  function planifier(A, r, i, h) { const m = get(A, r, i); if (!m) throw new Error('Match introuvable.'); m.h = h || null; return A; }
  function podium(A) {
    const F = A.r[A.r.length - 1][0], c = F.w || null;
    return { c: c, f: c ? (F.a === c ? F.b : F.a) : null, t: (A.pf && A.pf.w) || null };
  }
  const fdate = function (h) { try { return new Date(h).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } };
  function lire(doc) { try { const A = JSON.parse(doc && doc.Arbre); return (A && A.r && A.r.length) ? A : null; } catch (e) { return null; } }

  // ---------- Affichage ----------
  function css() {
    if (document.getElementById('abCss')) return;
    const s = document.createElement('style'); s.id = 'abCss';
    s.textContent = '.ab-wrap{overflow:auto;-webkit-overflow-scrolling:touch;padding:8px 4px 20px}'
      + '.ab{display:flex;align-items:stretch;width:max-content;--ln:rgba(var(--c1-rgb,0,255,136),.5)}'
      + '.ab .rd{display:flex;flex-direction:column;width:178px;flex:none}'
      + '.ab .th{height:28px;text-align:center;font-size:.58rem;letter-spacing:1px;color:var(--c1,#00ff88);font-weight:800;white-space:nowrap}'
      + '.ab .mws{flex:1;display:flex;flex-direction:column}'
      + '.ab .mw{flex:1;min-height:78px;display:flex;align-items:center;position:relative;padding:0 16px}'
      + '.ab .mw::after{content:"";position:absolute;right:0;top:50%;width:16px;border-top:2px solid var(--ln)}'
      + '.ab .mw:nth-child(odd)::before{content:"";position:absolute;right:0;top:50%;height:50%;border-right:2px solid var(--ln)}'
      + '.ab .mw:nth-child(even)::before{content:"";position:absolute;right:0;bottom:50%;height:50%;border-right:2px solid var(--ln)}'
      + '.ab .rd.fin .mw::before,.ab .rd.chp .mw::before{display:none}.ab .rd.chp .mw::after{display:none}'
      + '.ab .rd:not(:first-child) .m::before,.ab .tr::before{content:"";position:absolute;left:-16px;top:50%;width:16px;border-top:2px solid var(--ln)}'
      + '.ab .m{position:relative;width:100%;background:rgba(var(--bg-rgb,5,5,16),.94);border:1px solid rgba(var(--c1-rgb,0,255,136),.28);border-radius:10px;overflow:visible}'
      + '.ab .m.ed{cursor:pointer}.ab .m.pret{border-color:#fbbf24;animation:abp 1.6s infinite}'
      + '@keyframes abp{50%{box-shadow:0 0 12px rgba(251,191,36,.55)}}'
      + '.ab .pl{display:flex;justify-content:space-between;align-items:center;gap:6px;padding:7px 9px;font-size:.72rem;color:#cbd5e1;border-bottom:1px solid rgba(255,255,255,.07)}'
      + '.ab .pl:last-child{border-bottom:0}.ab .pl.w{background:rgba(var(--c1-rgb,0,255,136),.18);color:#fff;font-weight:700}'
      + '.ab .pl.l{opacity:.45;text-decoration:line-through}.ab .pl.vd{color:#64748b;font-style:italic}'
      + '.ab .pl.me{box-shadow:inset 3px 0 var(--c1,#00ff88)}'
      + '.ab .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ab .sc{color:var(--c1,#00ff88);font-size:.75rem}'
      + '.ab .dt{font-size:.58rem;color:#fbbf24;padding:3px 9px;background:rgba(251,191,36,.1);text-align:center;border-radius:0 0 9px 9px}'
      + '.ab .m.hit{box-shadow:0 0 0 2px #38bdf8,0 0 14px rgba(56,189,248,.6)}.ab .pf2{margin:6px 0 0 0}'
      + '.ab .rd.pf .mw::before,.ab .rd.pf .mw::after,.ab .rd.pf .m::before{display:none}'
      + '.ab .tr{position:relative;width:100%;text-align:center;padding:12px 6px;border:2px solid #fbbf24;border-radius:12px;background:rgba(251,191,36,.08);color:#fbbf24;font-size:.62rem;letter-spacing:1px}'
      + '.ab .tr .big{font-size:1.9rem;line-height:1.1}.ab .tr b{display:block;margin-top:4px;color:#fff;font-size:.85rem;letter-spacing:0;overflow:hidden;text-overflow:ellipsis}';
    document.head.appendChild(s);
  }
  function ligne(A, m, k, r, moi) {
    const id = m[k], s = k === 'a' ? m.sa : m.sb;
    let c = 'pl';
    if (id && m.w === id) c += ' w'; else if (id && m.w) c += ' l';
    if (!id) c += ' vd'; if (moi && id === moi) c += ' me';
    return '<div class="' + c + '"><span class="nm">' + (id ? esc(A.noms[id] || 'Joueur') : (r === 0 ? 'BYE' : 'En attente')) + '</span>' + (s != null && !isNaN(s) ? '<b class="sc">' + esc(s) + '</b>' : '') + '</div>';
  }
  function carte(A, m, r, i, opt) {
    const pret = m.a && m.b && !m.w, q = (opt.cherche || '').toLowerCase();
    const hit = q && ((m.a && (A.noms[m.a] || '').toLowerCase().indexOf(q) >= 0) || (m.b && (A.noms[m.b] || '').toLowerCase().indexOf(q) >= 0));
    return '<div class="mw"><div class="m' + (opt.admin ? ' ed' : '') + (pret ? ' pret' : '') + (hit ? ' hit' : '') + '" data-r="' + r + '" data-i="' + i + '">' + ligne(A, m, 'a', r, opt.moi) + ligne(A, m, 'b', r, opt.moi) + (m.h ? '<div class="dt">📅 ' + fdate(m.h) + '</div>' : '') + '</div></div>';
  }
  // rendre(conteneur, arbre, {admin:bool, moi:id, onMatch:(r,i)=>…})
  function rendre(el, A, opt) {
    opt = opt || {}; css();
    let h = '<div class="ab-wrap"><div class="ab">';
    A.r.forEach(function (rd, r) {
      h += '<div class="rd' + (r === A.r.length - 1 ? ' fin' : '') + '"><div class="th">' + nomTour(A, r) + '</div><div class="mws">';
      rd.forEach(function (m, i) {
        h += carte(A, m, r, i, opt);
      });
      h += '</div></div>';
    });
    const ch = A.r[A.r.length - 1][0].w;
    h += '<div class="rd chp"><div class="th">CHAMPION</div><div class="mws"><div class="mw"><div class="tr"><div class="big">🏆</div>VAINQUEUR<b>' + (ch ? esc(A.noms[ch] || 'Joueur') : '?') + '</b></div></div></div></div>';
    h += '</div>';
    if (A.pf) h += '<div class="ab pf2"><div class="rd pf"><div class="th">🥉 PETITE FINALE (3e PLACE)</div><div class="mws">' + carte(A, A.pf, -1, 0, opt) + '</div></div></div>';
    el.innerHTML = h + '</div>';
    if (opt.onMatch) el.querySelector('.ab-wrap').onclick = function (e) {
      const m = e.target.closest && e.target.closest('.m'); if (m) opt.onMatch(+m.dataset.r, +m.dataset.i);
    };
  }
  // Image PNG de l'arbre (à envoyer sur WhatsApp / Statut)
  function image(A, titre) {
    const W = 210, H = 56, G = 70, nr = A.r.length, n0 = A.r[0].length;
    const cv = document.createElement('canvas'); cv.width = nr * (W + 40) + W + 80; cv.height = n0 * G + 150 + (A.pf ? 100 : 0);
    const x = cv.getContext('2d'), cs = getComputedStyle(document.documentElement);
    const c1 = (cs.getPropertyValue('--c1') || '').trim() || '#00ff88', nom = function (id, r) { return id ? (A.noms[id] || 'Joueur') : (r === 0 ? 'BYE' : '…'); };
    x.fillStyle = '#050510'; x.fillRect(0, 0, cv.width, cv.height);
    x.fillStyle = c1; x.font = 'bold 24px sans-serif'; x.fillText('🏆 ' + (titre || 'EVO ARENA'), 30, 36);
    const cy = function (r, i) { return 90 + (i + .5) * G * Math.pow(2, r); };
    const box = function (px, py, m, r) {
      x.fillStyle = '#0d0d24'; x.strokeStyle = c1; x.lineWidth = 1.5; x.beginPath(); x.roundRect(px, py, W, H, 8); x.fill(); x.stroke();
      [['a', 0], ['b', 1]].forEach(function (k) {
        const id = m[k[0]], win = id && m.w === id; x.font = (win ? 'bold ' : '') + '14px sans-serif'; x.fillStyle = win ? c1 : (id && m.w ? '#64748b' : '#e2e8f0');
        x.fillText(String(nom(id, r)).slice(0, 20), px + 10, py + 19 + k[1] * 24);
        const sc = k[0] === 'a' ? m.sa : m.sb; if (sc != null) { x.textAlign = 'right'; x.fillText(String(sc), px + W - 10, py + 19 + k[1] * 24); x.textAlign = 'left'; }
      });
    };
    A.r.forEach(function (rd, r) {
      const px = 30 + r * (W + 40);
      x.fillStyle = c1; x.font = 'bold 12px sans-serif'; x.fillText(nomTour(A, r), px, 78);
      rd.forEach(function (m, i) {
        const py = cy(r, i) - H / 2; box(px, py, m, r);
        x.strokeStyle = c1; x.lineWidth = 1.5; x.beginPath(); x.moveTo(px + W, cy(r, i)); x.lineTo(px + W + 20, cy(r, i));
        if (r < nr - 1) { const j = (i >> 1), yy = cy(r + 1, j); x.lineTo(px + W + 20, yy); x.lineTo(px + W + 40, yy); } else x.lineTo(px + W + 40, cy(r, i));
        x.stroke();
      });
    });
    const ch = A.r[nr - 1][0].w, px = 30 + nr * (W + 40), y = cy(nr - 1, 0);
    x.strokeStyle = '#fbbf24'; x.lineWidth = 2; x.beginPath(); x.roundRect(px, y - 40, W, 80, 12); x.stroke();
    x.fillStyle = '#fbbf24'; x.font = 'bold 22px sans-serif'; x.textAlign = 'center'; x.fillText('🏆 CHAMPION', px + W / 2, y - 8);
    x.fillStyle = '#fff'; x.font = 'bold 16px sans-serif'; x.fillText(ch ? String(A.noms[ch] || '').slice(0, 20) : '?', px + W / 2, y + 20); x.textAlign = 'left';
    if (A.pf) { x.fillStyle = c1; x.font = 'bold 12px sans-serif'; x.fillText(nomTour(A, -1), 30, n0 * G + 120); box(30, n0 * G + 130, A.pf, 1); }
    x.fillStyle = '#475569'; x.font = '11px sans-serif'; x.fillText('EVO ARENA', cv.width - 100, cv.height - 10);
    return cv;
  }
  function telecharger(A, titre) {
    const cv = image(A, titre);
    cv.toBlob(function (b) {
      const f = new File([b], 'arbre-evo-arena.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: titre || 'Arbre EVO ARENA' }).catch(function () {});
      else { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = f.name; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000); }
    }, 'image/png');
  }
  window.Arbre = { planifier: planifier, podium: podium, fdate: fdate, image: image, telecharger: telecharger, construire: construire, poser: poser, vider: function (A, r, i) { vider_(A, r, i); return A; }, remplacer: remplacer, ajouter: ajouter, auto: auto, stats: stats, pour: pour, nomTour: nomTour, lire: lire, rendre: rendre, clone: clone, presents: presents };
})();
