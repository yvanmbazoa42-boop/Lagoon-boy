# EVO WORLD GAMER — rapport d'audit (29/10/2026)

Audit réalisé sur le code du zip « Darline.zip » + la page publique https://evoworl-gamearena.wasmer.app/.
Je n'ai PAS pu tester le site en live avec de vrais comptes/paiements : tout ce qui est marqué « à tester » doit être vérifié par toi.

## ✅ Corrigé dans ce zip
1. XSS admin : pseudos, numéros WhatsApp, liens de salle, mots de passe de salle, liens live affichés sans échappement (un joueur pouvait injecter du code qui s'exécute dans le navigateur de l'admin).
2. Liens `javascript:` bloqués (fonction `lienSur`) pour les liens de salle et logos.
3. Gagnant d'un match : refuse si le match est déjà terminé (double clic = double vie retirée avant), vérifie que le gagnant est bien un des 2 joueurs, et utilise des compteurs atomiques Firestore (`increment`) au lieu de lire puis réécrire.
4. Validation d'une inscription : relit le tournoi à jour, refuse si complet, évite le doublon « demande déjà traitée », et n'écrase plus le pseudo/numéro officiel du joueur avec ce qu'il a tapé dans le formulaire.
5. Zoom bloqué (user-scalable=no) retiré sur toutes les pages (accessibilité).
6. Nouveau `firestore.rules` : un joueur ne peut plus modifier Solde, Vies, Statut, abonnement « sans pub », etc. ; seuls les admins écrivent les tournois/matchs/live ; messages privés lisibles uniquement par expéditeur/destinataire.

## ⚠️ Ce que le code ne peut PAS corriger (indispensable avant de gérer de l'argent réel)
1. **Paiements manuels** : il n'y a aucune vérification automatique. Le joueur clique « payer », le code USSD s'ouvre, et un admin valide à la main. Aucune preuve de paiement n'est stockée → litiges, fraude (fausse déclaration de paiement), erreurs humaines. Solution : une API de paiement avec webhook + Cloud Functions qui valident l'inscription seulement après confirmation du paiement.
2. **Gains / retraits** : tout calcul d'argent doit être fait côté serveur (Cloud Functions, offre Blaze). Même avec les nouvelles règles, un admin compromis peut tout faire.
3. **Données personnelles publiques** : la collection Joueurs est lisible par tout le monde (classements) et contient téléphone, WhatsApp, e-mail. Il faut séparer en une fiche publique (pseudo, avatar, points) et une fiche privée.
4. **Question secrète admin** : vérifiée côté navigateur seulement → ce n'est pas une vraie sécurité. Utilise l'authentification + la collection `admins` (déjà en place), ou une double authentification.
5. **Demandes d'inscription** stockées en JSON dans le document tournoi : deux joueurs qui s'inscrivent en même temps peuvent s'écraser (une demande perdue). À migrer vers une sous-collection.
6. **Appwrite** : vérifier les permissions du bucket (taille et formats autorisés) pour éviter les abus.
7. ~~Script publicitaire tiers~~ : retiré.
8. **Comptes sans e-mail** (numero@evoarena.cm) : impossible de récupérer le mot de passe par e-mail.
9. **Mention « DE 13 À 18+ ans »** sur un site où l'on paie pour jouer et gagner de l'argent : risque juridique (mineurs + jeux d'argent). Fais vérifier la réglementation camerounaise par un juriste ; je ne suis pas avocat.
10. Pages Confidentialité / Conditions : liens vides (`#`). Obligatoire pour un site qui gère de l'argent et des données personnelles.
11. Clé API Firebase visible : normal pour Firebase, mais seulement sûre si les règles Firestore sont strictes (d'où `firestore.rules`) et si tu ajoutes App Check.

## 🔎 À tester par toi après mise en ligne
- Inscription/connexion (numéro, e-mail, Google, SMS) sur le domaine wasmer : ajoute `evoworl-gamearena.wasmer.app` dans Firebase → Authentication → Authorized domains, sinon Google/SMS échouent.
- Publier `firestore.rules`, puis tester avec un compte joueur normal : il ne doit pas pouvoir changer son Solde.
- Test avec 2 téléphones : deux inscriptions simultanées au même tournoi, double clic sur « gagnant ».

---
## ⚡ Mise à jour vitesse (affichage instantané)
Causes trouvées : (1) le site attendait la réponse de Firebase avant de savoir si tu es connecté, donc il affichait d'abord « CONNEXION / INSCRIPTION » ; (2) il refaisait une requête pour lire ta fiche avant d'afficher ton nom ; (3) sur le profil, TOUT erreur de chargement (même réseau lent) rouvrait l'écran de connexion ; (4) classement, clans et posts bloquaient l'affichage tant que 500 joueurs n'étaient pas téléchargés ; (5) logo de démarrage de 1,8 s.
Corrections : pastille du joueur affichée dès la 1re image depuis la mémoire de l'appareil ; ta fiche, les tournois, classements, clans, posts affichés immédiatement depuis la copie gardée sur l'appareil puis mis à jour en silence seulement si quelque chose a changé ; profil masqué (au lieu de montrer de faux zéros) jusqu'à son 1er affichage ; l'écran de connexion ne s'ouvre plus qu'en cas de vraie déconnexion ; classement/clan du profil chargés en arrière-plan ; SDK Firebase préchargé en parallèle ; logo de démarrage supprimé pour un joueur connecté et réduit à 0,8 s pour les autres. Les copies sont effacées à la déconnexion. Les messages privés ne sont jamais copiés sur l'appareil.
Limite : la toute première ouverture d'un appareil (aucune copie) reste limitée par le téléchargement de Firebase.

---
## 🔒 Mise à jour sécurité & fiabilité (29/10/2026)
**Logo de démarrage : 5 secondes** (une fois par ouverture de l'app, pour tout le monde). Constante `DUREE_MS` dans splash.js.

**Injection de code (XSS) — corrigée sur toutes les pages**
- ~60 endroits affichaient des données de joueurs sans protection (pseudos, noms de clans, avatars, images de posts, couleurs de clan, chat live, liste Top 100, admin). Un joueur pouvait enregistrer un faux « avatar » ou pseudo contenant du code qui s'exécutait chez les autres, y compris chez l'admin → vol de session/argent.
- Nouveaux outils communs (evo-config.js) : `escapeHtml`, `urlSure/urlBrute` (n'accepte que http(s) ou image data:), `couleurSure`, `jsArg` (arguments sûrs dans les boutons). Les boutons WhatsApp/Copier de l'admin n'embarquent plus de texte brut.
- En-tête de sécurité sur toutes les pages : pas d'objets embarqués, pas de redirection de formulaires vers d'autres sites, politique de référent.

**Inscription** : pseudo 3–50 caractères sans caractères dangereux, mot de passe 8 caractères minimum, numéro valide.

**Pannes / lenteurs** : plus de « Chargement… » infini (15 s maximum puis 1 nouvel essai automatique), message clair si le réseau coupe, plus d'écran blanc sur erreur imprévue.

**Coûts Firebase (quota gratuit = 50 000 lectures/jour)** : les rafraîchissements automatiques s'arrêtent quand l'app est en arrière-plan ; fréquences réduites (classement 60 s, accueil 90 s, clans 60 s) ; la liste des 500 joueurs de la page Live n'est plus rechargée toutes les 10 s mais toutes les 2 min ; les posts/statuts sont triés par le serveur (100 lectures au lieu de jusqu'à 2000).

**Règles Firestore renforcées** (firestore.rules à republier) : limites de taille sur tous les textes, un joueur ne peut publier/supprimer que ses propres posts et statuts, le destinataire d'un message ne peut que le marquer « lu », seuls les admins suppriment des clans.

**Secrets** : aucun secret serveur dans le code (la clé Firebase est publique par conception). À noter : le numéro Mobile Money et l'identifiant du bucket Appwrite sont visibles par tous (inévitable côté navigateur). Active **Firebase App Check** et ajoute des **restrictions de domaine sur la clé API** (Google Cloud → Identifiants → restrictions HTTP referrers : evoworl-gamearena.wasmer.app) pour empêcher qu'on utilise ta clé depuis un autre site.

**Toujours à faire côté serveur** (voir plus haut) : validation automatique des paiements, calcul des gains, séparation des données privées. Sans cela, le site ne doit pas gérer de grosses sommes.
