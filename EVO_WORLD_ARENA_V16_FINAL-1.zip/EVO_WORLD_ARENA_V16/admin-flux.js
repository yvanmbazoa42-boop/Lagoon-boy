// EVO ARENA — onglet admin 📺 FLUX (v14k) : diffusion de l'écran des joueurs vers Régie Live.
//  • À la création d'un match, un flux Cloudflare Stream est créé pour chaque joueur (via le Worker, voir serveur/LISEZMOI_FLUX.md)
//    et le message WhatsApp contient le lien « 📺 Diffuse ton écran » (page stream.html → plugin de l'application).
//  • Ici : état de chaque flux en direct, aperçu, bouton « Copier le lien Régie Live » (lien HLS .m3u8), publication sur la page live du match.
// Chargé après admin-pro2.js. Données : collection « flux » (voir firestore.rules).
(function () {
  'use strict';
  var tabs = document.querySelector('.tabs'); if (!tabs) return;
  var apres = document.getElementById('payout') || tabs.nextElementSibling;
  var COL = 'flux';
  var LS_URL = 'evo_flux_worker', LS_SECRET = 'evo_flux_secret';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(m, t) { try { showToast(m, t || 'info'); } catch (e) {} }
  function maintenant() { return new Date().toISOString(); }
  function lsGet(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function heure(iso) { try { return new Date(iso).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }
  function copier(texte, ok) {
    function repli() { var t = document.createElement('textarea'); t.value = texte; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); toast(ok || '📋 Copié', 'success'); } catch (e) { toast('Copie impossible : ' + texte, 'error'); } t.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(texte).then(function () { toast(ok || '📋 Copié', 'success'); }, repli); else repli();
  }
  function journal(action, cible, detail) {
    try { var adm = (typeof adminUserId !== 'undefined' && adminUserId) ? adminUserId : ''; EvoDB.create('admin_logs', EvoDB.newId(), { Admin: adm, Action: action, Cible: String(cible || '').slice(0, 80), Detail: String(detail || '').slice(0, 300), Date: maintenant() }).catch(function () {}); } catch (e) {}
  }
  function db() { return firebase.firestore(); }

  // ------------------------------------------------------------------ appel du Worker
  function worker(route, corps) {
    var base = lsGet(LS_URL).replace(/\/+$/, ''), secret = lsGet(LS_SECRET);
    if (!base || !secret) return Promise.reject(new Error('Configure d\'abord l\'adresse du Worker et le mot secret (onglet 📺 FLUX).'));
    return fetch(base + route, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ secret: secret }, corps)) })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (j) { if (!j.ok) throw new Error(j.erreur || 'Erreur du Worker'); return j; });
  }

  // ------------------------------------------------------------------ API pour creerMatch (admin.html)
  // Crée un flux par joueur et renvoie { idJoueur: lienJoueur } ; ne bloque jamais la création du match.
  async function creerPourMatch(matchId, matchNom, joueurs) {
    var liens = {};
    if (!lsGet(LS_URL) || !lsGet(LS_SECRET)) { toast('ℹ️ Flux d\'écran non configuré : match créé sans lien de diffusion (onglet 📺 FLUX).', 'info', 5000); return liens; }
    for (var i = 0; i < joueurs.length; i++) {
      var j = joueurs[i];
      try {
        var r = await worker('/creer', { nom: (matchNom || 'Match') + ' — ' + (j.nom || j.id) });
        var id = EvoDB.newId(), n = maintenant();
        await db().collection(COL).doc(id).set({ Match_id: matchId, Match_nom: matchNom || '', Joueur_id: j.id, Joueur_nom: j.nom || '', Uid: r.uid, Ingest: r.ingest, Cle: r.cle, Hls: r.hls, Etat: 'attente', Date: n, _createdAt: n, _updatedAt: n });
        liens[j.id] = location.origin + location.pathname.replace(/[^/]*$/, '') + 'stream.html?f=' + id;
      } catch (e) { toast('⚠️ Flux non créé pour ' + (j.nom || j.id) + ' : ' + ((e && e.message) || 'erreur'), 'error', 6000); }
    }
    if (Object.keys(liens).length) journal('Flux d\'écran créés', matchNom || matchId, Object.keys(liens).length + ' joueur(s)');
    return liens;
  }

  // ------------------------------------------------------------------ onglet
  var st = document.createElement('style');
  st.textContent =
    '.fx-carte{background:rgba(255,255,255,.04);border-radius:12px;padding:12px;margin:8px 0}' +
    '.fx-tete{display:flex;align-items:center;gap:8px;justify-content:space-between}.fx-tete b{color:#e0f2fe}' +
    '.fx-badge{font-size:.66rem;font-weight:800;border-radius:20px;padding:3px 9px;border:1px solid currentColor;white-space:nowrap}' +
    '.fx-sous{color:#64748b;font-size:.68rem;margin:4px 0}' +
    '.fx-lien{width:100%;box-sizing:border-box;margin:6px 0;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.4);color:#93c5fd;font-size:.68rem}' +
    '.fx-btns{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}' +
    '.fx-btn{border:0;border-radius:10px;padding:9px 11px;font:inherit;font-weight:800;font-size:.74rem;cursor:pointer;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000}' +
    '.fx-btn.sec{background:rgba(255,255,255,.09);color:#e0f2fe}.fx-btn.rouge{background:#dc2626;color:#fff}' +
    '.fx-champ{width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid rgba(var(--c1-rgb,0,255,136),.3);background:rgba(0,0,0,.4);color:#e0f2fe;font-size:16px;margin:6px 0}' +
    '.fx-prev{width:100%;max-height:50vh;background:#000;border-radius:10px;margin-top:8px}';
  document.head.appendChild(st);

  var tabEl = document.createElement('div'); tabEl.className = 'tab'; tabEl.textContent = '📺 FLUX';
  tabEl.onclick = function (ev) { openTab('fluxAdmin', ev); ouvrir(); };
  tabs.appendChild(tabEl);
  var cont = document.createElement('div'); cont.id = 'fluxAdmin'; cont.className = 'tab-content';
  cont.innerHTML =
    '<div class="section"><h2>📺 DIFFUSION DES JOUEURS → RÉGIE LIVE</h2>' +
    '<div class="info-box">Quand tu crées un match, chaque joueur reçoit dans son message WhatsApp un lien « Diffuse ton écran ». ' +
    'Il l\'ouvre dans l\'application EVO ARENA, accepte les conditions, et son écran part en direct. Ici tu copies le <b>lien Régie Live</b> (HLS) de chaque joueur.</div>' +
    '<div id="fxListe"><div style="color:#555;text-align:center;padding:12px">Aucun flux pour le moment.</div></div>' +
    '<details style="margin-top:16px"><summary style="cursor:pointer;font-weight:800;color:var(--c1,#00ff88);font-size:.85rem">⚙️ CONFIGURATION (une seule fois)</summary>' +
    '<div class="info-box" style="margin-top:8px">Adresse du Worker Cloudflare et mot secret : voir <b>serveur/LISEZMOI_FLUX.md</b>. Ils restent sur cet appareil uniquement.</div>' +
    '<input class="fx-champ" id="fxUrl" type="url" placeholder="https://evo-flux.ton-compte.workers.dev" autocomplete="off">' +
    '<input class="fx-champ" id="fxSecret" type="password" placeholder="Mot secret (ADMIN_SECRET)" autocomplete="off">' +
    '<button class="fx-btn" type="button" id="fxSave">💾 ENREGISTRER</button>' +
    '<button class="fx-btn sec" type="button" id="fxTest" style="margin-left:6px">🧪 TESTER</button></details></div>';
  (apres && apres.parentNode ? apres.parentNode : document.body).appendChild(cont);

  var ETATS = { attente: ['⏳ Lien envoyé', '#f59e0b'], en_direct: ['🔴 EN DIRECT', '#ef4444'], termine: ['⚪ Terminé', '#94a3b8'], echec: ['❌ Échec', '#f87171'] };
  var unListe = null, docs = {}, apercu = null;

  function arreterApercu() { if (apercu) { try { apercu.hls && apercu.hls.destroy(); } catch (e) {} apercu = null; } }
  function chargerHls(cb) {
    if (window.Hls) { cb(); return; }
    var s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.17/hls.min.js'; s.onload = cb; s.onerror = function () { toast('Lecteur HLS indisponible (réseau)', 'error'); };
    document.head.appendChild(s);
  }
  function voirApercu(carte, d) {
    arreterApercu();
    var ancien = document.querySelectorAll('.fx-prev'); [].forEach.call(ancien, function (x) { x.remove(); });
    var v = document.createElement('video'); v.className = 'fx-prev'; v.controls = true; v.muted = true; v.autoplay = true; v.playsInline = true;
    carte.appendChild(v);
    if (v.canPlayType('application/vnd.apple.mpegurl')) { v.src = d.Hls; apercu = { v: v }; return; }
    chargerHls(function () {
      if (!window.Hls || !Hls.isSupported()) { toast('Aperçu non supporté ici : colle le lien dans Régie Live', 'info'); return; }
      var h = new Hls({ lowLatencyMode: false }); h.loadSource(d.Hls); h.attachMedia(v); apercu = { v: v, hls: h };
      h.on(Hls.Events.ERROR, function (e, data) { if (data && data.fatal) toast('Pas d\'image pour le moment (le joueur ne diffuse pas encore ?)', 'info'); });
    });
  }

  function rendre() {
    var z = document.getElementById('fxListe'); if (!z) return;
    arreterApercu(); z.textContent = '';
    var l = Object.keys(docs).map(function (k) { return docs[k]; }).sort(function (a, b) { return String(b.Date || '').localeCompare(String(a.Date || '')); }).slice(0, 40);
    if (!l.length) { z.innerHTML = '<div style="color:#555;text-align:center;padding:12px">Aucun flux pour le moment.</div>'; return; }
    l.forEach(function (d) {
      var e = ETATS[d.Etat] || ETATS.attente, c = document.createElement('div'); c.className = 'fx-carte';
      c.innerHTML = '<div class="fx-tete"><b>' + esc(d.Joueur_nom || d.id) + '</b><span class="fx-badge" style="color:' + e[1] + '">' + e[0] + '</span></div>' +
        '<div class="fx-sous">' + esc(d.Match_nom || '') + ' · ' + esc(heure(d.Date)) + (d.Accepte_le ? ' · conditions acceptées ' + esc(heure(d.Accepte_le)) : '') + '</div>' +
        '<input class="fx-lien" readonly value="' + esc(d.Hls) + '">';
      var b = document.createElement('div'); b.className = 'fx-btns'; c.appendChild(b);
      function bt(txt, cls, f) { var x = document.createElement('button'); x.type = 'button'; x.className = 'fx-btn ' + cls; x.textContent = txt; x.onclick = f; b.appendChild(x); }
      bt('📋 Copier le lien Régie Live', '', function () { copier(d.Hls, '📋 Lien Régie Live copié'); });
      bt('▶ Aperçu', 'sec', function () { voirApercu(c, d); });
      bt('📱 Lien du joueur', 'sec', function () { copier(location.origin + location.pathname.replace(/[^/]*$/, '') + 'stream.html?f=' + d.id, '📋 Lien du joueur copié'); });
      if (d.Match_id) bt('🎯 Publier sur la page live', 'sec', function () {
        EvoDB.update(COLLECTIONS.MATCHES, d.Match_id, { Lien_stream: d.Hls }).then(function () { journal('Flux publié en live', d.Match_nom || d.Match_id, d.Joueur_nom); toast('✅ Lien publié sur la page live du match', 'success'); }).catch(function (er) { toast('❌ ' + ((er && er.message) || 'Erreur'), 'error'); });
      });
      bt('🗑', 'rouge', function () {
        if (!confirm('Supprimer ce flux ? Le lien du joueur et le lien Régie Live cesseront de fonctionner.')) return;
        worker('/supprimer', { uid: d.Uid }).catch(function () { /* déjà supprimé chez Cloudflare : on retire quand même la fiche */ }).then(function () { return db().collection(COL).doc(d.id).delete(); })
          .then(function () { journal('Flux supprimé', d.Match_nom || '', d.Joueur_nom); }).catch(function (er) { toast('❌ ' + ((er && er.message) || 'Erreur'), 'error'); });
      });
      z.appendChild(c);
    });
  }
  function ecouter() {
    if (unListe) return;
    try {
      unListe = db().collection(COL).onSnapshot(function (qs) {
        qs.docChanges().forEach(function (ch) {
          var d = ch.doc.data(); d.id = ch.doc.id;
          if (ch.type === 'removed') { delete docs[d.id]; return; }
          var av = docs[d.id]; docs[d.id] = d;
          if (av && av.Etat !== d.Etat && d.Etat === 'en_direct') toast('🔴 ' + (d.Joueur_nom || 'Un joueur') + ' diffuse son écran', 'success', 6000);
        });
        majBadge(); rendre();
      }, function (e) {
        unListe = null; var z = document.getElementById('fxListe');
        if (z) z.innerHTML = '<div style="color:#f59e0b;text-align:center;padding:12px">⚠️ ' + esc((e && e.code === 'permission-denied') ? 'Permission refusée : publie les nouvelles règles Firestore (firestore.rules v14k).' : (e && e.message) || 'Erreur') + '</div>';
      });
    } catch (e) { unListe = null; }
  }
  function majBadge() {
    var n = 0; Object.keys(docs).forEach(function (k) { if (docs[k].Etat === 'en_direct') n++; });
    tabEl.textContent = '📺 FLUX';
    if (n) { var s = document.createElement('span'); s.style.cssText = 'display:inline-block;min-width:16px;padding:0 5px;margin-left:5px;border-radius:9px;background:#ef4444;color:#fff;font-size:.62rem;line-height:16px;text-align:center'; s.textContent = n; tabEl.appendChild(s); }
  }
  function ouvrir() {
    document.getElementById('fxUrl').value = lsGet(LS_URL); document.getElementById('fxSecret').value = lsGet(LS_SECRET);
    ecouter();
  }
  document.getElementById('fxSave').onclick = function () {
    var u = document.getElementById('fxUrl').value.trim(), s = document.getElementById('fxSecret').value.trim();
    if (!/^https:\/\//i.test(u) || s.length < 8) { toast('⚠️ Adresse https du Worker + mot secret (8 caractères min)', 'error'); return; }
    lsSet(LS_URL, u); lsSet(LS_SECRET, s); toast('✅ Configuration enregistrée', 'success');
  };
  document.getElementById('fxTest').onclick = function () {
    document.getElementById('fxSave').onclick();
    worker('/creer', { nom: 'TEST EVO ARENA' }).then(function (r) { toast('✅ Worker OK, flux de test créé', 'success'); return worker('/supprimer', { uid: r.uid }); })
      .catch(function (e) { toast('❌ ' + ((e && e.message) || 'Erreur'), 'error', 6000); });
  };

  try { if (typeof firebase !== 'undefined' && firebase.auth) firebase.auth().onAuthStateChanged(function (u) { if (u) ecouter(); }); } catch (e) {}
  window.EvoFlux = { creerPourMatch: creerPourMatch, configure: function () { return !!(lsGet(LS_URL) && lsGet(LS_SECRET)); } };
})();
