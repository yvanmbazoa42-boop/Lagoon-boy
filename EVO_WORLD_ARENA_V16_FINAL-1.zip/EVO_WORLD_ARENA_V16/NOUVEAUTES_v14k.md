# EVO ARENA v14k — diffusion d'écran des joueurs vers Régie Live

## Ce qui a changé
1. **Message de création de match** : chaque joueur reçoit, avec le lien de salle et le mot de passe, un lien personnel **« 📺 Diffuse ton écran »** (`stream.html?f=…`).
2. **Page `stream.html`** : s'ouvre dans l'application EVO ARENA (depuis WhatsApp : bouton « Ouvrir dans l'application »). Conditions à accepter, choix paysage/portrait, bouton **Activer et diffuser mon écran**, état en direct, bouton Arrêter.
3. **Plugin Android natif `EvoScreenCast`** (dans `app-native/native/`) : capture l'écran (MediaProjection, service au premier plan avec notification « Arrêter ») et l'envoie en RTMPS vers Cloudflare Stream (bibliothèque RootEncoder). Le workflow GitHub l'intègre tout seul.
4. **Onglet admin 📺 FLUX** : un flux par joueur, badge « EN DIRECT », **📋 Copier le lien Régie Live** (HLS `.m3u8`), aperçu, **🎯 Publier sur la page live** du match. Le bouton 📋 COPIER LE LIEN est aussi dans la liste des lives de l'admin.
5. **`serveur/worker-flux.js`** : petit Worker Cloudflare qui crée/supprime les flux (la clé Cloudflare n'est jamais dans le site). Mise en place : `serveur/LISEZMOI_FLUX.md`.
6. **Règles Firestore** : collection `flux` (clé d'envoi lisible seulement par l'admin et le joueur concerné).
7. Version « 14k », cache du service worker, application Android 1.3.0.

## À faire de ton côté
- Suivre `serveur/LISEZMOI_FLUX.md` (compte Cloudflare Stream + Worker, ≈ 20 min).
- Republier `firestore.rules`, remplacer le site, reconstruire l'APK (GitHub Actions) et le réinstaller.
- Remplir `APK_URL` dans `stream.html`.

## À savoir (honnêtement)
- **Le code Java n'a pas pu être compilé ici** (pas d'Android SDK). Je l'ai vérifié contre des signatures simulées, et le script de build contre un faux projet Capacitor, mais **le premier build GitHub peut échouer sur un détail de la bibliothèque RootEncoder** (version 2.8.1). Dans ce cas, envoie-moi le message d'erreur : c'est une correction de quelques lignes.
- **Le son n'est pas diffusé** (seulement l'écran) ; le micro, s'il est autorisé, reste coupé.
- Direct = HLS : **5 à 15 secondes de retard** côté Régie Live.
- Android affiche toujours sa propre confirmation « Commencer à enregistrer ou à caster ? » : impossible à contourner, c'est voulu par Android.
- iPhone : non pris en charge (Android uniquement).
- Si le jeu est lancé après l'activation, la diffusion continue en arrière-plan grâce au service et à la notification.
- Depuis WhatsApp, Android peut ouvrir le lien dans le navigateur : le bouton « Ouvrir dans l'application » de la page lance alors l'application.
