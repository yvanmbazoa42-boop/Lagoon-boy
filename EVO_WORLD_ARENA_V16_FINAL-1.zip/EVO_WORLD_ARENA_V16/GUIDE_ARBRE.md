# 🌳 Arbre des tournois — mode d'emploi

## Admin (admin.html → onglet 🌳 ARBRE)
1. Choisis le tournoi en haut de la page.
2. **GÉNÉRER** : tirage au sort ou ordre d'inscription. L'arbre s'adapte seul au nombre de joueurs (2, 4, 8, 16, 32, 64, 128 places) ; les places libres deviennent des **BYE** (le joueur passe directement au tour suivant).
3. Touche un match : désigne le **vainqueur** (il avance dans l'arbre), saisis le **score**, **annule** un résultat (les tours suivants impactés sont remis à zéro) ou **remplace** un joueur (tant que le match n'est pas joué).
4. Nouveaux inscrits après la création : bouton **➕ AJOUTER** (ils prennent les places BYE libres).
5. Les matchs prêts à jouer clignotent en jaune.
6. **Petite finale** (3e place) : case à cocher à la création ; elle se remplit toute seule avec les 2 perdants des demi-finales.
7. **Planning** : dans un match, choisis date + heure (visibles par tous sur l'arbre) puis **📱 WhatsApp** pour prévenir chaque joueur avec lien et mot de passe de salle (ils ne sont pas enregistrés dans l'arbre).
8. **👁️ Publier / Masquer** l'arbre aux joueurs ; **📸 Image à partager** (PNG pour WhatsApp / Statut).
9. **🏁 Clôturer + podium** : champion, finaliste et 3e avec leurs gains (CEO 50 %, 25 %, 15 %, 10 %), tournoi passé en « terminé ».

## Joueurs (arbre.html, bouton 🌳 sur l'accueil)
- Arbre en lecture seule, **mis à jour en direct** dès que l'admin valide un vainqueur.
- Ton nom est marqué ; un encart indique ton prochain match, ton élimination ou ton titre.
- Boutons + / − pour zoomer, défilement horizontal, recherche d'un joueur (match surligné), bouton 📸 pour partager l'arbre en image.
- Date du prochain match avec compte à rebours, podium du tournoi terminé, **palmarès** de tous les tournois finis.

## Mise en ligne
- Aucune règle Firestore à changer : l'arbre est stocké dans le champ `Arbre` du document Tournois (écriture admin, lecture publique).
- Remplace tous les fichiers (nouveaux : `bracket.js`, `arbre-admin.js`, `arbre.html`).

## Limites actuelles
- Élimination directe (un match perdu = éliminé). Le système « 3 vies » existant reste géré par l'onglet VALIDER, séparément.
- Un joueur n'est rattaché qu'à un seul tournoi à la fois (champ `Tournament_id`).

## En faire une vraie APK
Le site est une PWA installable (manifest + raccourcis). Pour un fichier APK : **PWABuilder.com** (colle l'adresse du site → Android) ou **Capacitor** (`npx cap add android`). Cela demande un accès internet et Android Studio : à faire depuis ton ordinateur.
