'use strict';
// Parrainage : flux complet, anti-doublon, antifraude (base mémoire, pas l'émulateur Firebase).
const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../lib/core'); const { FakeDb } = require('./fakedb');
let n = 0; const T0 = new Date('2026-11-08T10:00:00Z');
const mk = (uid) => ({ uid, secret: 'test-secret-0123456789-abcdef', now: () => T0, newId: () => 'R' + String(++n).padStart(6, '0'), newCode: () => 'K' + String(1000000 + (++n)).replace(/[01]/g, '7').slice(0, 7), proofMeta: async () => ({ size: 10, contentType: 'image/png' }) });
function world() {
  const db = new FakeDb(); db.seed('admins/ADMIN', { ok: 1 });
  db.seed('Tournois/T1', { Nom: 'T1', Statut: 'actif', Frais_instription: 1000, Max_joueurs: 50, Inscrits: '[]' });
  db.seed('Tournois/T2', { Nom: 'T2', Statut: 'actif', Frais_instription: 1000, Max_joueurs: 50, Inscrits: '[]' });
  for (const u of ['P', 'F', 'G']) { db.seed('Joueurs/' + u, { Psuedo: u }); db.seed('Joueurs_prive/' + u, { Tel: '6' + u.charCodeAt(0) + '000000'.slice(0, 6) + '1' }); }
  return db;
}
async function pay(db, uid, tid, ref, payerPhone) {
  const r = await C.submitPayment(db, mk(uid), { tournamentId: tid, method: 'MTN_MOMO', mobileMoneyRef: ref, payerPhone, birthDate: '2000-01-01' });
  await C.attachProof(db, mk(uid), { txId: r.txId, path: 'payment_proofs/' + uid + '/' + r.txId + '/a.png' });
  return C.reviewPayment(db, mk('ADMIN'), { txId: r.txId, decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 });
}
test('flux complet : code unique, filleul enregistré, 2 récompenses à la 1re inscription payante confirmée, jamais en double', async () => {
  const db = world(); const { code } = await C.ensureReferralCode(db, mk('P'));
  assert.equal((await C.ensureReferralCode(db, mk('P'))).code, code, 'même code à chaque appel');
  assert.equal((await C.applyReferralCode(db, mk('F'), { code })).status, 'PENDING');
  const out = await pay(db, 'F', 'T1', 'REFREF0001', '699111222'); assert.equal(out.referralRewarded, true);
  assert.equal(db.read('wallets/P').FreeEntries, 1); assert.equal(db.read('wallets/F').FreeEntries, 1); assert.equal(db.read('referrals/F').status, 'REWARDED');
  const out2 = await pay(db, 'F', 'T2', 'REFREF0002', '699111222'); assert.equal(out2.referralRewarded, false);
  assert.equal(db.read('wallets/P').FreeEntries, 1, 'pas de récompense en double');
  assert.ok([...db.store.keys()].some((k) => k.startsWith('admin_logs/')));
});
test('antifraude : code refusé après un paiement ; auto-parrainage ; 2e parrain ; code inconnu', async () => {
  const db = world(); const { code } = await C.ensureReferralCode(db, mk('P'));
  await assert.rejects(C.applyReferralCode(db, mk('P'), { code }), /propre code/);
  await assert.rejects(C.applyReferralCode(db, mk('F'), { code: 'ZZZZZZZZ' }), /inconnu/);
  await C.applyReferralCode(db, mk('F'), { code });
  await assert.rejects(C.applyReferralCode(db, mk('F'), { code }), /déjà un parrain/);
  await pay(db, 'G', 'T1', 'REFREF0010', '699000000');
  await assert.rejects(C.applyReferralCode(db, mk('G'), { code }), /avant ta première/);
});
test('antifraude : le filleul paie avec le numéro du parrain -> pas de récompense automatique, SUSPECT ; l\'admin valide -> récompense UNE fois', async () => {
  const db = world(); const { code } = await C.ensureReferralCode(db, mk('P')); await C.applyReferralCode(db, mk('F'), { code });
  const parrainTel = db.read('Joueurs_prive/P').Tel;
  const out = await pay(db, 'F', 'T1', 'REFREF0020', parrainTel);
  assert.equal(out.referralRewarded, false); assert.equal(out.referralFlagged, true);
  assert.equal(db.read('referrals/F').status, 'SUSPECT'); assert.equal(db.read('wallets/P').FreeEntries, undefined);
  await assert.rejects(C.setReferralStatus(db, mk('G'), { referredId: 'F', status: 'PENDING' }), /administrateurs/);
  const r = await C.setReferralStatus(db, mk('ADMIN'), { referredId: 'F', status: 'PENDING' }); assert.equal(r.status, 'REWARDED');
  assert.equal(db.read('wallets/P').FreeEntries, 1); assert.equal(db.read('wallets/F').FreeEntries, 1);
  await assert.rejects(C.setReferralStatus(db, mk('ADMIN'), { referredId: 'F', status: 'PENDING' }), /déjà distribuée/);
});
test('antifraude : même numéro -> SUSPECT ; rejet admin = aucune récompense ; plafond de filleuls par parrain', async () => {
  const db = world(); db.seed('Joueurs_prive/G', { Tel: db.read('Joueurs_prive/P').Tel });
  const { code } = await C.ensureReferralCode(db, mk('P'));
  assert.equal((await C.applyReferralCode(db, mk('G'), { code })).status, 'SUSPECT');
  await C.setReferralStatus(db, mk('ADMIN'), { referredId: 'G', status: 'REJECTED' });
  const o = await pay(db, 'G', 'T1', 'REFREF0030', '699000001'); assert.equal(o.referralRewarded, false); assert.equal(db.read('wallets/P').FreeEntries, undefined);
  const db2 = world(); const c2 = (await C.ensureReferralCode(db2, mk('P'))).code; db2.seed('wallets/P', { ReferralCode: c2, ReferralTotal: 30 });
  assert.equal((await C.applyReferralCode(db2, mk('F'), { code: c2 })).status, 'SUSPECT'); assert.match(db2.read('referrals/F').suspectReason, /Plafond/);
});
test('entrée gratuite : utilisée une seule fois, solde jamais négatif', async () => {
  const db = world(); const { code } = await C.ensureReferralCode(db, mk('P')); await C.applyReferralCode(db, mk('F'), { code });
  await pay(db, 'F', 'T1', 'REFREF0040', '699111333');
  const r = await C.submitPayment(db, mk('P'), { tournamentId: 'T2', useFreeEntry: true, birthDate: '1990-01-01' }); assert.equal(r.freeEntry, true);
  assert.equal(db.read('wallets/P').FreeEntries, 0);
  await assert.rejects(C.submitPayment(db, mk('P'), { tournamentId: 'T1', useFreeEntry: true, birthDate: '1990-01-01' }), /entrée gratuite/);
});
