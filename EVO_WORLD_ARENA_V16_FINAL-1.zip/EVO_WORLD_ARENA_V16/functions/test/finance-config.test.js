'use strict';
// Configuration financière : validation, simulation, versions, gel des règles (base mémoire, pas l'émulateur Firebase).
const test = require('node:test'); const assert = require('node:assert/strict'); const fs = require('fs'); const path = require('path');
const C = require('../lib/core'); const F = require('../lib/finance-calc'); const { FakeDb } = require('./fakedb');
const T0 = new Date('2026-11-08T10:00:00Z'); let n = 0;
const mk = (uid) => ({ uid, secret: 'test-secret-0123456789-abcdef', now: () => T0, newId: () => 'F' + String(++n).padStart(6, '0'), newCode: () => 'ABCD2345', proofMeta: async () => ({ size: 10, contentType: 'image/png' }) });
const CFG1 = { commissionPct: 20, split: { first: 50, second: 30, third: 10, platform: 10 } };
const world = () => { const db = new FakeDb(); db.seed('admins/ADMIN', { ok: 1 });
  for (const u of ['A', 'B']) db.seed('Joueurs/' + u, { Psuedo: u });
  for (const t of ['T1', 'T2']) db.seed('Tournois/' + t, { Nom: t, Statut: 'actif', Frais_instription: 1000, Max_joueurs: 8, Inscrits: '[]' });
  return db; };
const setCfg = (db, cfg, expectedVersion, who) => C.setFinanceConfig(db, mk(who || 'ADMIN'), Object.assign({ confirmedSimulation: true, expectedVersion }, cfg));
async function payApprove(db, uid, tid, ref) {
  const r = await C.submitPayment(db, mk(uid), { tournamentId: tid, method: 'MTN_MOMO', mobileMoneyRef: ref, birthDate: '2000-01-01' });
  await C.attachProof(db, mk(uid), { txId: r.txId, path: 'payment_proofs/' + uid + '/' + r.txId + '/a.png' });
  return C.reviewPayment(db, mk('ADMIN'), { txId: r.txId, decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 });
}
test('validation : somme = 100 %, bornes, 1er > 0', () => {
  assert.equal(F.validateFinanceConfig(CFG1).ok, true);
  assert.match(F.validateFinanceConfig({ commissionPct: 20, split: { first: 50, second: 30, third: 10, platform: 5 } }).errors.join(), /100 %/);
  assert.equal(F.validateFinanceConfig({ commissionPct: 120, split: CFG1.split }).ok, false);
  assert.equal(F.validateFinanceConfig({ commissionPct: -1, split: CFG1.split }).ok, false);
  assert.equal(F.validateFinanceConfig({ commissionPct: 10, split: { first: 0, second: 50, third: 50, platform: 0 } }).ok, false);
  assert.equal(F.validateFinanceConfig({ commissionPct: 10, split: { first: '50', second: 30, third: 10, platform: 10 } }).ok, false);
  assert.equal(F.validateFinanceConfig({ commissionPct: 12.5, split: { first: 60.5, second: 20, third: 10, platform: 9.5 } }).ok, true);
});
test('simulation : la somme des parts est toujours égale au net, au franc près', () => {
  for (const net of [0, 1, 7, 999, 1000, 12345, 99999, 1234567]) for (const cfg of [CFG1, { commissionPct: 33.33, split: { first: 33.34, second: 33.33, third: 33.33, platform: 0 } }, { commissionPct: 0, split: { first: 100, second: 0, third: 0, platform: 0 } }]) {
    const s = F.simulateFinance(cfg, net); assert.equal(s.check, true, JSON.stringify([net, cfg, s])); assert.ok(s.poolReserve >= 0 && s.first >= 0);
  }
  const s = F.simulateFinance(CFG1, 10000); assert.deepEqual([s.commission, s.pool, s.first, s.second, s.third, s.poolReserve, s.platformTotal], [2000, 8000, 4000, 2400, 800, 800, 2800]);
});
test('copie client identique au calcul serveur', () => {
  assert.equal(fs.readFileSync(path.join(__dirname, '../lib/finance-calc.js'), 'utf8'), fs.readFileSync(path.join(__dirname, '../../finance-calc.js'), 'utf8'));
});
test('setFinanceConfig : admin seulement, simulation confirmée, version + historique immuable, conflit de version', async () => {
  const db = world();
  await assert.rejects(setCfg(db, CFG1, 0, 'A'), /administrateurs/);
  await assert.rejects(C.setFinanceConfig(db, mk('ADMIN'), Object.assign({ expectedVersion: 0 }, CFG1)), /simulation/);
  await assert.rejects(setCfg(db, { commissionPct: 20, split: { first: 50, second: 30, third: 10, platform: 9 } }, 0), /100 %/);
  assert.equal((await setCfg(db, CFG1, 0)).version, 1);
  await assert.rejects(setCfg(db, CFG1, 0), /changé entre-temps/);
  assert.equal((await setCfg(db, { commissionPct: 10, split: { first: 60, second: 25, third: 10, platform: 5 } }, 1)).version, 2);
  assert.equal(db.read('finance_config/current').commissionPct, 10);
  assert.equal(db.read('finance_config_history/000001').commissionPct, 20); assert.equal(db.read('finance_config_history/000002').previous.commissionPct, 20);
  assert.ok([...db.store.keys()].some((k) => k.startsWith('admin_logs/')), 'journal d\'audit écrit');
});
test('PAS RÉTROACTIF : une cagnotte engagée garde les règles figées ; un nouveau tournoi suit la nouvelle configuration', async () => {
  const db = world(); await setCfg(db, CFG1, 0);
  await payApprove(db, 'A', 'T1', 'REF100001');             // T1 : cagnotte engagée sous la version 1
  assert.equal(db.read('tournament_finance/T1').Rules.version, 1);
  await setCfg(db, { commissionPct: 50, split: { first: 100, second: 0, third: 0, platform: 0 } }, 1);   // version 2
  await payApprove(db, 'B', 'T1', 'REF100002');             // 2e paiement du MÊME tournoi : règles inchangées
  assert.equal(db.read('tournament_finance/T1').Rules.version, 1);
  const o1 = await C.prepareWinnings(db, mk('ADMIN'), { tournamentId: 'T1', winners: { 1: 'A', 2: 'B' } });
  assert.deepEqual([o1.rulesVersion, o1.prizePool, o1.rows.map((x) => x.amount)], [1, 1600, [800, 480]]);   // 20 % de 2000 = 400 ; 50 %, 30 % de 1600
  assert.equal(o1.platformShare, 400 + 1600 - 800 - 480 - 160, 'commission + reste non attribué');
  await payApprove(db, 'A', 'T2', 'REF100003');             // T2 : engagé après le changement -> version 2
  assert.equal(db.read('tournament_finance/T2').Rules.version, 2);
  const o2 = await C.prepareWinnings(db, mk('ADMIN'), { tournamentId: 'T2', winners: { 1: 'A' } });
  assert.deepEqual([o2.rulesVersion, o2.prizePool, o2.rows[0].amount], [2, 500, 500]);
});
test('cagnotte encaissée sans règles figées : refus sans confirmation explicite ; sans aucune configuration : refus', async () => {
  const db = world();
  await payApprove(db, 'A', 'T1', 'REF200001');             // aucune config ni règle : rien n'est figé
  assert.equal(db.read('tournament_finance/T1').Rules, undefined);
  await assert.rejects(C.prepareWinnings(db, mk('ADMIN'), { tournamentId: 'T1', winners: { 1: 'A' } }), /figées/);
  await assert.rejects(C.prepareWinnings(db, mk('ADMIN'), { tournamentId: 'T1', winners: { 1: 'A' }, applyCurrent: true }), /Configure la commission/);
  await setCfg(db, CFG1, 0);
  const o = await C.prepareWinnings(db, mk('ADMIN'), { tournamentId: 'T1', winners: { 1: 'A' }, applyCurrent: true });
  assert.equal(o.rulesVersion, 1); assert.equal(db.read('tournament_finance/T1').Rules.version, 1, 'figées à ce moment-là');
});
