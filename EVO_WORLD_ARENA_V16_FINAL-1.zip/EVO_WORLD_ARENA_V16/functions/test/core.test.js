'use strict';
const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../lib/core'); const { FakeDb } = require('./fakedb');
const SECRET = 'test-secret-0123456789-abcdef';
let n = 0; const T0 = new Date('2026-11-08T10:00:00Z');
const mk = (uid, extra) => Object.assign({ uid, secret: SECRET, now: () => T0, newId: () => 'ID' + String(++n).padStart(6, '0'), newCode: () => 'CODE' + String(++n).padStart(4, '0').replace(/0/g, '2').replace(/1/g, '3').slice(-4),
  proofMeta: async () => ({ size: 1000, contentType: 'image/png' }) }, extra || {});
function world() {
  const db = new FakeDb();
  db.seed('Tournois/T1', { Nom: 'Free Fire Cup', Statut: 'actif', Frais_instription: 1000, Max_joueurs: 2, Inscrits: '[]', Commission_pct: 20, Repartition: '[50,30]' });
  db.seed('Tournois/TFREE', { Nom: 'Free cup', Statut: 'actif', Frais_instription: 0, Max_joueurs: 8, Inscrits: '[]' });
  db.seed('admins/ADMIN', { ok: true });
  for (const u of ['A', 'B', 'C', 'MINOR']) {
    db.seed('Joueurs/' + u, { Psuedo: 'P_' + u });   // v16 : profil PUBLIC sans contact
    db.seed('Joueurs_prive/' + u, { Tel: '6' + (u.charCodeAt(0) * 1000003).toString().slice(0, 8) });
  }
  return db;
}
const pay = (db, uid, ref, extra) => C.submitPayment(db, mk(uid), Object.assign({ tournamentId: 'T1', method: 'MTN_MOMO', mobileMoneyRef: ref, birthDate: '2000-01-01' }, extra || {}));
const approve = (db, txId, extra) => C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId, decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 }, extra || {}));
async function paidAndProved(db, uid, ref) { const r = await pay(db, uid, ref); await C.attachProof(db, mk(uid), { txId: r.txId, path: 'payment_proofs/' + uid + '/' + r.txId + '/a.png' }); return r; }

test('1+2 transaction créée PENDING, montant serveur, preuve -> UNDER_REVIEW, historique', async () => {
  const db = world(); const r = await pay(db, 'A', 'MP260101.AB12', { amount: 1 });
  const t = db.read('transactions/' + r.txId);
  assert.equal(t.amount, 1000); assert.equal(t.currency, 'XAF'); assert.equal(t.status, 'PENDING'); assert.equal(t.mobileMoneyRef, 'MP260101AB12');
  assert.match(r.invoiceNumber, /^EVO-INV-2026-000001$/);
  await C.attachProof(db, mk('A'), { txId: r.txId, path: 'payment_proofs/A/' + r.txId + '/x.png' });
  const t2 = db.read('transactions/' + r.txId); assert.equal(t2.status, 'UNDER_REVIEW'); assert.equal(t2.History.length, 2);
  assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits), [], "pas inscrit tant que non validé");
});
test('capture seule ≠ paiement confirmé : refus sans preuve, sans confirmation, mauvais montant', async () => {
  const db = world(); const r = await pay(db, 'A', 'REF000001');
  await assert.rejects(approve(db, r.txId), /preuve/i);
  await C.attachProof(db, mk('A'), { txId: r.txId, path: 'payment_proofs/A/' + r.txId + '/x.png' });
  await assert.rejects(approve(db, r.txId, { confirmedReceived: false }), /exactement/);
  await assert.rejects(approve(db, r.txId, { receivedAmount: 500 }), /exactement/);
  assert.equal(db.read('transactions/' + r.txId).status, 'UNDER_REVIEW');
});
test('3+4+5+6 validation admin : inscrit, facture d\'inscription + reçu distincts, signature, vérification', async () => {
  const db = world(); const r = await paidAndProved(db, 'A', 'REF000002');
  const out = await approve(db, r.txId);
  assert.equal(out.status, 'APPROVED'); assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits), ['A']);
  const reg = db.read('invoices/EVO-INV-2026-000001'), rec = db.read('invoices/' + out.receiptNumber);
  assert.equal(reg.type, 'REGISTRATION_INVOICE'); assert.equal(rec.type, 'PAYMENT_RECEIPT'); assert.notEqual(reg.number, rec.number);
  assert.equal(rec.verified, true); assert.equal(rec.currency, 'XAF');
  assert.equal(db.read('invoice_public/' + reg.number).paymentStatus, 'APPROVED');
  const v = await C.verifyInvoice(db, SECRET, rec.number, C.shortSig(rec.signature));
  assert.equal(v.found, true); assert.equal(v.signatureOk, true); assert.equal(v.amount, 1000);
  assert.equal((await C.verifyInvoice(db, SECRET, rec.number, 'deadbeefdeadbeef')).signatureOk, false);
  assert.equal((await C.verifyInvoice(db, SECRET, 'EVO-INV-2026-999999')).found, false);
  const keys = Object.keys(v).sort(); assert.deepEqual(keys, ['amount', 'currency', 'found', 'issuedAt', 'number', 'paymentStatus', 'signatureOk', 'type', 'verified']);
  // signature : modifier le montant invalide la signature
  assert.notEqual(C.invoiceSignature(SECRET, { ...rec, amount: 5000 }), rec.signature);
});
test('7 doublons : double validation concurrente, référence réutilisée, 2e demande même tournoi', async () => {
  const db = world(); const r = await paidAndProved(db, 'A', 'REF000003');
  const res = await Promise.allSettled([approve(db, r.txId), approve(db, r.txId)]);
  assert.equal(res.filter((x) => x.status === 'fulfilled').length, 1); assert.equal(res.filter((x) => x.status === 'rejected').length, 1);
  assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits), ['A']);
  assert.equal(db.read('tournament_finance/T1').Collected, 1000);
  await assert.rejects(pay(db, 'B', 'ref-000003'), /déjà été utilisée/);
  await assert.rejects(pay(db, 'A', 'REF000009'), /déjà/);
});
test('numéros de facture uniques et séquentiels, jamais écrasés', async () => {
  const db = world(); const a = await pay(db, 'A', 'REF100001'); const b = await pay(db, 'B', 'REF100002');
  assert.deepEqual([a.invoiceNumber, b.invoiceNumber], ['EVO-INV-2026-000001', 'EVO-INV-2026-000002']);
  db.seed('invoice_counters/2026', { last: 0 }); // compteur corrompu : doit refuser plutôt qu'écraser
  await assert.rejects(pay(db, 'C', 'REF100003'), /Conflit/);
});
test('8 refus : raison obligatoire, référence libérée, justificatif, pas inscrit', async () => {
  const db = world(); const r = await paidAndProved(db, 'A', 'REF000004');
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), { txId: r.txId, decision: 'REJECT', reason: '' }), /raison/i);
  await C.reviewPayment(db, mk('ADMIN'), { txId: r.txId, decision: 'REJECT', reason: 'Montant non reçu' });
  const t = db.read('transactions/' + r.txId); assert.equal(t.status, 'REJECTED'); assert.equal(t.RejectReason, 'Montant non reçu');
  assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits), []);
  assert.equal(db.read('payment_refs/REF000004'), undefined);
  await assert.rejects(approve(db, r.txId), /Déjà traitée/);
  const r2 = await pay(db, 'A', 'REF000005'); assert.equal(r2.status, 'PENDING'); // peut re-soumettre
});
test('9 remboursement : enregistré ≠ transfert ; reçu seulement après confirmation', async () => {
  const db = world(); const r = await paidAndProved(db, 'A', 'REF000006'); await approve(db, r.txId);
  await C.recordRefund(db, mk('ADMIN'), { txId: r.txId, reason: 'Tournoi annulé' });
  assert.equal(db.read('transactions/' + r.txId).status, 'APPROVED');
  assert.equal(db.read('transactions/' + r.txId).RefundState, 'RECORDED');
  await assert.rejects(C.confirmRefundTransfer(db, mk('ADMIN'), { txId: r.txId, confirmedTransfer: false, transferRef: 'X' }), /Confirme/);
  const out = await C.confirmRefundTransfer(db, mk('ADMIN'), { txId: r.txId, confirmedTransfer: true, transferRef: 'MP-REFUND-1' });
  assert.equal(db.read('transactions/' + r.txId).status, 'REFUNDED'); assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits), []);
  assert.equal(db.read('tournament_finance/T1').Refunded, 1000);
  assert.ok([...db.store.keys()].some((k) => k.startsWith('invoices/') && db.read(k).type === 'REFUND_RECEIPT' && db.read(k).verified === true), 'reçu de remboursement émis après confirmation');
  assert.equal([...db.store.keys()].filter((k) => k.startsWith('invoices/') && db.read(k).type === 'REFUND_RECEIPT').length, 1);
  await assert.rejects(C.recordRefund(db, mk('ADMIN'), { txId: r.txId, reason: 'x' }), /confirmé peut être/);
});
test('10 parrainage : auto-parrainage, code après 1er paiement, récompense unique, suspicion', async () => {
  const db = world();
  const { code } = await C.ensureReferralCode(db, mk('A', { newCode: () => 'ABCD2345' }));
  assert.equal((await C.ensureReferralCode(db, mk('A'))).code, 'ABCD2345');
  await assert.rejects(C.applyReferralCode(db, mk('A'), { code }), /propre code/);
  await assert.rejects(C.applyReferralCode(db, mk('B'), { code: 'ZZZZ9999' }), /inconnu/);
  assert.equal((await C.applyReferralCode(db, mk('B'), { code })).status, 'PENDING');
  await assert.rejects(C.applyReferralCode(db, mk('B'), { code }), /déjà un parrain/);
  const r = await paidAndProved(db, 'B', 'REF000007'); const out = await approve(db, r.txId);
  assert.equal(out.referralRewarded, true);
  assert.equal(db.read('wallets/A').FreeEntries, 1); assert.equal(db.read('wallets/B').FreeEntries, 1);
  assert.equal(db.read('referrals/B').status, 'REWARDED'); assert.ok(db.read('referral_rewards/B_REFERRER') && db.read('referral_rewards/B_REFEREE'));
  // 2e paiement de B : aucune nouvelle récompense
  db.seed('Tournois/T2', { Nom: 'Cup 2', Statut: 'actif', Frais_instription: 1000, Max_joueurs: 8, Inscrits: '[]' });
  const r2 = await C.submitPayment(db, mk('B'), { tournamentId: 'T2', method: 'MTN_MOMO', mobileMoneyRef: 'REF000008' });
  await C.attachProof(db, mk('B'), { txId: r2.txId, path: 'payment_proofs/B/' + r2.txId + '/a.png' });
  assert.equal((await approve(db, r2.txId)).referralRewarded, false); assert.equal(db.read('wallets/A').FreeEntries, 1);
  // utilisation de l'entrée gratuite : décrémentée, inscrit sans paiement, une seule fois
  const f = await C.submitPayment(db, mk('A'), { tournamentId: 'T2', useFreeEntry: true, birthDate: '1998-02-02' });
  assert.equal(f.status, 'APPROVED'); assert.equal(db.read('wallets/A').FreeEntries, 0);
  await assert.rejects(C.submitPayment(db, mk('A'), { tournamentId: 'T1', useFreeEntry: true, birthDate: '1998-02-02' }), /entrée gratuite/);
  // suspicion : même numéro
  db.seed('Joueurs/D', { Psuedo: 'D' }); db.seed('Joueurs_prive/D', { Tel: db.read('Joueurs_prive/A').Tel }); assert.equal((await C.applyReferralCode(db, mk('D'), { code })).status, 'SUSPECT');
  const rd = await paidAndProved(db, 'D', 'REF000010'); assert.equal((await approve(db, rd.txId)).referralRewarded, false);
});
test('11 gains : calcul serveur, config obligatoire, pas de double attribution ni double paiement', async () => {
  const db = world();
  for (const [u, ref] of [['A', 'REF000011'], ['B', 'REF000012']]) { const r = await paidAndProved(db, u, ref); await approve(db, r.txId); }
  const c = mk('ADMIN');
  const out = await C.prepareWinnings(db, c, { tournamentId: 'T1', winners: { 1: 'A', 2: 'B' } });
  assert.equal(out.platformShare, 400); assert.equal(out.prizePool, 1600); assert.deepEqual(out.rows.map((x) => x.amount), [800, 480]);
  await assert.rejects(C.prepareWinnings(db, c, { tournamentId: 'T1', winners: { 1: 'A' } }), /déjà été attribué/);
  await assert.rejects(C.confirmPrizePaid(db, c, { tournamentId: 'T1', rank: 1, confirmedTransfer: false, transferRef: 'MP1' }), /Confirme/);
  const p = await C.confirmPrizePaid(db, c, { tournamentId: 'T1', rank: 1, confirmedTransfer: true, transferRef: 'MP-PRIZE-1' });
  assert.equal(db.read('invoices/' + p.receiptNumber).type, 'PRIZE_RECEIPT');
  await assert.rejects(C.confirmPrizePaid(db, c, { tournamentId: 'T1', rank: 1, confirmedTransfer: true, transferRef: 'MP-PRIZE-1' }), /Déjà payé/);
  const db2 = world(); db2.seed('Tournois/T3', { Nom: 'Sans config', Statut: 'actif', Inscrits: '["A"]' });
  await assert.rejects(C.prepareWinnings(db2, c, { tournamentId: 'T3', winners: { 1: 'A' } }), /Configure la commission/);
});
test('12-14 mineurs, droits admin, preuve invalide, tournoi complet/gratuit, Sans pub', async () => {
  const db = world();
  await assert.rejects(pay(db, 'MINOR', 'REF000020', { birthDate: '2012-05-05' }), /18 ans/);
  await assert.rejects(pay(db, 'MINOR', 'REF000021', { birthDate: 'n\'importe quoi' }), /Date de naissance/);
  const r = await paidAndProved(db, 'A', 'REF000022');
  await assert.rejects(C.reviewPayment(db, mk('A'), { txId: r.txId, decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 }), /administrateurs/);
  await assert.rejects(C.recordRefund(db, mk('A'), { txId: r.txId, reason: 'x' }), /administrateurs/);
  await assert.rejects(C.attachProof(db, mk('B'), { txId: r.txId, path: 'payment_proofs/B/' + r.txId + '/a.png' }), /introuvable/);
  await assert.rejects(C.attachProof(db, mk('A'), { txId: r.txId, path: 'payment_proofs/B/x/a.png' }), /Chemin/);
  await assert.rejects(C.attachProof(db, mk('A', { proofMeta: async () => ({ size: 10, contentType: 'application/pdf' }) }), { txId: r.txId, path: 'payment_proofs/A/' + r.txId + '/a.pdf' }), /image/);
  await approve(db, r.txId); const rb = await paidAndProved(db, 'B', 'REF000023'); await approve(db, rb.txId);
  await assert.rejects(pay(db, 'C', 'REF000024'), /complet/);
  const fr = await C.submitPayment(db, mk('MINOR'), { tournamentId: 'TFREE' }); assert.equal(fr.needsProof, false); // gratuit : accessible sans âge
  await C.reviewPayment(db, mk('ADMIN'), { txId: fr.txId, decision: 'APPROVE' });
  assert.deepEqual(JSON.parse(db.read('Tournois/TFREE').Inscrits), ['MINOR']);
  const s = await C.submitPayment(db, mk('C'), { kind: 'SANS_PUB', method: 'ORANGE_MONEY', mobileMoneyRef: 'REF000025', birthDate: '1999-03-03' });
  assert.equal(db.read('transactions/' + s.txId).amount, 1000); assert.equal(db.read('invoices/' + s.invoiceNumber).type, 'SUBSCRIPTION_INVOICE');
  await C.attachProof(db, mk('C'), { txId: s.txId, path: 'payment_proofs/C/' + s.txId + '/a.png' }); await approve(db, s.txId);
  assert.equal(db.read('Joueurs/C').Sans_pub, true); assert.equal(db.read('Joueurs/C').Sans_pub_fin, '2026-12-08T10:00:00.000Z');
});
