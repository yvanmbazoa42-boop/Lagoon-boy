'use strict';
// À LANCER avec les émulateurs Storage + Firestore (les règles Storage lisent la collection admins) :
//   firebase emulators:exec --only firestore,storage "node --test functions/test/storage.emulator.test.js"
// ÉCRIT MAIS NON EXÉCUTÉ dans la livraison (pas de réseau ni d'émulateur disponibles dans l'environnement de développement).
const test = require('node:test'); const fs = require('fs'); const path = require('path');
const { initializeTestEnvironment, assertFails, assertSucceeds } = require('@firebase/rules-unit-testing');
let env;
test.before(async () => {
  env = await initializeTestEnvironment({ projectId: 'evo-test', firestore: { rules: fs.readFileSync(path.join(__dirname, '../../firestore.rules'), 'utf8') }, storage: { rules: fs.readFileSync(path.join(__dirname, '../../storage.rules'), 'utf8') } });
  await env.withSecurityRulesDisabled(async (c) => { await c.firestore().doc('admins/ADMIN').set({ ok: 1 }); });
});
test.after(async () => env && env.cleanup());
const st = (uid) => (uid ? env.authenticatedContext(uid) : env.unauthenticatedContext()).storage();
const PNG = Buffer.from('89504e470d0a1a0a', 'hex');
test('preuve de paiement : le joueur écrit seulement dans SON dossier, image PNG/JPEG/WebP < 5 Mo', async () => {
  await assertSucceeds(st('A').ref('payment_proofs/A/TX1/a.png').put(PNG, { contentType: 'image/png' }));
  await assertFails(st('B').ref('payment_proofs/A/TX1/b.png').put(PNG, { contentType: 'image/png' }));
  await assertFails(st(null).ref('payment_proofs/A/TX1/c.png').put(PNG, { contentType: 'image/png' }));
  await assertFails(st('A').ref('payment_proofs/A/TX1/d.pdf').put(Buffer.from('%PDF'), { contentType: 'application/pdf' }));
  await assertFails(st('A').ref('payment_proofs/A/TX1/e.svg').put(Buffer.from('<svg/>'), { contentType: 'image/svg+xml' }));
  await assertFails(st('A').ref('payment_proofs/A/TX1/big.png').put(Buffer.alloc(5 * 1024 * 1024 + 1), { contentType: 'image/png' }));
});
test('preuve de paiement : lecture par le propriétaire et l\'admin seulement ; jamais de modification ni suppression', async () => {
  await assertSucceeds(st('A').ref('payment_proofs/A/TX1/a.png').getDownloadURL()); await assertSucceeds(st('ADMIN').ref('payment_proofs/A/TX1/a.png').getDownloadURL());
  await assertFails(st('B').ref('payment_proofs/A/TX1/a.png').getDownloadURL()); await assertFails(st(null).ref('payment_proofs/A/TX1/a.png').getDownloadURL());
  await assertFails(st('A').ref('payment_proofs/A/TX1/a.png').delete()); await assertFails(st('A').ref('payment_proofs/A/TX1/a.png').put(PNG, { contentType: 'image/png' }));
});
test('tout autre chemin Storage est fermé', async () => { await assertFails(st('A').ref('autre/x.png').put(PNG, { contentType: 'image/png' })); await assertFails(st('ADMIN').ref('autre/x.png').getDownloadURL()); });
