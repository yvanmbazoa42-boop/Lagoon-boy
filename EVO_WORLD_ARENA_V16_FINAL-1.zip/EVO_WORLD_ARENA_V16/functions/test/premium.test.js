'use strict';
// EVO PREMIUM — SANS PUB : jamais actif avant confirmation, dates, renouvellement, expiration (base mémoire, pas l'émulateur Firebase).
const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../lib/core'); const { FakeDb } = require('./fakedb');
let n = 0; let NOW = new Date('2026-11-08T10:00:00Z');
const mk = (uid) => ({ uid, secret: 'test-secret-0123456789-abcdef', now: () => NOW, newId: () => 'P' + String(++n).padStart(6, '0'), newCode: () => 'ABCD2345', proofMeta: async () => ({ size: 10, contentType: 'image/png' }) });
const world = () => { const db = new FakeDb(); db.seed('admins/ADMIN', { ok: 1 }); db.seed('Joueurs/A', { Psuedo: 'A' }); db.seed('Joueurs/M', { Psuedo: 'M' }); return db; };
async function subscribe(db, uid, ref, birth) {
  const r = await C.submitPayment(db, mk(uid), { kind: 'SANS_PUB', method: 'ORANGE_MONEY', mobileMoneyRef: ref, birthDate: birth || '1999-05-05' });
  await C.attachProof(db, mk(uid), { txId: r.txId, path: 'payment_proofs/' + uid + '/' + r.txId + '/a.png' }); return r;
}
const confirm = (db, txId) => C.reviewPayment(db, mk('ADMIN'), { txId, decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 });
test('abonnement : 1000 FCFA, nom EVO PREMIUM, JAMAIS actif avant la confirmation de l\'admin', async () => {
  const db = world(); const r = await subscribe(db, 'A', 'SUB000001');
  const t = db.read('transactions/' + r.txId); assert.equal(t.amount, 1000); assert.match(t.serviceName, /EVO PREMIUM — SANS PUB/); assert.equal(t.kind, 'SANS_PUB');
  assert.equal(db.read('Joueurs/A').Sans_pub, undefined, 'pas actif tant que non confirmé');
  await assert.rejects(C.submitPayment(db, mk('A'), { kind: 'SANS_PUB', method: 'MTN_MOMO', mobileMoneyRef: 'SUB000002', birthDate: '1999-05-05' }), /déjà en cours/);
  const out = await confirm(db, r.txId); assert.equal(out.status, 'APPROVED');
  const p = db.read('Joueurs/A'); assert.equal(p.Sans_pub, true); assert.equal(p.Sans_pub_debut, '2026-11-08T10:00:00.000Z'); assert.equal(p.Sans_pub_fin, '2026-12-08T10:00:00.000Z');
  const t2 = db.read('transactions/' + r.txId); assert.equal(t2.SubStart, '2026-11-08T10:00:00.000Z'); assert.equal(t2.SubEnd, '2026-12-08T10:00:00.000Z'); assert.equal(t2.SubRenewal, false);
  const rec = db.read('invoices/' + t2.ReceiptNumber); assert.equal(rec.type, 'PAYMENT_RECEIPT'); assert.match(rec.serviceName, /du 2026-11-08 au 2026-12-08/);
  assert.equal(db.read('invoices/' + t2.InvoiceNumber).type, 'SUBSCRIPTION_INVOICE');
});
test('refus : abonnement jamais activé, nouvelle demande possible', async () => {
  const db = world(); const r = await subscribe(db, 'A', 'SUB000010');
  await C.reviewPayment(db, mk('ADMIN'), { txId: r.txId, decision: 'REJECT', reason: 'Montant reçu incorrect' });
  assert.equal(db.read('Joueurs/A').Sans_pub, undefined);
  const r2 = await subscribe(db, 'A', 'SUB000011'); assert.equal(db.read('transactions/' + r2.txId).status, 'UNDER_REVIEW');
});
test('renouvellement avant l\'échéance = prolongation depuis la date de fin ; après expiration = depuis maintenant', async () => {
  const db = world(); NOW = new Date('2026-11-08T10:00:00Z');
  await confirm(db, (await subscribe(db, 'A', 'SUB000020')).txId);
  NOW = new Date('2026-11-20T10:00:00Z');
  const r = await subscribe(db, 'A', 'SUB000021'); await confirm(db, r.txId);
  assert.equal(db.read('Joueurs/A').Sans_pub_fin, '2027-01-07T10:00:00.000Z'); assert.equal(db.read('transactions/' + r.txId).SubRenewal, true);
  assert.equal(db.read('Joueurs/A').Sans_pub_debut, '2026-11-08T10:00:00.000Z', 'le début de la série est conservé');
  NOW = new Date('2027-03-01T10:00:00Z');
  const r3 = await subscribe(db, 'A', 'SUB000022'); await confirm(db, r3.txId);
  assert.equal(db.read('Joueurs/A').Sans_pub_fin, '2027-03-31T10:00:00.000Z'); assert.equal(db.read('Joueurs/A').Sans_pub_debut, '2027-03-01T10:00:00.000Z');
  NOW = new Date('2026-11-08T10:00:00Z');
});
test('expiration automatique : seuls les abonnements échus sont désactivés', async () => {
  const db = world(); NOW = new Date('2026-12-09T00:00:00Z');
  db.seed('Joueurs/E', { Psuedo: 'E', Sans_pub: true, Sans_pub_fin: '2026-12-08T10:00:00.000Z' });
  db.seed('Joueurs/V', { Psuedo: 'V', Sans_pub: true, Sans_pub_fin: '2027-01-01T00:00:00.000Z' });
  const r = await C.expireSubscriptions(db, mk('system')); assert.equal(r.expired, 1);
  assert.equal(db.read('Joueurs/E').Sans_pub, false); assert.equal(db.read('Joueurs/E').Sans_pub_expire_le, '2026-12-09T00:00:00.000Z'); assert.equal(db.read('Joueurs/V').Sans_pub, true);
  assert.equal((await C.expireSubscriptions(db, mk('system'))).expired, 0);
  NOW = new Date('2026-11-08T10:00:00Z');
});
test('mineur : abonnement refusé ; double validation impossible', async () => {
  const db = world();
  await assert.rejects(C.submitPayment(db, mk('M'), { kind: 'SANS_PUB', method: 'MTN_MOMO', mobileMoneyRef: 'SUB000030', birthDate: '2012-01-01' }), /18 ans/);
  const r = await subscribe(db, 'A', 'SUB000031');
  const res = await Promise.allSettled([confirm(db, r.txId), confirm(db, r.txId)]);
  assert.equal(res.filter((x) => x.status === 'fulfilled').length, 1);
  assert.equal(db.read('Joueurs/A').Sans_pub_fin, '2026-12-08T10:00:00.000Z', '30 jours une seule fois');
});
