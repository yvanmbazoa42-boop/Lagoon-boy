'use strict';
// Base mémoire imitant les règles des transactions Firestore : lectures avant écritures, create() échoue si le document existe,
// update() échoue si absent, transactions sérialisées. Ce N'EST PAS l'émulateur Firebase.
class FakeDb {
  constructor() { this.store = new Map(); this._q = Promise.resolve(); }
  doc(path) {
    const db = this;
    return {
      path,
      async get() { return snap(db.store, path); },
      async set(data, opts) { const cur = db.store.get(path); db.store.set(path, opts && opts.merge ? Object.assign({}, cur || {}, clone(data)) : clone(data)); },
      async update(data) {
        const cur = db.store.get(path); if (!cur) throw new Error('FAKE: NOT_FOUND ' + path);
        const nx = Object.assign({}, cur);
        for (const k of Object.keys(data)) { if (data[k] && data[k].__delete) delete nx[k]; else nx[k] = clone(data[k]); }
        db.store.set(path, nx);
      }
    };
  }
  collection(name) {
    const db = this; const filters = [];
    const api = { where(f, op, v) { if (op !== '==') throw new Error('FAKE: seul == est géré'); filters.push([f, v]); return api; }, async get() { const docs = []; for (const [p, v] of db.store) { if (p.startsWith(name + '/') && !p.slice(name.length + 1).includes('/') && filters.every(([f, x]) => v[f] === x)) docs.push({ id: p.slice(name.length + 1), data: () => clone(v) }); } return { docs }; } };
    return api;
  }
  seed(path, data) { this.store.set(path, JSON.parse(JSON.stringify(data))); }
  read(path) { const v = this.store.get(path); return v ? JSON.parse(JSON.stringify(v)) : undefined; }
  runTransaction(fn) {
    const run = async () => {
      const writes = []; let wrote = false;
      const tx = {
        async get(ref) { if (wrote) throw new Error('FAKE: lecture après écriture (interdit par Firestore)'); return snap(db.store, ref.path); },
        set(ref, data, opts) { wrote = true; writes.push(['set', ref.path, data, opts]); },
        create(ref, data) { wrote = true; writes.push(['create', ref.path, data]); },
        update(ref, data) { wrote = true; writes.push(['update', ref.path, data]); },
        delete(ref) { wrote = true; writes.push(['delete', ref.path]); }
      };
      const db = this;
      const result = await fn(tx);
      const staged = new Map(db.store);
      for (const [op, path, data, opts] of writes) {
        const cur = staged.get(path);
        if (op === 'create') { if (cur) throw new Error('FAKE: ALREADY_EXISTS ' + path); staged.set(path, clone(data)); }
        else if (op === 'update') { if (!cur) throw new Error('FAKE: NOT_FOUND ' + path); staged.set(path, Object.assign({}, cur, clone(data))); }
        else if (op === 'set') { staged.set(path, opts && opts.merge ? Object.assign({}, cur || {}, clone(data)) : clone(data)); }
        else if (op === 'delete') staged.delete(path);
      }
      db.store = staged; return result;
    };
    const p = this._q.then(run, run); this._q = p.catch(() => {}); return p;
  }
}
const clone = (x) => JSON.parse(JSON.stringify(x));
function snap(store, path) { const v = store.get(path); return { exists: v !== undefined, data: () => clone(v) }; }
module.exports = { FakeDb };
