'use strict';
// Unification des paiements : migration de l'ancien « En_attente » vers transactions (base mémoire, pas l'émulateur Firebase).
const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../lib/core'); const { FakeDb } = require('./fakedb');
const T0 = new Date('2026-11-08T10:00:00Z'); let n = 0;
const mk = (uid) => ({ uid, secret: 'test-secret-0123456789-abcdef', now: () => T0, newId: () => 'U' + String(++n).padStart(6, '0'), newCode: () => 'ABCD2345', proofMeta: async () => ({ size: 10, contentType: 'image/png' }) });
function world() {
  const db = new FakeDb();
  db.seed('admins/ADMIN', { ok: 1 });
  db.seed('Tournois/T1', { Nom: 'FF Cup', Statut: 'actif', Frais_instription: 1000, Max_joueurs: 8, Inscrits: '["Z"]',
    En_attente: JSON.stringify([ JSON.stringify({ playerId: 'A', pseudo: 'A', phone: '677000001', operator: 'MTN', frais: 1 }), { playerId: 'B', pseudo: 'B', phone: '699000002', operator: 'Orange Money', frais: 999999 }, 'pas du json', JSON.stringify({ playerId: 'Z' }), JSON.stringify({ playerId: 'GHOST' }) ]) });
  for (const u of ['A', 'B', 'Z']) db.seed('Joueurs/' + u, { Psuedo: 'P_' + u });
  return db;
}
test('import : montants du TOURNOI (pas de l\'ancienne donnée), factures d\'inscription, verrous, archive, entrées invalides ignorées', async () => {
  const db = world();
  const r = await C.importLegacyPending(db, mk('ADMIN'), { tournamentId: 'T1' });
  assert.equal(r.imported, 2); assert.equal(r.skipped.length, 3);
  const t = db.read('transactions/' + r.txIds[0]);
  assert.equal(t.amount, 1000); assert.equal(t.status, 'PENDING'); assert.equal(t.legacy, true); assert.equal(t.method, 'MTN_MOMO');
  assert.equal(db.read('transactions/' + r.txIds[1]).method, 'ORANGE_MONEY'); assert.equal(db.read('transactions/' + r.txIds[1]).amount, 1000);
  assert.equal(db.read('invoices/' + t.InvoiceNumber).type, 'REGISTRATION_INVOICE'); assert.equal(db.read('invoice_public/' + t.InvoiceNumber).verified, false);
  assert.ok(db.read('registrations/T1_A') && db.read('registrations/T1_B'));
  const tour = db.read('Tournois/T1'); assert.deepEqual(JSON.parse(tour.En_attente), []); assert.equal(JSON.parse(tour.En_attente_archive).length, 5, 'rien n\'est perdu : archive complète');
  assert.deepEqual(JSON.parse(tour.Inscrits), ['Z'], 'personne n\'est inscrit avant confirmation de paiement');
});
test('import : relancer ne crée aucun doublon ; non-admin refusé ; lot trop gros refusé', async () => {
  const db = world(); await C.importLegacyPending(db, mk('ADMIN'), { tournamentId: 'T1' });
  assert.equal((await C.importLegacyPending(db, mk('ADMIN'), { tournamentId: 'T1' })).imported, 0);
  await assert.rejects(C.importLegacyPending(world(), mk('A'), { tournamentId: 'T1' }), /administrateurs/);
  const big = world(); big.seed('Tournois/T2', { Nom: 'x', Frais_instription: 500, Inscrits: '[]', En_attente: JSON.stringify(Array.from({ length: 41 }, (_, i) => ({ playerId: 'P' + i }))) });
  await assert.rejects(C.importLegacyPending(big, mk('ADMIN'), { tournamentId: 'T2' }), /Trop de demandes/);
});
test('transaction héritée : validation impossible sans référence Mobile Money saisie par l\'admin ; référence unique ; puis inscrit + reçu + audit', async () => {
  const db = world(); const r = await C.importLegacyPending(db, mk('ADMIN'), { tournamentId: 'T1' });
  const [a, b] = r.txIds; const ok = { decision: 'APPROVE', confirmedReceived: true, receivedAmount: 1000 };
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId: a }, ok)), /Référence/);
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId: a, legacyRef: 'AB' }, ok)), /Référence/);
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), { txId: a, decision: 'APPROVE', confirmedReceived: false, receivedAmount: 1000, legacyRef: 'MP260101XY1' }), /exactement/);
  const out = await C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId: a, legacyRef: 'mp-2601-01xy1' }, ok));
  assert.equal(out.status, 'APPROVED'); assert.ok(out.receiptNumber);
  const t = db.read('transactions/' + a); assert.equal(t.mobileMoneyRef, 'MP260101XY1'); assert.equal(t.status, 'APPROVED');
  assert.deepEqual(JSON.parse(db.read('Tournois/T1').Inscrits).sort(), ['A', 'Z']);
  assert.equal(db.read('invoices/' + out.receiptNumber).type, 'PAYMENT_RECEIPT'); assert.equal(db.read('invoice_public/' + t.InvoiceNumber).verified, true);
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId: b, legacyRef: 'MP260101XY1' }, ok)), /déjà été utilisée/);
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), Object.assign({ txId: a, legacyRef: 'ZZZ99999' }, ok)), /Déjà traitée/);
});
test('transaction héritée refusée : raison obligatoire, historique conservé, verrou libéré', async () => {
  const db = world(); const r = await C.importLegacyPending(db, mk('ADMIN'), { tournamentId: 'T1' });
  await assert.rejects(C.reviewPayment(db, mk('ADMIN'), { txId: r.txIds[0], decision: 'REJECT' }), /raison/i);
  await C.reviewPayment(db, mk('ADMIN'), { txId: r.txIds[0], decision: 'REJECT', reason: 'Paiement introuvable' });
  const t = db.read('transactions/' + r.txIds[0]); assert.equal(t.status, 'REJECTED'); assert.equal(t.RejectReason, 'Paiement introuvable'); assert.equal(t.History.length, 2);
  assert.equal(db.read('registrations/T1_A'), undefined);
});
