'use strict';
// À LANCER avec l'émulateur :  firebase emulators:exec --only firestore,storage "node --test functions/test/rules.emulator.test.js"
// Nécessite : npm i -D @firebase/rules-unit-testing   — ÉCRIT MAIS NON EXÉCUTÉ dans la livraison (pas de réseau ni d'émulateur disponibles).
const test = require('node:test'); const fs = require('fs'); const path = require('path');
const { initializeTestEnvironment, assertFails, assertSucceeds } = require('@firebase/rules-unit-testing');
let env;
test.before(async () => {
  env = await initializeTestEnvironment({ projectId: 'evo-test', firestore: { rules: fs.readFileSync(path.join(__dirname, '../../firestore.rules'), 'utf8') } });
  await env.withSecurityRulesDisabled(async (c) => { const d = c.firestore();
    await d.doc('admins/ADMIN').set({ ok: 1 });
    await d.doc('transactions/TX1').set({ playerId: 'A', amount: 1000, status: 'PENDING' });
    await d.doc('invoices/EVO-INV-2026-000001').set({ playerId: 'A', amount: 1000 });
    await d.doc('invoice_public/EVO-INV-2026-000001').set({ number: 'EVO-INV-2026-000001', amount: 1000 });
    await d.doc('Joueurs_prive/A').set({ Naissance: '2000-01-01' });
    await d.doc('Tournois/T1').set({ Nom: 'x', Inscrits: '[]', En_attente: '[]' });
    await d.doc('Joueurs/A').set({ Psuedo: 'A', Solde: 0, Vies: 3 }); });
});
test.after(async () => env && env.cleanup());
const as = (uid) => env.authenticatedContext(uid).firestore();
test('un joueur lit sa transaction, pas celle d\'un autre', async () => {
  await assertSucceeds(as('A').doc('transactions/TX1').get()); await assertFails(as('B').doc('transactions/TX1').get()); await assertSucceeds(as('ADMIN').doc('transactions/TX1').get()); });
test('aucun client n\'écrit transactions, factures, wallets, referrals, prize_distributions', async () => {
  for (const p of ['transactions/TX1', 'invoices/X', 'wallets/A', 'referrals/A', 'prize_distributions/T1_1', 'referral_rewards/x', 'refunds/x', 'Joueurs_prive/A'])
    await assertFails(as('A').doc(p).set({ amount: 1 })); await assertFails(as('ADMIN').doc('transactions/TX1').update({ status: 'APPROVED' })); });
test('facture : lisible par son propriétaire et l\'admin seulement ; fiche publique lisible par tous', async () => {
  await assertSucceeds(as('A').doc('invoices/EVO-INV-2026-000001').get()); await assertFails(as('B').doc('invoices/EVO-INV-2026-000001').get());
  await assertSucceeds(env.unauthenticatedContext().firestore().doc('invoice_public/EVO-INV-2026-000001').get()); });
test('données privées : propriétaire et admin seulement', async () => {
  await assertSucceeds(as('A').doc('Joueurs_prive/A').get()); await assertFails(as('B').doc('Joueurs_prive/A').get()); });
test('un joueur ne modifie plus En_attente d\'un tournoi ni son Solde', async () => {
  await assertFails(as('A').doc('Tournois/T1').update({ En_attente: '[1]' })); await assertFails(as('A').doc('Joueurs/A').update({ Solde: 999 })); });

// ===== v16 : données privées, configuration financière, parrainage, abonnement =====
const unauth = () => env.unauthenticatedContext().firestore();
test('v16 profil PUBLIC : lisible par tous ; création/modification avec Tel, WhatsApp, Email, Tel_norm ou Naissance REFUSÉE', async () => {
  await assertSucceeds(unauth().doc('Joueurs/A').get());
  const base = { Psuedo: 'Nouveau', Solde: 0, Vies: 3, Eliminated: false, Statut: 'actif' };
  await assertSucceeds(as('NEW1').doc('Joueurs/NEW1').set(base));
  for (const f of ['Tel', 'WhatsApp', 'Email', 'Tel_norm', 'Naissance']) await assertFails(as('NEW2').doc('Joueurs/NEW2').set(Object.assign({}, base, { [f]: 'x' })));
  await assertFails(as('A').doc('Joueurs/A').update({ Tel: '677000000' })); await assertFails(as('A').doc('Joueurs/A').update({ Email: 'a@b.cd' }));
  await assertFails(as('ADMIN').doc('Joueurs/A').update({ WhatsApp: '677000000' }));
  await assertSucceeds(as('A').doc('Joueurs/A').update({ Bio: 'salut' }));
});
test('v16 espace PRIVÉ : lecture par le propriétaire et l\'admin seulement ; aucune écriture client (même propriétaire/admin) ; pas de lecture anonyme', async () => {
  await env.withSecurityRulesDisabled(async (c) => { await c.firestore().doc('Joueurs_prive/A').set({ Tel: '677000000', Email: 'a@b.cd', Naissance: '2000-01-01' }); });
  await assertSucceeds(as('A').doc('Joueurs_prive/A').get()); await assertSucceeds(as('ADMIN').doc('Joueurs_prive/A').get());
  await assertFails(as('B').doc('Joueurs_prive/A').get()); await assertFails(unauth().doc('Joueurs_prive/A').get());
  await assertFails(as('A').doc('Joueurs_prive/A').update({ Tel: '1' })); await assertFails(as('ADMIN').doc('Joueurs_prive/A').update({ Tel: '1' })); await assertFails(as('A').doc('Joueurs_prive/A').delete());
  await assertFails(as('B').collection('Joueurs_prive').get());      // pas de lecture en liste par un joueur
  await assertSucceeds(as('ADMIN').collection('Joueurs_prive').get()); // l'admin liste (export / support)
});
test('v16 index téléphone et limitation de tentatives : inaccessibles aux clients', async () => {
  for (const p of ['phone_index/677000000', 'rate_limits/abc']) { await assertFails(as('A').doc(p).get()); await assertFails(as('ADMIN').doc(p).get()); await assertFails(as('ADMIN').doc(p).set({ uid: 'A' })); await assertFails(unauth().doc(p).get()); }
});
test('v16 configuration financière : lecture par tout joueur connecté, écriture jamais par un client ; historique = admins ; tournament_finance = admins', async () => {
  await env.withSecurityRulesDisabled(async (c) => { const d = c.firestore(); await d.doc('finance_config/current').set({ version: 1, commissionPct: 20 }); await d.doc('finance_config_history/000001').set({ version: 1 }); await d.doc('tournament_finance/T1').set({ Collected: 1000 }); });
  await assertSucceeds(as('A').doc('finance_config/current').get()); await assertFails(unauth().doc('finance_config/current').get());
  await assertFails(as('ADMIN').doc('finance_config/current').set({ version: 2, commissionPct: 0 })); await assertFails(as('A').doc('finance_config/current').update({ commissionPct: 0 }));
  await assertSucceeds(as('ADMIN').doc('finance_config_history/000001').get()); await assertFails(as('A').doc('finance_config_history/000001').get()); await assertFails(as('ADMIN').doc('finance_config_history/000002').set({ x: 1 }));
  await assertSucceeds(as('ADMIN').doc('tournament_finance/T1').get()); await assertFails(as('A').doc('tournament_finance/T1').get());
});
test('v16 abonnement et parrainage : un joueur ne peut ni s\'activer Sans_pub ni se donner une récompense ni lire le parrainage d\'un autre', async () => {
  await assertFails(as('A').doc('Joueurs/A').update({ Sans_pub: true })); await assertFails(as('A').doc('Joueurs/A').update({ Sans_pub_fin: '2099-01-01' }));
  await env.withSecurityRulesDisabled(async (c) => { const d = c.firestore(); await d.doc('wallets/A').set({ FreeEntries: 0 }); await d.doc('referrals/F').set({ referredId: 'F', referrerId: 'A' }); await d.doc('referral_rewards/F_REFERRER').set({ beneficiaryId: 'A' }); });
  await assertFails(as('A').doc('wallets/A').update({ FreeEntries: 99 })); await assertSucceeds(as('A').doc('wallets/A').get()); await assertFails(as('B').doc('wallets/A').get());
  await assertSucceeds(as('A').doc('referrals/F').get()); await assertFails(as('B').doc('referrals/F').get()); await assertFails(as('A').doc('referral_rewards/F_REFERRER').update({ qty: 9 })); await assertFails(as('B').doc('referral_rewards/F_REFERRER').get());
  await assertFails(as('A').doc('referral_codes/ABCD2345').get());
});
test('v16 un client ne crée jamais de transaction, de facture, de gain ni de remboursement', async () => {
  for (const p of ['transactions/NEW', 'invoices/EVO-INV-2026-999999', 'invoice_public/EVO-INV-2026-999999', 'prize_distributions/T1_1', 'refunds/NEW', 'registrations/T1_A', 'payment_refs/ABC123456']) {
    await assertFails(as('A').doc(p).set({ playerId: 'A', amount: 1 })); await assertFails(as('ADMIN').doc(p).set({ playerId: 'A', amount: 1 })); }
});
