'use strict';
// Tests de la séparation PUBLIC / PRIVÉ (v16) — logique serveur sur base mémoire (ce n'est PAS l'émulateur Firebase).
const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../lib/core'); const { FakeDb } = require('./fakedb');
const { migrate } = require('../../scripts/migrate-private');
const T0 = new Date('2026-11-08T10:00:00Z'); let n = 0;
const mk = (uid) => ({ uid, secret: 'test-secret-0123456789-abcdef', now: () => T0, newId: () => 'ID' + (++n), newCode: () => 'ABCD2345' });
const world = () => { const db = new FakeDb(); db.seed('Joueurs/A', { Psuedo: 'A' }); db.seed('Joueurs/B', { Psuedo: 'B' }); return db; };

test('saveContact : écrit dans Joueurs_prive + index téléphone, JAMAIS dans le profil public', async () => {
  const db = world();
  const r = await C.saveContact(db, mk('A'), { tel: '677 12 34 56', email: 'A@Mail.com' });
  assert.equal(r.indexed, true);
  const priv = db.read('Joueurs_prive/A');
  assert.equal(priv.Tel, '677123456'); assert.equal(priv.WhatsApp, '677123456'); assert.equal(priv.Email, 'a@mail.com'); assert.equal(priv.Tel_norm, '677123456');
  assert.deepEqual(db.read('Joueurs/A'), { Psuedo: 'A' }, 'le profil public reste sans aucun contact');
  assert.equal(db.read('phone_index/677123456').uid, 'A');
});
test('saveContact : validation des entrées', async () => {
  const db = world();
  await assert.rejects(C.saveContact(db, mk('A'), { tel: 'abc' }), /invalide/i);
  await assert.rejects(C.saveContact(db, mk('A'), { email: 'pas-un-mail' }), /e-mail/i);
  await assert.rejects(C.saveContact(db, mk('A'), {}), /Rien/);
  await assert.rejects(C.saveContact(db, mk('ZZZ'), { tel: '677123456' }), /Profil/);
});
test('saveContact : un numéro déjà rattaché à un autre compte n\'est pas réattribué ; changement de numéro libère l\'ancien', async () => {
  const db = world();
  await C.saveContact(db, mk('A'), { tel: '677123456' });
  const r = await C.saveContact(db, mk('B'), { tel: '677123456' });
  assert.equal(r.indexed, false); assert.equal(db.read('phone_index/677123456').uid, 'A');
  await C.saveContact(db, mk('A'), { tel: '655000111' });
  assert.equal(db.read('phone_index/677123456'), undefined, 'ancien index libéré'); assert.equal(db.read('phone_index/655000111').uid, 'A');
});
test('findLoginEmail : retrouve le compte par numéro (usage serveur), inconnu -> null', async () => {
  const db = world();
  await C.saveContact(db, mk('A'), { tel: '677123456', email: 'a@mail.com' });
  const f = await C.findLoginEmail(db, '+237 677 12 34 56');
  assert.deepEqual(f, { uid: 'A', email: 'a@mail.com' });
  assert.equal(await C.findLoginEmail(db, '699999999'), null); assert.equal(await C.findLoginEmail(db, '12'), null);
});
test('rateLimit : bloque après le maximum, repart après la fenêtre', async () => {
  const db = world(); let now = T0.getTime(); const ctx = { now: () => new Date(now) };
  for (let i = 0; i < 3; i++) await C.rateLimit(db, ctx, 'login:677', 3, 60000);
  await assert.rejects(C.rateLimit(db, ctx, 'login:677', 3, 60000), /Trop de tentatives/);
  await C.rateLimit(db, ctx, 'login:autre', 3, 60000);
  now += 61000; await C.rateLimit(db, ctx, 'login:677', 3, 60000);
});
test('parrainage : le doublon de numéro est détecté dans l\'espace PRIVÉ', async () => {
  const db = world(); db.seed('Joueurs/C', { Psuedo: 'C' });
  await C.saveContact(db, mk('A'), { tel: '677123456' }); await C.saveContact(db, mk('C'), { tel: '677123456' });
  const { code } = await C.ensureReferralCode(db, mk('A'));
  assert.equal((await C.applyReferralCode(db, mk('C'), { code })).status, 'SUSPECT');
});
test('splitPlayerDoc : sépare le privé du public, garde tout le reste', () => {
  const { priv, remove } = C.splitPlayerDoc({ Psuedo: 'X', Tel: '677123456', WhatsApp: '677123456', Email: 'x@y.fr', Solde: 5 });
  assert.deepEqual(priv, { Tel: '677123456', WhatsApp: '677123456', Email: 'x@y.fr', Tel_norm: '677123456' });
  assert.deepEqual(remove.sort(), ['Email', 'Tel', 'WhatsApp']);
  assert.deepEqual(C.splitPlayerDoc({ Psuedo: 'Y' }).remove, []);
});
test('migration : simulation n\'écrit rien ; exécution copie, vérifie puis retire du public ; aucune donnée perdue ; idempotente', async () => {
  const db = new FakeDb(); const FieldValue = { delete: () => ({ __delete: true }) };
  db.seed('Joueurs/A', { Psuedo: 'A', Tel: '677123456', WhatsApp: '677123456', Email: 'a@mail.com', Solde: 10 });
  db.seed('Joueurs/B', { Psuedo: 'B', Tel: 'Non renseigné', WhatsApp: '655000111' });
  db.seed('Joueurs/C', { Psuedo: 'C' });
  const dry = await migrate(db, { apply: false, FieldValue });
  assert.equal(dry.toMigrate, 2); assert.equal(db.read('Joueurs_prive/A'), undefined); assert.equal(db.read('Joueurs/A').Tel, '677123456');
  const r = await migrate(db, { apply: true, FieldValue });
  assert.equal(r.migrated, 2); assert.equal(r.verified, 2);
  assert.deepEqual(db.read('Joueurs/A'), { Psuedo: 'A', Solde: 10 });
  assert.equal(db.read('Joueurs_prive/A').Email, 'a@mail.com'); assert.equal(db.read('Joueurs_prive/B').WhatsApp, '655000111');
  assert.equal(db.read('phone_index/677123456').uid, 'A');
  const again = await migrate(db, { apply: true, FieldValue });
  assert.equal(again.toMigrate, 0);
});

test('saveContact : un admin renseigne le contact d\'un joueur qu\'il a créé ; un joueur ordinaire ne peut pas viser un autre compte', async () => {
  const db = world(); db.seed('admins/ADMIN', { ok: 1 });
  await assert.rejects(C.saveContact(db, mk('A'), { playerId: 'B', tel: '677123456' }), /administrateurs/);
  assert.equal(db.read('Joueurs_prive/B'), undefined);
  await C.saveContact(db, mk('ADMIN'), { playerId: 'B', tel: '677123456', whatsapp: '655000111' });
  assert.equal(db.read('Joueurs_prive/B').WhatsApp, '655000111'); assert.equal(db.read('phone_index/677123456').uid, 'B'); assert.deepEqual(db.read('Joueurs/B'), { Psuedo: 'B' });
});
