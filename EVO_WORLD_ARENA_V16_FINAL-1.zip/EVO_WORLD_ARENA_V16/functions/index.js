'use strict';
// Cloud Functions EVO WORLD ARENA — enveloppes minces autour de lib/core.js (toute la logique testée est dans core.js).
// Secret requis :  firebase functions:secrets:set INVOICE_SECRET   (≥ 16 caractères aléatoires, ne JAMAIS le mettre dans le site)
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
const crypto = require('crypto');
const core = require('./lib/core');
admin.initializeApp();
const db = admin.firestore();
const OPTS = { secrets: ['INVOICE_SECRET'], enforceAppCheck: process.env.ENFORCE_APPCHECK === '1' };

const ctxFor = (uid) => ({
  uid, secret: process.env.INVOICE_SECRET, now: () => new Date(),
  newId: () => crypto.randomBytes(5).toString('hex'),
  newCode: () => Array.from(crypto.randomBytes(8)).map((b) => core.CODE_ALPHABET[b % core.CODE_ALPHABET.length]).join(''),
  proofMeta: async (path) => {
    const f = admin.storage().bucket().file(path); const [ex] = await f.exists(); if (!ex) return null;
    const [m] = await f.getMetadata(); return { size: Number(m.size), contentType: m.contentType };
  }
});
function callable(fn) {
  return functions.runWith(OPTS).https.onCall(async (data, context) => {
    if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Connexion requise.');
    try { return await fn(db, ctxFor(context.auth.uid), data || {}); }
    catch (e) {
      if (e instanceof core.HttpErr) throw new functions.https.HttpsError(e.code, e.message);
      console.error(e); throw new functions.https.HttpsError('internal', 'Erreur serveur.');
    }
  });
}
exports.submitPayment = callable(core.submitPayment);
exports.attachProof = callable(core.attachProof);
exports.reviewPayment = callable(core.reviewPayment);
exports.recordRefund = callable(core.recordRefund);
exports.confirmRefundTransfer = callable(core.confirmRefundTransfer);
exports.ensureReferralCode = callable(core.ensureReferralCode);
exports.applyReferralCode = callable(core.applyReferralCode);
exports.setReferralStatus = callable(core.setReferralStatus);
exports.prepareWinnings = callable(core.prepareWinnings);
exports.confirmPrizePaid = callable(core.confirmPrizePaid);
exports.saveContact = callable(core.saveContact);
exports.setFinanceConfig = callable(core.setFinanceConfig);
exports.importLegacyPending = callable(core.importLegacyPending);

// ---- v16 : connexion par numéro et mot de passe oublié SANS exposer e-mail ni téléphone ----
// Fonctions publiques (appelées avant connexion). Anti force brute : limitation par numéro/identifiant ET par adresse IP.
// WEB_API_KEY = clé Web Firebase (publique par conception, déjà présente dans firebase-config.js) : voir functions/.env
const WEB_API_KEY = () => process.env.WEB_API_KEY || '';
async function idToolkit(path, body) {
  const r = await fetch('https://identitytoolkit.googleapis.com/v1/' + path + '?key=' + encodeURIComponent(WEB_API_KEY()), {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  let j = {}; try { j = await r.json(); } catch (e) {}
  return { ok: r.ok, json: j };
}
function publicCallable(fn) {
  return functions.runWith({ enforceAppCheck: process.env.ENFORCE_APPCHECK === '1' }).https.onCall(async (data, context) => {
    try {
      const ip = (context.rawRequest && (context.rawRequest.headers['x-forwarded-for'] || context.rawRequest.ip)) || 'noip';
      await core.rateLimit(db, ctxFor(null), 'ip:' + String(ip).split(',')[0].trim(), 40, 10 * 60 * 1000);
      return await fn(data || {});
    } catch (e) {
      if (e instanceof core.HttpErr) throw new functions.https.HttpsError(e.code, e.message);
      console.error(e); throw new functions.https.HttpsError('internal', 'Erreur serveur.');
    }
  });
}
const BAD_LOGIN = () => { throw new functions.https.HttpsError('permission-denied', 'Identifiants incorrects.'); };
exports.phoneSignIn = publicCallable(async (data) => {
  const phone = String(data.phone || ''), password = String(data.password || '');
  if (core.phoneKey(phone).length < 8 || password.length < 6 || password.length > 200) BAD_LOGIN();
  await core.rateLimit(db, ctxFor(null), 'login:' + core.phoneKey(phone), 8, 15 * 60 * 1000);
  const found = await core.findLoginEmail(db, phone);
  if (!found) BAD_LOGIN();
  const r = await idToolkit('accounts:signInWithPassword', { email: found.email, password, returnSecureToken: false });
  if (!r.ok) BAD_LOGIN();
  return { token: await admin.auth().createCustomToken(found.uid) };
});
exports.requestPasswordReset = publicCallable(async (data) => {
  const id = String(data.identifier || '').trim();
  await core.rateLimit(db, ctxFor(null), 'reset:' + id.toLowerCase(), 4, 60 * 60 * 1000);
  let email = core.isEmail(id) ? id.toLowerCase() : null;
  if (!email) { const f = await core.findLoginEmail(db, id); email = f && f.email; }
  if (email) { try { await idToolkit('accounts:sendOobCode', { requestType: 'PASSWORD_RESET', email }); } catch (e) { console.error('reset', e.message); } }
  return { ok: true }; // réponse identique que le compte existe ou non (pas d'énumération de comptes)
});

// Page publique /verify-invoice : renvoie uniquement numéro, montant, date, type, statut (+ validité de la signature du QR)
exports.verifyInvoice = functions.runWith({ secrets: ['INVOICE_SECRET'] }).https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*'); res.set('Cache-Control', 'no-store');
  try { res.json(await core.verifyInvoice(db, process.env.INVOICE_SECRET, String(req.query.id || ''), req.query.sig ? String(req.query.sig) : '')); }
  catch (e) { console.error(e); res.status(500).json({ found: false, error: 'server' }); }
});

// Expiration automatique des abonnements Sans pub (tous les jours à 01:00, heure de Douala). Nécessite le forfait Blaze (Cloud Scheduler).
exports.expireSubscriptions = functions.pubsub.schedule('0 1 * * *').timeZone('Africa/Douala').onRun(async () => {
  const r = await core.expireSubscriptions(db, ctxFor('system')); console.log('Abonnements expirés :', r.expired); return null;
});
