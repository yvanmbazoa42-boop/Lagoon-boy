// EVO ARENA v15 — client des Cloud Functions de paiement (aucune logique financière ici : le serveur décide de tout).
const EvoPay = (function () {
  const REGION_URL = 'https://us-central1-' + FIREBASE_CONFIG.projectId + '.cloudfunctions.net';
  const call = (name) => async function (data) {
    if (typeof firebase.functions !== 'function') throw new Error('Module Cloud Functions non chargé.');
    try { const r = await firebase.functions().httpsCallable(name)(data || {}); return r.data; }
    catch (e) { throw new Error((e && e.message) ? String(e.message).replace(/^.*?: /, '') : 'Erreur serveur'); }
  };
  const LABELS = { PENDING: 'En attente', UNDER_REVIEW: 'En vérification', APPROVED: 'Confirmée', REJECTED: 'Refusée', REFUNDED: 'Remboursée', PAID: 'Versé', DUE: 'À verser', REFUND_RECORDED: 'Remboursement enregistré' };
  const TYPES = { REGISTRATION_INVOICE: "Facture d'inscription", PAYMENT_RECEIPT: 'Reçu de paiement confirmé', REFUND_RECEIPT: 'Reçu de remboursement', SUBSCRIPTION_INVOICE: 'Facture abonnement Sans pub', PRIZE_RECEIPT: 'Reçu de gain versé', ADMIN_VOUCHER: 'Justificatif de transaction' };
  async function uploadProof(txId, file) {
    if (!file) throw new Error('Choisis une capture.');
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) throw new Error('La capture doit être une image PNG, JPEG ou WebP.');
    if (file.size > 5 * 1024 * 1024) throw new Error('Capture trop lourde (5 Mo max).');
    if (typeof firebase.storage !== 'function') throw new Error('Module Firebase Storage non chargé.');
    const u = await EvoAuth.current(); const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
    const path = 'payment_proofs/' + u.id + '/' + txId + '/' + Date.now() + '.' + ext;
    await firebase.storage().ref(path).put(file, { contentType: file.type });
    return call('attachProof')({ txId, path });
  }
  // Lien de parrainage ?ref=CODE : mémorisé puis appliqué dès que le joueur est connecté (une seule tentative réussie)
  try { const p = new URLSearchParams(location.search).get('ref'); if (p && /^[A-Za-z2-9]{8}$/.test(p)) localStorage.setItem('evo_ref', p.toUpperCase()); } catch (e) {}
  async function tryApplyRef() {
    let c; try { c = localStorage.getItem('evo_ref'); } catch (e) {} if (!c) return;
    try { await EvoAuth.current(); await call('applyReferralCode')({ code: c }); localStorage.removeItem('evo_ref'); }
    catch (e) { if (/déjà|propre|inconnu|invalide|avant ta première/i.test(String(e.message))) { try { localStorage.removeItem('evo_ref'); } catch (e2) {} } }
  }
  setTimeout(tryApplyRef, 3500);
  return { submitPayment: call('submitPayment'), attachProof: call('attachProof'), reviewPayment: call('reviewPayment'), recordRefund: call('recordRefund'),
    confirmRefundTransfer: call('confirmRefundTransfer'), ensureReferralCode: call('ensureReferralCode'), applyReferralCode: call('applyReferralCode'),
    setReferralStatus: call('setReferralStatus'), setFinanceConfig: call('setFinanceConfig'), importLegacyPending: call('importLegacyPending'), saveContact: call('saveContact'), prepareWinnings: call('prepareWinnings'), confirmPrizePaid: call('confirmPrizePaid'),
    uploadProof, LABELS, TYPES, VERIFY_URL: REGION_URL + '/verifyInvoice' };
})();
