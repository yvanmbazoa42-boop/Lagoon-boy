// EVO ARENA — fonctions partagées (le SDK et la configuration sont dans firebase-config.js)

// ============================================================
// HELPERS PARTAGÉS
// ============================================================

// Convertit un numéro de téléphone en "email" (Firebase Auth exige un email)
function telToEmail(tel) {
  return tel.replace(/\s/g, '') + '@evoarena.cm';
}


// ============================================================
// SÉCURITÉ / ROBUSTESSE — partagés par toutes les pages
// ============================================================
function escapeHtml(str) { if (str === null || str === undefined) return ''; return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
// Lien/URL d'image sûr : seulement http(s) ou image data:, sans guillemets. urlBrute = pour du JS/CSS, urlSure = pour du HTML.
function urlBrute(u) {
  try {
    u = String(u == null ? '' : u).trim(); if (!u) return '';
    if (/^data:image\/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+\/=]+$/i.test(u)) return u;
    const x = new URL(u, location.href); if (x.protocol !== 'https:' && x.protocol !== 'http:') return '';
    return x.href.replace(/'/g, '%27').replace(/"/g, '%22').replace(/</g, '%3C').replace(/>/g, '%3E').replace(/`/g, '%60').replace(/\\/g, '%5C');
  } catch (e) { return ''; }
}
function urlSure(u) { return urlBrute(u).replace(/&/g, '&amp;'); }
// Argument JS sûr à placer dans un onclick="..." : jsArg(x) -> decodeURIComponent('x%20encodé')  (aucun guillemet, aucune apostrophe possible)
function jsArg(x) { return "decodeURIComponent('" + encodeURIComponent(String(x == null ? '' : x)).replace(/'/g, '%27') + "')"; }
// Couleurs CSS : seulement #hex, rgb(), hsl(), var(--x) ; sinon valeur par défaut
function couleurSure(c, defaut) { c = String(c == null ? '' : c).trim(); return /^(#[0-9a-f]{3,8}|(rgb|hsl)a?\([0-9 ,.%]+\)|var\(--[a-z0-9-]+(,\s*#[0-9a-f]{3,8})?\))$/i.test(c) ? c : (defaut || ''); }

// Aucune erreur silencieuse : on évite l'écran blanc et on prévient le joueur (max 1 message / 5 s)
(function () {
  let dernier = 0;
  function prevenir(msg) {
    if (Date.now() - dernier < 5000) return; dernier = Date.now();
    try { if (typeof showToast === 'function') showToast('⚠️ ' + msg, 'error'); } catch (e) {}
  }
  window.addEventListener('unhandledrejection', function (e) {
    const r = e && e.reason; const code = r && r.code;
    console.warn('[EVO] promesse rejetée :', r);
    if (code === 'permission-denied') prevenir('Action non autorisée. Reconnecte-toi si le problème continue.');
    else if (code === 'unavailable' || code === 'auth/network-request-failed' || (r && /réseau|network|timeout/i.test(String(r.message || r)))) prevenir('Réseau instable : réessaie dans un instant.');
  });
  window.addEventListener('error', function (e) { console.warn('[EVO] erreur :', e && e.message); });
})();
// Économie de lectures : les rafraîchissements automatiques se mettent en pause quand l'onglet/app est en arrière-plan
(function () {
  const _si = window.setInterval;
  window.setInterval = function (fn, ms) {
    const args = Array.prototype.slice.call(arguments, 2);
    return _si.apply(window, [function () { if (document.hidden) return; return fn.apply(this, arguments); }, ms].concat(args));
  };
})();

// Pseudo gardé sur l'appareil (évite que le nom change d'un coup pendant le chargement)
function pseudoCache(id, defaut) {
  try { const c = JSON.parse(localStorage.getItem('evo_c:Joueurs/' + id) || 'null'); if (c && c.Psuedo) return c.Psuedo; } catch (e) {}
  return defaut;
}
// Quand le serveur apporte une version plus récente de ma fiche, je mets à jour l'objet joueur de la page
window.addEventListener('evo-fresh', function (e) {
  try { const d = e.detail || {}; if (d.doc && typeof userConnecte !== 'undefined' && userConnecte && userConnecte.id === d.id) Object.assign(userConnecte, d.doc); } catch (x) {}
});

// Réduit une image AVANT l'envoi (une photo de téléphone fait 3-6 Mo : l'avatar n'en a besoin que de ~60 Ko).
// Rend le site beaucoup plus rapide pour tout le monde et économise le stockage.
async function compresserImage(file, cote, qualite) {
  try {
    if (!file || !/^image\/(jpeg|png|webp)$/i.test(file.type)) return file; // gif/vidéo : inchangé
    if (file.size < 150 * 1024) return file;                                 // déjà léger
    const bmp = await createImageBitmap(file);
    const r = Math.min(1, cote / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * r), h = Math.round(bmp.height * r);
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    cv.getContext('2d').drawImage(bmp, 0, 0, w, h);
    const blob = await new Promise(ok => cv.toBlob(ok, 'image/jpeg', qualite));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], (file.name || 'image').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
  } catch (e) { return file; }
}

// Upload un fichier vers Firebase et retourne son URL de visualisation
// opts.cote = taille max en pixels (avatar : 512, couverture : 1280, défaut : 1600)
async function uploadFichier(file, opts) {
  opts = opts || {};
  file = await compresserImage(file, opts.cote || 1600, 0.82);
  return await EvoStorage.upload(file);
}

// Vérifie si l'utilisateur connecté est admin (un document existe dans la collection "admins")
async function estAdmin(userId) {
  if (!userId) return false;
  try {
    await EvoDB.get(COLLECTIONS.ADMINS, userId);
    return true;
  } catch (e) {
    return false;
  }
}

// ============================================================
// Les listes (inscrits, membres, commentaires…) sont stockées comme texte JSON dans Firestore.
// arrGet lit une liste depuis un document, arrSet la prépare pour l'écriture.
// ============================================================
function arrGet(doc, field) {
  const v = doc && doc[field];
  if (Array.isArray(v)) return v;
  if (!v) return [];
  try {
    const parsed = JSON.parse(v);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}
function arrSet(list) {
  return JSON.stringify(list || []);
}

// ============================================================
// PUBS — affichées sauf si le joueur a l'option "Sans pub" (champ booléen Sans_pub dans la collection Joueurs)
// ============================================================
const PRIX_SANS_PUB = 1000;           // FCFA PAR MOIS — modifiable ici
const DUREE_SANS_PUB_JOURS = 30;       // durée d'un abonnement "sans pub"
// Abonnement actif ? (Sans_pub = true ET date de fin pas encore dépassée ; sans date de fin = illimité)
function sansPubActif(d) {
  if (!d || d.Sans_pub !== true) return false;
  if (!d.Sans_pub_fin) return true;
  const f = new Date(d.Sans_pub_fin);
  return isNaN(f) || f > new Date();
}
function sansPubJoursRestants(d) {
  if (!sansPubActif(d) || !d.Sans_pub_fin) return null;
  return Math.max(0, Math.ceil((new Date(d.Sans_pub_fin) - new Date()) / 86400000));
}
function sansPubFinTexte(d) {
  if (!d || !d.Sans_pub_fin) return '';
  const f = new Date(d.Sans_pub_fin);
  return isNaN(f) ? '' : f.toLocaleDateString('fr-FR');
}
const WHATSAPP_CEO = '237658946362';  // numéro WhatsApp du CEO (préviens-moi après paiement)
const NUMERO_PAIEMENT = '656134780';  // numéro Mobile Money qui reçoit les paiements


// ============================================================
// AFFICHAGE IMMÉDIAT : si le joueur était connecté, on montre son nom tout de suite
// (au lieu des boutons CONNEXION / INSCRIPTION) pendant que Firebase vérifie la session.
// ============================================================
(function () {
  if (/admin\.html/i.test(location.pathname)) return;
  const h = EvoAuth.hint();
  document.addEventListener('DOMContentLoaded', function () {
    const nav = document.getElementById('navButtons');
    const original = nav ? nav.innerHTML : '';
    if (h) {
      if (nav) nav.innerHTML = '<span class="btn btn-connecte">👤 ' + String(pseudoCache(h.id, h.name) || 'Gameur').replace(/[<>&"']/g, '') + '</span><button class="btn btn-danger" onclick="logoutUser()">DÉCO</button>';
      const ecran = document.getElementById('authScreen'), panneau = document.getElementById('panel');
      if (ecran && panneau) { ecran.style.display = 'none'; panneau.style.display = 'block'; }
    }
    _authReady.then(function () {
      if (h && !_auth.currentUser) {
        document.documentElement.classList.remove('evo-connu');
        if (nav) nav.innerHTML = original;
        const ecran = document.getElementById('authScreen'), panneau = document.getElementById('panel');
        if (ecran && panneau) { ecran.style.display = 'flex'; panneau.style.display = 'none'; }
      }
    });
  });
})();

// ============================================================
// CONNEXION / INSCRIPTION JOUEUR (communes à index.html et profil.html)
// Méthodes activées dans Firebase : E-mail/Mot de passe, Téléphone (SMS), Google.
// - Un joueur peut s'inscrire avec son NUMÉRO (compte « numéro@evoarena.cm » en interne)
//   et, facultativement, un VRAI E-MAIL (pour récupérer son mot de passe).
// - Il se connecte avec son numéro OU son e-mail + mot de passe, ou avec Google, ou par SMS.
// ============================================================
function numeroNormalise(tel) {
  let d = String(tel || '').replace(/\D/g, '');
  if (d.indexOf('237') === 0 && d.length >= 12) d = d.slice(3);
  return d;
}
function estEmail(txt) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(txt || '').trim()); }

async function creerCompteJoueur(pseudo, tel, pass, emailReel) {
  pseudo = String(pseudo || '').replace(/[<>"'`\\]/g, '').trim();
  if (pseudo.length < 3) throw new Error('Pseudo trop court (3 caractères minimum, sans < > " \').');
  if (String(pass || '').length < 8) throw new Error('Mot de passe trop court (8 caractères minimum).');
  if (!/^\+?[0-9 ]{8,15}$/.test(String(tel || '').trim())) throw new Error('Numéro invalide. Exemple : 6XX XX XX XX');
  if (pseudo.length > 50) throw new Error('Pseudo trop long (50 caractères maximum).');
  if (tel.length > 20) throw new Error('Numéro trop long (20 caractères maximum).');
  emailReel = String(emailReel || '').trim().toLowerCase();
  if (emailReel && !estEmail(emailReel)) throw new Error('Adresse e-mail invalide.');
  const email = emailReel || telToEmail(tel);
  try { await EvoAuth.signOut(); } catch (e) {}
  let user;
  try {
    user = await EvoAuth.signUp(email, pass, pseudo);
  } catch (err) {
    if (err && err.code === 'auth/email-already-in-use') {
      const deja = new Error(emailReel ? 'Cet e-mail est déjà inscrit. Connecte-toi avec ton mot de passe.' : 'Ce numéro est déjà inscrit. Connecte-toi avec ton mot de passe.');
      try {
        await EvoAuth.signIn(email, pass);
        user = await EvoAuth.current();
      } catch (e2) { throw deja; }
      let profilExiste = true;
      try { await EvoDB.get(COLLECTIONS.PLAYERS, user.id); }
      catch (e3) { if (e3 && e3.code === 'not-found') profilExiste = false; }
      if (profilExiste) { try { await EvoAuth.signOut(); } catch (e4) {} throw deja; }
    } else { throw err; }
  }
  // v16 : le profil public ne contient AUCUNE donnée de contact ; téléphone et e-mail partent dans l'espace privé (serveur)
  const playerData = { Psuedo: pseudo, Solde: 0, Vies: 3, Statut: 'actif', Match_gagnes: 0, Match_perdus: 0, Eliminated: false, Bio: '', Stars: 3, Followers: 0, Following: 0, Likes: 0 };
  await EvoDB.create(COLLECTIONS.PLAYERS, user.id, playerData);
  try { await EvoFn.call('saveContact', { tel: tel, whatsapp: tel, email: emailReel || undefined }); }
  catch (e) { console.error('Contact privé non enregistré :', e.message); }
  return { id: user.id, ...playerData };
}


// ============================================================
// v16 — contacts PRIVÉS des joueurs, réservés à l'administration (Joueurs_prive : lecture admin seulement par les règles Firestore)
// Fusionne Tel / WhatsApp / Email EN MÉMOIRE dans la liste passée ; rien n'est réécrit dans le profil public.
// ============================================================
let _contactsCache = { t: 0, map: null };
async function chargerContactsPrives() {
  if (_contactsCache.map && Date.now() - _contactsCache.t < 60000) return _contactsCache.map;
  const map = {};
  try { const r = await EvoDB.list('Joueurs_prive', [Q.limit(2000)]); (r.documents || []).forEach(function (d) { map[d.id] = d; }); }
  catch (e) { console.warn('Contacts privés indisponibles (réservé aux administrateurs) :', e && e.message); }
  _contactsCache = { t: Date.now(), map: map };
  return map;
}
async function fusionnerContacts(liste) {
  const map = await chargerContactsPrives();
  (liste || []).forEach(function (p) { const c = map[p.id]; if (c) { p.Tel = c.Tel || ''; p.WhatsApp = c.WhatsApp || c.Tel || ''; p.Email = c.Email || ''; } });
  return liste;
}

// Connexion par « numéro OU e-mail » + mot de passe. Retourne { id }.
async function connecterJoueur(identifiant, pass) {
  identifiant = String(identifiant || '').trim();
  if (estEmail(identifiant)) return EvoAuth.signIn(identifiant.toLowerCase(), pass);
  try { return await EvoAuth.signIn(telToEmail(identifiant), pass); }
  catch (e) {
    // Joueur inscrit avec un vrai e-mail : le SERVEUR vérifie numéro + mot de passe et renvoie un jeton (l'e-mail n'est jamais exposé)
    try {
      const r = await EvoFn.call('phoneSignIn', { phone: identifiant, password: pass });
      if (r && r.token) return await EvoAuth.signInWithToken(r.token);
    } catch (e2) {}
    throw e;
  }
}

// Mot de passe oublié : le serveur envoie l'e-mail de réinitialisation si le compte en a un ; réponse identique dans tous les cas
async function motDePasseOublie(identifiant) {
  identifiant = String(identifiant || '').trim();
  if (!identifiant) throw new Error('Entre d\'abord ton e-mail ou ton numéro.');
  await EvoFn.call('requestPasswordReset', { identifier: identifiant });
  return identifiant;
}

// ============================================================
// RÉGIE LIVE — analyse d'un lien de flux et construction du lecteur
// Utilisé par admin.html (aperçu) ET live.html (diffusion).
// Supporte : YouTube, Facebook, Twitch, fichiers vidéo directs (.mp4/.webm), HLS (.m3u8).
// ============================================================
function nettoyerLienLive(brut) {
  if (!brut) return '';
  const m = String(brut).match(/https?:\/\/[^\s"'<>]+/i); // accepte un lien collé avec du texte autour ou glissé depuis une page
  return m ? m[0].trim() : '';
}
function analyserLienLive(brut) {
  const url = nettoyerLienLive(brut);
  if (!url) return null;
  let m = url.match(/(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|live\/|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (m) return { url, type: 'youtube', label: 'YouTube', ytId: m[1], src: 'https://www.youtube.com/embed/' + m[1] + '?autoplay=1&rel=0&playsinline=1' };
  if (/facebook\.com|fb\.watch/i.test(url))
    return { url, type: 'facebook', label: 'Facebook', src: 'https://www.facebook.com/plugins/video.php?href=' + encodeURIComponent(url) + '&show_text=false&autoplay=true' };
  m = url.match(/twitch\.tv\/(?:videos\/(\d+)|([a-zA-Z0-9_]{3,25}))(?:[/?#]|$)/i);
  if (m) {
    const parent = encodeURIComponent(location.hostname || 'localhost');
    const src = m[1]
      ? 'https://player.twitch.tv/?video=v' + m[1] + '&parent=' + parent + '&autoplay=true'
      : 'https://player.twitch.tv/?channel=' + m[2] + '&parent=' + parent + '&autoplay=true';
    return { url, type: 'twitch', label: 'Twitch', src };
  }
  if (/\.m3u8(\?|#|$)/i.test(url)) return { url, type: 'hls', label: 'Flux HLS (.m3u8)', src: url };
  if (/\.(mp4|webm|ogg|mov)(\?|#|$)/i.test(url)) return { url, type: 'video', label: 'Vidéo directe', src: url };
  return { url, type: 'externe', label: 'Lien externe', src: url };
}
// Écrit le lecteur dans `conteneur` (un élément DOM) avec le lecteur EVO (player.js — design maison).
// opts : { muet:true (démarre sans son), hauteur:'200px' (aperçu), titre:'…', live:false (replay) }
function afficherLecteurLive(conteneur, brut, opts) {
  opts = opts || {};
  const info = analyserLienLive(brut);
  if (!conteneur) return info;
  if (conteneur._evp) { try { conteneur._evp.destroy(); } catch (e) {} conteneur._evp = null; }
  if (!info) { conteneur.innerHTML = ''; return null; }
  if (info.type === 'externe') {
    conteneur.innerHTML = '<div style="color:#93c5fd;text-align:center;padding:24px">📹 Ce lien ne peut pas être intégré directement.<br><a href="' + info.url.replace(/"/g, '&quot;') + '" target="_blank" rel="noopener noreferrer" style="color:var(--c1,#00ff88)">Ouvrir le live ↗</a></div>';
    return info;
  }
  const monter = () => { if (window.EvoPlayer) EvoPlayer.mount(conteneur, info, opts); };
  if (window.EvoPlayer) monter();
  else { // player.js pas encore chargé : on le charge puis on monte le lecteur
    const sc = document.createElement('script'); sc.src = 'player.js'; sc.onload = monter;
    sc.onerror = () => { conteneur.innerHTML = '<div style="color:#f59e0b;padding:20px;text-align:center">⚠️ Lecteur indisponible. <a href="' + info.url.replace(/"/g, '&quot;') + '" target="_blank" rel="noopener noreferrer" style="color:var(--c1,#00ff88)">Ouvrir le live ↗</a></div>'; };
    document.head.appendChild(sc);
  }
  return info;
}
// Vide un conteneur en arrêtant proprement le lecteur (sinon le son peut continuer en arrière-plan)
function viderLecteurLive(conteneur) {
  if (!conteneur) return;
  if (conteneur._evp) { try { conteneur._evp.destroy(); } catch (e) {} conteneur._evp = null; }
  conteneur.innerHTML = '';
}
// Lit la diffusion principale (null si aucune / collection absente)
async function lireDiffusionPrincipale() {
  try {
    const d = await EvoDB.get(COLLECTIONS.LIVE_STREAM, LIVE_DOC_ID);
    return d;
  } catch (e) { return null; }
}

// ============================================================
// TEMPS RÉEL (Firestore onSnapshot) — en plus du rafraîchissement automatique existant.
// Si le temps réel échoue, le site continue de fonctionner par rafraîchissement régulier (rien ne casse).
// ============================================================
function ecouterTempsReel(collectionId, callback) {
  try {
    let t = null;
    return EvoDB.listen(collectionId, function () {
      clearTimeout(t);
      t = setTimeout(function () { try { callback(); } catch (e) {} }, 300);
    });
  } catch (e) { return null; }
}


// ============================================================
// CONNEXION GOOGLE — fournisseur « Google » activé dans Firebase → Authentication
// ============================================================
function connexionSociale() {
  const retour = location.href.split('#')[0];
  EvoAuth.signInGoogle(retour).catch(function (e) { alert('Connexion Google impossible : ' + (e.message || e)); });
}
// Crée la fiche joueur d'un compte venu de Google ou du SMS (pas de numéro de téléphone au départ pour Google)
async function creerProfilSocial(u) {
  const tel = (u.phone || '').replace(/^\+237/, '');
  const pseudo = String(u.name || (u.email ? u.email.split('@')[0] : (tel ? 'Gamer' + tel.slice(-4) : 'Gamer'))).slice(0, 50);
  const data = { Psuedo: pseudo, Solde: 0, Vies: 3, Statut: 'actif', Match_gagnes: 0, Match_perdus: 0, Eliminated: false, Bio: '', Stars: 3, Followers: 0, Following: 0, Likes: 0 };
  if (tel) data.Tel_verifie = true;   // simple indicateur public « numéro vérifié » (le numéro lui-même reste privé)
  await EvoDB.create(COLLECTIONS.PLAYERS, u.id, data);
  if (u.email || tel) { try { await EvoFn.call('saveContact', { tel: tel || undefined, whatsapp: tel || undefined, email: u.email || undefined }); } catch (e) { console.error('Contact privé non enregistré :', e.message); } }
}

// ------------------------------------------------------------
// CONNEXION PAR SMS — fenêtre en 2 étapes (numéro → code reçu)
// ------------------------------------------------------------
function smsLogin() {
  if (document.getElementById('evoSmsModal')) return;
  const ov = document.createElement('div');
  ov.id = 'evoSmsModal';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px';
  ov.innerHTML = '<div style="background:#0d0d24;border:1px solid rgba(0,255,136,.3);border-radius:16px;padding:22px;width:100%;max-width:360px;font-family:system-ui,sans-serif;color:#e5e7eb">'
    + '<h3 style="margin:0 0 6px;color:#00ff88;font-size:1.05rem">📱 Connexion par SMS</h3>'
    + '<p id="smsAide" style="margin:0 0 12px;font-size:.78rem;color:#94a3b8">Entre ton numéro : tu recevras un code par SMS.</p>'
    + '<input id="smsNum" type="tel" placeholder="6XX XX XX XX" autocomplete="tel" style="width:100%;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #334155;background:#111827;color:#fff;font-size:1rem;margin-bottom:8px">'
    + '<input id="smsCode" type="text" inputmode="numeric" maxlength="6" placeholder="Code à 6 chiffres" autocomplete="one-time-code" style="display:none;width:100%;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #334155;background:#111827;color:#fff;font-size:1.1rem;letter-spacing:4px;text-align:center;margin-bottom:8px">'
    + '<div id="smsErr" style="display:none;color:#f87171;font-size:.78rem;margin-bottom:8px"></div>'
    + '<button id="smsGo" style="width:100%;padding:12px;border:none;border-radius:10px;background:#0ea5e9;color:#fff;font-weight:700;cursor:pointer">ENVOYER LE CODE</button>'
    + '<button id="smsNo" style="width:100%;padding:10px;margin-top:6px;border:none;background:none;color:#94a3b8;cursor:pointer">Annuler</button></div>';
  document.body.appendChild(ov);
  const $ = id => document.getElementById(id);
  let vid = null;
  const erreur = m => { $('smsErr').textContent = '❌ ' + m; $('smsErr').style.display = 'block'; };
  $('smsNo').onclick = () => ov.remove();
  $('smsGo').onclick = async () => {
    const btn = $('smsGo'); $('smsErr').style.display = 'none'; btn.disabled = true;
    try {
      if (!vid) {
        btn.textContent = '⏳ Envoi…';
        vid = await EvoAuth.sendSms($('smsNum').value);
        $('smsNum').style.display = 'none'; $('smsCode').style.display = 'block'; $('smsCode').focus();
        $('smsAide').textContent = 'Code envoyé au ' + numeroInternational($('smsNum').value) + '. Entre-le ci-dessous.';
        btn.textContent = 'VALIDER';
      } else {
        btn.textContent = '⏳ Vérification…';
        await EvoAuth.signInSms(vid, $('smsCode').value);
        location.reload();
        return;
      }
    } catch (e) { erreur(e.message || e); btn.textContent = vid ? 'VALIDER' : 'ENVOYER LE CODE'; }
    btn.disabled = false;
  };
  setTimeout(() => $('smsNum').focus(), 50);
}

// Bouton « Mot de passe oublié ? » (lit le champ identifiant, affiche le résultat dans la zone d'erreur)
async function oubliMotDePasseUI(inputId, errId) {
  const err = document.getElementById(errId);
  const montre = (m, ok) => { if (err) { err.textContent = m; err.style.color = ok ? '#22c55e' : ''; err.style.display = 'block'; } else alert(m); };
  try {
    const email = await motDePasseOublie(document.getElementById(inputId).value);
    montre('✅ E-mail de réinitialisation envoyé à ' + email + ' (regarde aussi les spams).', true);
  } catch (e) { montre('❌ ' + (e.message || e), false); }
}

// Si un compte Google / SMS n'a pas encore de fiche joueur, elle est créée automatiquement au premier accès.
// (Les comptes créés avec un numéro — @evoarena.cm — ou un e-mail à l'inscription ont déjà leur fiche.)
(function () {
  const lire = EvoDB.get.bind(EvoDB);
  EvoDB.get = async function (col, id) {
    try { return await lire(col, id); }
    catch (e) {
      if (col === COLLECTIONS.PLAYERS && e && e.code === 'not-found') {
        try {
          const u = await EvoAuth.current();
          if (u.id === id && !/@evoarena\.cm$/i.test(u.email || '')) { await creerProfilSocial(u); return await lire(col, id); }
        } catch (x) {}
      }
      throw e;
    }
  };
})();

// ============================================================
// JOUEUR VÉRIFIÉ (badge ✔) — colonne booléenne Verifie dans Joueurs, activée par l'admin
// ============================================================
function badgeVerifie(d) {
  return (d && d.Verifie === true) ? ' <span title="Joueur vérifié" style="display:inline-block;background:#3b82f6;color:#fff;border-radius:50%;width:15px;height:15px;line-height:15px;text-align:center;font-size:.6rem;vertical-align:middle">✔</span>' : '';
}
