// EVO ARENA — fonctions « application native » côté joueur (partagé par toutes les pages joueur)
// Contenu : retour haptique, tirer-pour-rafraîchir, installer l'app, annonce officielle, favoris,
// ajout au calendrier (.ics), partage WhatsApp, styles « app native » (zones sûres, pas de rebond, etc.).
// Tout est optionnel : si une partie échoue, la page continue de marcher normalement.
(function () {
  'use strict';
  if (window.EvoPro) return;

  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  function esc(s) { return (typeof escapeHtml === 'function') ? escapeHtml(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(m, t) { try { if (typeof showToast === 'function') showToast(m, t || 'info'); } catch (e) {} }
  function vibre(ms) { try { if (navigator.vibrate) navigator.vibrate(ms || 10); } catch (e) {} }
  var estStandalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true || !!window.Capacitor;

  // ------------------------------------------------------------------
  // 1. Styles « app native »
  // ------------------------------------------------------------------
  var css = document.createElement('style');
  css.textContent = [
    'html{overscroll-behavior-y:contain;-webkit-text-size-adjust:100%}',
    'button,.btn,.nav-btn,.tab,.chip-evo,.card{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}',
    '.bottom-nav{padding-bottom:env(safe-area-inset-bottom,0px)}',
    '.nav-btn:active{transform:scale(.92)}',
    // tirer pour rafraîchir
    '#evoPtr{position:fixed;top:0;left:50%;transform:translate(-50%,-60px);z-index:99998;background:rgba(10,10,20,.95);color:var(--c1,#00ff88);border:1px solid rgba(var(--c1-rgb,0,255,136),.4);border-radius:0 0 18px 18px;padding:8px 18px;font-size:.72rem;font-weight:800;transition:transform .15s;pointer-events:none}',
    '#evoPtr.on{transform:translate(-50%,0)}',
    // annonce
    '#evoAnnonce{position:relative;z-index:90;margin:0;padding:10px 38px 10px 14px;font-size:.78rem;font-weight:700;line-height:1.35;color:#e0f2fe;background:linear-gradient(90deg,rgba(var(--c2-rgb,124,58,237),.45),rgba(var(--c1-rgb,0,255,136),.25));border-bottom:1px solid rgba(var(--c1-rgb,0,255,136),.35)}',
    '#evoAnnonce.alerte{background:linear-gradient(90deg,rgba(239,68,68,.55),rgba(245,158,11,.35))}',
    '#evoAnnonce.promo{background:linear-gradient(90deg,rgba(245,158,11,.5),rgba(var(--c1-rgb,0,255,136),.3))}',
    '#evoAnnonce a{color:var(--c1,#00ff88);text-decoration:underline;margin-left:6px}',
    '#evoAnnonce button{position:absolute;right:6px;top:50%;transform:translateY(-50%);background:none;border:none;color:#fff;font-size:1.1rem;padding:6px 10px;cursor:pointer}',
    // installer l'app
    '#evoInstall{position:fixed;left:14px;right:14px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:98;display:none;align-items:center;gap:10px;padding:10px 12px;border-radius:16px;background:rgba(10,10,20,.96);border:1px solid rgba(var(--c1-rgb,0,255,136),.45);color:#e0f2fe;font-size:.75rem;box-shadow:0 8px 30px rgba(0,0,0,.5)}',
    '#evoInstall.on{display:flex}',
    '#evoInstall b{color:var(--c1,#00ff88)}',
    '#evoInstall .go{margin-left:auto;background:var(--c1,#00ff88);color:#000;border:none;border-radius:10px;padding:8px 12px;font-weight:800;font-size:.72rem;cursor:pointer;white-space:nowrap}',
    '#evoInstall .x{background:none;border:none;color:#94a3b8;font-size:1.1rem;cursor:pointer;padding:4px 6px}',
    // puces de filtre
    '.chips-evo{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:0 12px 12px;-webkit-overflow-scrolling:touch}',
    '.chips-evo::-webkit-scrollbar{display:none}',
    '.chip-evo{flex:0 0 auto;padding:7px 14px;border-radius:999px;border:1px solid rgba(var(--c1-rgb,0,255,136),.25);background:rgba(var(--bg-rgb,5,5,16),.8);color:#cbd5e1;font-size:.72rem;font-weight:700;cursor:pointer;font-family:inherit}',
    '.chip-evo.on{background:var(--c1,#00ff88);color:#000;border-color:var(--c1,#00ff88)}',
    '.btn-mini{flex:1 1 20%!important;min-width:0;background:#2a2a3e!important;color:#fff!important;padding:4px 0!important;font-size:.8rem!important;min-height:30px}',
    '.btn-mini.fav-on{background:#f59e0b!important;color:#000!important}'
  ].join('\n');
  document.head.appendChild(css);

  // ------------------------------------------------------------------
  // 2. Retour haptique (vibration courte sur les boutons / navigation)
  // ------------------------------------------------------------------
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest && e.target.closest('button,.nav-btn,.tab,.chip-evo,.btn');
    if (t) vibre(8);
  }, { passive: true });

  // ------------------------------------------------------------------
  // 3. Tirer pour rafraîchir (comme une vraie app)
  // ------------------------------------------------------------------
  (function () {
    var bar = document.createElement('div'); bar.id = 'evoPtr'; bar.textContent = '↓ Tire pour actualiser';
    function monter() { if (document.body) document.body.appendChild(bar); else document.addEventListener('DOMContentLoaded', function () { document.body.appendChild(bar); }); }
    monter();
    var y0 = null, dy = 0, SEUIL = 95;
    function enHaut() { return (window.scrollY || document.documentElement.scrollTop || 0) <= 0; }
    function bloque(el) {
      if (document.body.style.overflow === 'hidden') return true;
      for (var n = el; n && n !== document.body; n = n.parentElement) {
        if (n.scrollHeight > n.clientHeight + 4 && /(auto|scroll)/.test(getComputedStyle(n).overflowY)) return true;
        if (n.scrollWidth > n.clientWidth + 4 && /(auto|scroll)/.test(getComputedStyle(n).overflowX) && n.tagName !== 'BODY') return true;
      }
      return false;
    }
    document.addEventListener('touchstart', function (e) {
      y0 = (e.touches.length === 1 && enHaut() && !bloque(e.target)) ? e.touches[0].clientY : null; dy = 0;
    }, { passive: true });
    document.addEventListener('touchmove', function (e) {
      if (y0 == null) return; dy = e.touches[0].clientY - y0;
      if (dy > 20 && enHaut()) { bar.classList.add('on'); bar.textContent = dy > SEUIL ? '↑ Relâche pour actualiser' : '↓ Tire pour actualiser'; } else bar.classList.remove('on');
    }, { passive: true });
    document.addEventListener('touchend', function () {
      var ok = y0 != null && dy > SEUIL; y0 = null; bar.classList.remove('on');
      if (!ok) return;
      vibre(15); bar.textContent = '⟳ Actualisation…'; bar.classList.add('on'); setTimeout(function () { bar.classList.remove('on'); }, 900);
      var ev = new CustomEvent('evo-refresh', { cancelable: true });
      window.dispatchEvent(ev);
      if (!ev.defaultPrevented) setTimeout(function () { location.reload(); }, 250);
    }, { passive: true });
  })();

  // ------------------------------------------------------------------
  // 4. Installer l'app (Android : invite native ; iPhone : mode d'emploi)
  // ------------------------------------------------------------------
  (function () {
    if (estStandalone) return;
    var rappel = LS.get('evo_install_non', 0);
    if (Date.now() - rappel < 7 * 864e5) return;
    var evtInstall = null;
    var box = document.createElement('div'); box.id = 'evoInstall';
    function afficher(html, bouton, action) {
      box.innerHTML = '<span style="font-size:1.4rem">📲</span><span>' + html + '</span>' + (bouton ? '<button class="go" type="button">' + bouton + '</button>' : '') + '<button class="x" type="button" aria-label="Fermer">✕</button>';
      if (bouton) box.querySelector('.go').onclick = action;
      box.querySelector('.x').onclick = function () { box.classList.remove('on'); LS.set('evo_install_non', Date.now()); };
      if (!box.parentNode) document.body.appendChild(box);
      box.classList.add('on');
    }
    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault(); evtInstall = e;
      setTimeout(function () {
        afficher('<b>Installe EVO ARENA</b> sur ton écran d\'accueil : plein écran, accès direct.', 'Installer', function () {
          if (!evtInstall) return; evtInstall.prompt();
          evtInstall.userChoice.then(function () { box.classList.remove('on'); evtInstall = null; });
        });
      }, 6000);
    });
    var ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
    if (ios) setTimeout(function () { afficher('<b>Installe l\'app :</b> touche <b>Partager</b> ⬆️ puis <b>« Sur l\'écran d\'accueil »</b>.'); }, 8000);
    window.addEventListener('appinstalled', function () { box.classList.remove('on'); toast('✅ App installée !', 'success'); });
  })();

  // ------------------------------------------------------------------
  // 5. Annonce officielle (publiée par l'admin dans Config/annonce)
  // ------------------------------------------------------------------
  function afficherAnnonce(a) {
    var ancien = document.getElementById('evoAnnonce'); if (ancien) ancien.remove();
    if (!a || a.Actif === false || !a.Texte) return;
    if (a.Date_fin && new Date(a.Date_fin).getTime() < Date.now()) return;
    var cle = String(a.Texte).slice(0, 80) + '|' + (a._updatedAt || '');
    if (LS.get('evo_annonce_vue', '') === cle) return;
    var type = /^(alerte|promo)$/.test(a.Type) ? a.Type : 'info';
    var d = document.createElement('div'); d.id = 'evoAnnonce'; d.className = type; d.setAttribute('role', 'status');
    var ico = { info: '📣', alerte: '⚠️', promo: '🎁' }[type];
    d.appendChild(document.createTextNode(ico + ' ' + String(a.Texte).slice(0, 300)));
    var lien = (typeof urlBrute === 'function') ? urlBrute(a.Lien) : '';
    if (lien) { var l = document.createElement('a'); l.href = lien; l.target = '_blank'; l.rel = 'noopener noreferrer'; l.textContent = 'En savoir plus'; d.appendChild(l); }
    var x = document.createElement('button'); x.type = 'button'; x.setAttribute('aria-label', 'Fermer'); x.textContent = '✕';
    x.onclick = function () { LS.set('evo_annonce_vue', cle); d.remove(); };
    d.appendChild(x);
    var h = document.querySelector('header'); if (h && h.parentNode) h.parentNode.insertBefore(d, h.nextSibling); else document.body.insertBefore(d, document.body.firstChild);
  }
  function chargerAnnonce() {
    try {
      if (typeof EvoDB === 'undefined' || !EvoDB.getFast) return;
      EvoDB.getFast('Config', 'annonce').then(afficherAnnonce).catch(function () {});
    } catch (e) {}
  }
  window.addEventListener('evo-fresh', function (e) { var d = e && e.detail; if (d && d.col === 'Config' && d.id === 'annonce') afficherAnnonce(d.doc); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(chargerAnnonce, 400); }); else setTimeout(chargerAnnonce, 400);

  // ------------------------------------------------------------------
  // 6. API pour les pages : favoris, calendrier, partage WhatsApp
  // ------------------------------------------------------------------
  var EvoPro = {
    vibre: vibre,
    favoris: function () { var f = LS.get('evo_fav', []); return Array.isArray(f) ? f : []; },
    estFavori: function (id) { return EvoPro.favoris().indexOf(id) >= 0; },
    basculerFavori: function (id) {
      var f = EvoPro.favoris(), i = f.indexOf(id);
      if (i >= 0) f.splice(i, 1); else f.push(id);
      LS.set('evo_fav', f); vibre(15);
      return i < 0;
    },
    // Fichier .ics : ajoute le tournoi au calendrier du téléphone, avec rappel 30 min avant
    ajouterAuCalendrier: function (nom, dateDebut, dureeMin) {
      var d = new Date(dateDebut);
      if (!dateDebut || isNaN(d.getTime())) { toast('📅 Date du tournoi pas encore annoncée', 'info'); return; }
      var f = function (x) { return x.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); };
      var fin = new Date(d.getTime() + (dureeMin || 120) * 60000);
      var propre = function (s) { return String(s || '').replace(/[\\;,]/g, ' ').replace(/[\r\n]+/g, ' ').slice(0, 100); };
      var ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//EVO ARENA//FR', 'BEGIN:VEVENT',
        'UID:' + d.getTime() + '-' + propre(nom).replace(/\s/g, '') + '@evoarena', 'DTSTAMP:' + f(new Date()),
        'DTSTART:' + f(d), 'DTEND:' + f(fin), 'SUMMARY:' + propre('Tournoi EVO ARENA - ' + nom),
        'DESCRIPTION:' + propre('Ouvre EVO ARENA pour rejoindre ton match.'),
        'BEGIN:VALARM', 'TRIGGER:-PT30M', 'ACTION:DISPLAY', 'DESCRIPTION:Ton tournoi commence dans 30 minutes', 'END:VALARM',
        'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
      var blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
      var url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = 'tournoi-evo.ics'; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      toast('📅 Ajouté : ouvre le fichier pour l\'enregistrer dans ton calendrier', 'success');
    },
    // Partage : feuille de partage du téléphone (WhatsApp en tête) ou lien WhatsApp direct
    partager: function (texte, url) {
      url = url || (location.origin + location.pathname.replace(/[^/]*$/, 'index.html'));
      if (navigator.share) { navigator.share({ title: 'EVO ARENA', text: texte, url: url }).catch(function () {}); return; }
      window.open('https://wa.me/?text=' + encodeURIComponent(texte + ' ' + url), '_blank', 'noopener');
    },
    filtre: 'tous'
  };
  window.EvoPro = EvoPro;

  // ------------------------------------------------------------------
  // 7. Mode maintenance (Config/maintenance, activé par l'admin) — écran plein page côté joueur
  // ------------------------------------------------------------------
  function afficherMaintenance(m) {
    var ex = document.getElementById('evoMaintenance');
    if (!m || m.Actif !== true) { if (ex) ex.remove(); document.documentElement.style.overflow = ''; return; }
    if (ex) return;
    var d = document.createElement('div'); d.id = 'evoMaintenance'; d.setAttribute('role', 'alert');
    d.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(5,5,16,.97);color:#e0f2fe;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:30px;font-family:inherit';
    var h = document.createElement('div'); h.style.cssText = 'font-size:3.2rem;margin-bottom:12px'; h.textContent = '🔧'; d.appendChild(h);
    var t = document.createElement('div'); t.style.cssText = 'font-size:1.2rem;font-weight:800;margin-bottom:8px'; t.textContent = 'Maintenance en cours'; d.appendChild(t);
    var s = document.createElement('div'); s.style.cssText = 'font-size:.9rem;color:#94a3b8;max-width:320px'; s.textContent = String(m.Message || 'Nous revenons très vite.').slice(0, 200); d.appendChild(s);
    var b = document.createElement('button'); b.type = 'button'; b.textContent = '🔄 Réessayer';
    b.style.cssText = 'margin-top:20px;padding:12px 22px;border-radius:12px;border:0;background:var(--c1,#00ff88);color:#000;font-weight:800;font-family:inherit;cursor:pointer';
    b.onclick = function () { location.reload(); }; d.appendChild(b);
    document.body.appendChild(d); document.documentElement.style.overflow = 'hidden';
  }
  function chargerMaintenance() {
    try { if (typeof EvoDB === 'undefined' || !EvoDB.getFast) return; EvoDB.getFast('Config', 'maintenance').then(afficherMaintenance).catch(function () {}); } catch (e) {}
  }
  window.addEventListener('evo-fresh', function (e) { var d = e && e.detail; if (d && d.col === 'Config' && d.id === 'maintenance') afficherMaintenance(d.doc); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(chargerMaintenance, 300); }); else setTimeout(chargerMaintenance, 300);
})();
