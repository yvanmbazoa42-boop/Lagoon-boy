# EVO — nouveautés v14

## Cartes tournoi (accueil)
Image recadrée, minuteur visible. v14d : hauteur de carte = 28 % de l écran sur téléphone (variable --carte-h dans index.html, ex. 24vh plus court, 32vh plus long).
Réglage : `index.html`, bloc « v14 CARTES TOURNOI » (valeur `aspect-ratio`). Plus grand = `1/1.3`, plus petit = `1/0.9`.

## 🌸 Fonds animés en direct (fichier `fonds.js`, toutes les pages)
Fond par défaut = TON fond d'origine (« Original EVO », inchangé). 7 fonds en option : 🌊 Vagues PS · Sakura 🌸 · Matrice 💚 · Galaxie ✨ (étoiles filantes) · Braises 🔥 · Neige ❄️ · Lucioles 🟡 · Aucun.
- Joueur : ⚙️ Paramètres › « Fond animé en direct ».
- Admin : onglet 🎨 FOND = fond par défaut pour tous (le choix du joueur reste prioritaire).
- Automatiquement coupé si « Animations réduites » est activé, en pause quand l'app est cachée, allégé sur les téléphones lents.

## Admin (fichier `admin-pro2.js`)
- 🎨 FOND : fond animé par défaut du site, avec aperçu.
- 🔧 MAINTENANCE : écran « maintenance » pour les joueurs (l'admin reste accessible). C'est un blocage d'affichage, pas une sécurité serveur.
- 👥 JOUEURS : recherche, ➕/➖ solde (motif obligatoire, confirmation), 🚫 bloquer / ✅ débloquer.
- 🧾 JOURNAL : 50 dernières actions sensibles (non modifiable).

## À FAIRE : republier `firestore.rules`
Nouvelle règle `admin_logs` (journal). Sans elle, le journal affiche une erreur et les actions solde/blocage fonctionnent mais ne sont pas inscrites.
Ajoute aussi `evoworl-gamearena.wasmer.app` aux domaines autorisés Firebase si ce n'est pas fait.

## Non testé en réel
Je n'ai pas pu ouvrir le site avec Firebase ni un vrai téléphone. Les animations ont été exécutées sans erreur dans un test simulé ; à vérifier sur ton téléphone (rendu des cartes, fluidité, onglets admin).

---
## ⚡ Vitesse (v14b)
- `sw.js` : vrai service worker. 2e ouverture = pages, scripts et images servis depuis le téléphone (quasi instantané), mises à jour discrètes en arrière-plan, pages admin toujours à jour (réseau d'abord). Les données (Firestore, connexion, paiements) ne sont JAMAIS mises en cache.
  **À chaque mise en ligne, change `VERSION` dans `sw.js`** (ex. `evo-v15`) pour forcer la mise à jour chez tous les joueurs.
- `firebase-config.js` : cache en mémoire vive (RAM) pour les données déjà lues + écriture disque différée (n'attend plus le disque).
- `speed.js` : la page suivante se charge dès que le doigt touche un lien, et les pages principales se préchargent quand le téléphone est au repos (désactivé si économiseur de données / 2G).
- Images des cartes chargées tout de suite, décodées hors du fil principal.
- ⚙️ › « Vitesse de chargement » : affiche les temps RÉELS mesurés sur le téléphone.
- Limite honnête : un chargement de moins de 9 ms n'existe pas sur le réseau mobile (la seule latence réseau dépasse ça). Objectif réaliste : affichage en quelques dizaines de ms à partir de la 2e ouverture.

---
## 📲 App native (v14c)
- Icônes adaptatives Android (maskable, avec marge de sécurité), manifest nettoyé, page `offline.html` quand il n'y a vraiment aucune connexion.
- Dossier `app-native/` : projet Capacitor + workflow GitHub qui construit l'APK sans ordinateur. Lis `app-native/README_APP.md` (2 chemins : PWABuilder recommandé, ou Capacitor).
- Dans l'app, la bannière « Installer l'app » est masquée.

Fond par défaut = TON fond d'origine (« Touches PlayStation (défaut) » dans la liste, vague de la barre du bas comprise). Les 7 fonds animés sont des options en plus, jamais imposées sauf si l'admin en choisit un dans 🎨 FOND.
