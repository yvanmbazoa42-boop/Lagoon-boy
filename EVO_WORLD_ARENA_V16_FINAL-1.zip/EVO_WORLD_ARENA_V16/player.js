// ============================================================
// LECTEUR VIDÉO EVO ARENA — design 100 % maison (remplace les contrôles moches des navigateurs)
//
//  • Vidéo directe (.mp4/.webm) et flux HLS (.m3u8) : lecteur entièrement personnalisé
//  • YouTube : on cache l'interface YouTube (controls=0) et on pilote la vidéo avec NOS boutons
//  • Facebook / Twitch : ces plateformes imposent leurs propres boutons -> on garde leur lecteur
//    mais dans un cadre EVO (badge EN DIRECT + bouton plein écran)
//
//  Utilisation : EvoPlayer.mount(conteneur, info, opts)  — appelé par afficherLecteurLive() (evo-config.js)
//  Couleurs : suit automatiquement le thème du site (--c1, --c2).
// ============================================================
(function () {
  if (window.EvoPlayer) return;

  // ---------- Styles (injectés une seule fois) ----------
  var CSS = [
    '.evp{position:relative;width:100%;aspect-ratio:16/9;background:#000;overflow:hidden;color:#fff;font-family:inherit;user-select:none;-webkit-user-select:none;outline:none;touch-action:manipulation;-webkit-tap-highlight-color:transparent}',
    '.evp *{box-sizing:border-box}',
    '.evp-stage,.evp-stage video,.evp-stage iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:#000;display:block}',
    '.evp-stage video{object-fit:contain}',
    '.evp-shield{position:absolute;inset:0;z-index:2;cursor:pointer}',
    '.evp:fullscreen,.evp.evp-fs{aspect-ratio:auto;width:100%;height:100%;max-height:none}',
    '.evp:-webkit-full-screen{aspect-ratio:auto;width:100%;height:100%}',
    /* haut : badge + titre */
    '.evp-top{position:absolute;left:0;right:0;top:0;z-index:4;display:flex;align-items:center;gap:8px;padding:10px 12px;background:linear-gradient(180deg,rgba(0,0,0,.65),transparent);transition:opacity .25s;pointer-events:none}',
    '.evp-badge{display:inline-flex;align-items:center;gap:6px;background:#ef4444;color:#fff;font-weight:800;font-size:.62rem;letter-spacing:.8px;padding:3px 9px;border-radius:5px;text-transform:uppercase}',
    '.evp-badge i{width:7px;height:7px;border-radius:50%;background:#fff;animation:evpPulse 1.2s ease-in-out infinite}',
    '.evp-badge.replay{background:rgba(255,255,255,.18)}',
    '.evp-badge.replay i{display:none}',
    '@keyframes evpPulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.7)}}',
    '.evp-title{font-size:.78rem;font-weight:700;text-shadow:0 1px 4px rgba(0,0,0,.8);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    /* gros bouton central */
    '.evp-big{position:absolute;left:50%;top:50%;z-index:4;width:68px;height:68px;margin:-34px 0 0 -34px;border-radius:50%;border:2px solid var(--c1,#00ff88);background:rgba(var(--bg-rgb,5,5,16),.55);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);color:var(--c1,#00ff88);display:none;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 0 28px rgba(var(--c1-rgb,0,255,136),.35);transition:transform .15s}',
    '.evp-big:active{transform:scale(.92)}',
    '.evp-big svg{width:34px;height:34px;fill:currentColor;margin-left:3px}',
    '.evp.paused .evp-big{display:flex}',
    '.evp.busy .evp-big,.evp.err .evp-big{display:none}',
    /* attente */
    '.evp-spin{position:absolute;left:50%;top:50%;z-index:4;width:46px;height:46px;margin:-23px 0 0 -23px;border-radius:50%;border:3px solid rgba(255,255,255,.18);border-top-color:var(--c1,#00ff88);animation:evpSpin .8s linear infinite;display:none;pointer-events:none}',
    '.evp.busy .evp-spin{display:block}',
    '@keyframes evpSpin{to{transform:rotate(360deg)}}',
    /* puce « activer le son » */
    '.evp-unmute{position:absolute;left:12px;bottom:64px;z-index:5;display:none;align-items:center;gap:7px;border:none;cursor:pointer;background:var(--c1,#00ff88);color:#000;font-weight:800;font-size:.72rem;padding:8px 14px;border-radius:20px;box-shadow:0 4px 16px rgba(0,0,0,.5);animation:evpIn .3s ease}',
    '.evp-unmute svg{width:16px;height:16px;fill:#000}',
    '.evp.needsound .evp-unmute{display:inline-flex}',
    '@keyframes evpIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    /* erreur */
    '.evp-err{position:absolute;inset:0;z-index:6;display:none;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:rgba(0,0,0,.85);text-align:center;padding:16px;font-size:.82rem;color:#fca5a5}',
    '.evp.err .evp-err{display:flex}',
    '.evp-err button{border:none;cursor:pointer;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;font-weight:800;padding:8px 18px;border-radius:20px;font-size:.75rem}',
    /* barre du bas */
    '.evp-bar{position:absolute;left:0;right:0;bottom:0;z-index:5;padding:26px 10px 8px;background:linear-gradient(0deg,rgba(0,0,0,.82),transparent);transition:opacity .25s,transform .25s}',
    '.evp.idle:not(.paused):not(.err) .evp-bar{opacity:0;transform:translateY(6px);pointer-events:none}',
    '.evp.idle:not(.paused):not(.err) .evp-top{opacity:0}',
    '.evp.idle:not(.paused):not(.err) .evp-shield{cursor:none}',
    '.evp-seek{position:relative;height:16px;display:flex;align-items:center;cursor:pointer;touch-action:none;margin:0 2px 2px}',
    '.evp-seek .track{position:relative;width:100%;height:4px;border-radius:2px;background:rgba(255,255,255,.22);transition:height .12s}',
    '.evp-seek:hover .track,.evp-seek.drag .track{height:6px}',
    '.evp-seek .buf,.evp-seek .cur{position:absolute;left:0;top:0;bottom:0;border-radius:2px;width:0}',
    '.evp-seek .buf{background:rgba(255,255,255,.28)}',
    '.evp-seek .cur{background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed))}',
    '.evp-seek .dot{position:absolute;top:50%;width:13px;height:13px;margin:-6.5px 0 0 -6.5px;border-radius:50%;background:var(--c1,#00ff88);box-shadow:0 0 10px var(--c1,#00ff88);left:0;transform:scale(0);transition:transform .12s}',
    '.evp-seek:hover .dot,.evp-seek.drag .dot{transform:scale(1)}',
    '.evp.islive .evp-seek{display:none}',
    '.evp-row{display:flex;align-items:center;gap:2px}',
    '.evp-btn{flex:none;width:38px;height:38px;border:none;background:transparent;color:#fff;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:background .15s,color .15s,transform .1s;padding:0}',
    '.evp-btn:hover{background:rgba(255,255,255,.14);color:var(--c1,#00ff88)}',
    '.evp-btn:active{transform:scale(.9)}',
    '.evp-btn svg{width:22px;height:22px;fill:currentColor}',
    '.evp-time{font-size:.7rem;font-weight:600;font-variant-numeric:tabular-nums;margin:0 8px;white-space:nowrap;opacity:.9}',
    '.evp.islive .evp-time{display:none}',
    '.evp-sp{flex:1}',
    '.evp-golive{border:1px solid rgba(255,255,255,.35);background:transparent;color:#fff;font-size:.62rem;font-weight:800;padding:4px 10px;border-radius:14px;cursor:pointer;margin-right:4px;display:none;letter-spacing:.5px}',
    '.evp.islive.behind .evp-golive{display:inline-block;border-color:var(--c1,#00ff88);color:var(--c1,#00ff88)}',
    '.evp-vol{width:0;opacity:0;transition:width .2s,opacity .2s;-webkit-appearance:none;appearance:none;height:4px;border-radius:2px;background:rgba(255,255,255,.28);outline:none;cursor:pointer;margin:0}',
    '.evp-volwrap:hover .evp-vol,.evp-vol:focus{width:70px;opacity:1;margin:0 8px 0 2px}',
    '.evp-vol::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--c1,#00ff88)}',
    '.evp-vol::-moz-range-thumb{width:12px;height:12px;border:none;border-radius:50%;background:var(--c1,#00ff88)}',
    '.evp-volwrap{display:flex;align-items:center}',
    '@media (hover:none){.evp-volwrap .evp-vol{display:none}}',
    /* cadre pour Facebook / Twitch */
    '.evp-fsbtn{position:absolute;right:8px;top:8px;z-index:6;width:36px;height:36px;border-radius:50%;border:none;cursor:pointer;background:rgba(0,0,0,.55);color:#fff;display:flex;align-items:center;justify-content:center}',
    '.evp-fsbtn svg{width:20px;height:20px;fill:currentColor}',
    '.evp-fsbtn:hover{color:var(--c1,#00ff88)}',
    '.evp.frameonly .evp-top{background:none;right:56px}',
    /* petit format (aperçu admin) */
    '.evp.compact .evp-title,.evp.compact .evp-time,.evp.compact .evp-volwrap{display:none}',
    '.evp.compact .evp-btn{width:32px;height:32px}',
    '.evp.compact .evp-big{transform:scale(.7)}'
  ].join('\n');
  function injecterCss() {
    if (document.getElementById('evp-css')) return;
    var s = document.createElement('style'); s.id = 'evp-css'; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  // ---------- Icônes ----------
  function ico(d) { return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>'; }
  var I = {
    play: ico('M8 5v14l11-7z'),
    pause: ico('M6 5h4v14H6zM14 5h4v14h-4z'),
    vol: ico('M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z'),
    mute: ico('M16.5 12A4.5 4.5 0 0014 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0021 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 003.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z'),
    fs: ico('M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z'),
    fsx: ico('M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z'),
    pip: ico('M19 7h-8v6h8V7zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 1.98 2 1.98h18c1.1 0 2-.88 2-1.98V5c0-1.1-.9-2-2-2zm0 16.01H3V4.98h18v14.03z')
  };

  function fmt(t) {
    if (!isFinite(t) || t < 0) t = 0; t = Math.floor(t);
    var h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  // hls.js chargé à la demande (une seule fois)
  var hlsPromise = null;
  function chargerHls() {
    if (window.Hls) return Promise.resolve();
    if (hlsPromise) return hlsPromise;
    hlsPromise = new Promise(function (ok, ko) {
      var sc = document.createElement('script');
      sc.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js';
      sc.onload = ok; sc.onerror = function () { hlsPromise = null; ko(new Error('hls.js')); };
      document.head.appendChild(sc);
    });
    return hlsPromise;
  }

  // ============================================================
  function mount(conteneur, info, opts) {
    opts = opts || {};
    injecterCss();
    if (conteneur._evp) { try { conteneur._evp.destroy(); } catch (e) {} }
    conteneur.innerHTML = '';

    var type = info.type;
    var frameOnly = (type === 'facebook' || type === 'twitch');
    var root = document.createElement('div');
    root.className = 'evp paused' + (opts.hauteur ? ' compact' : '') + (frameOnly ? ' frameonly' : '');
    root.tabIndex = 0;
    if (opts.hauteur) root.style.cssText = 'aspect-ratio:auto;height:' + opts.hauteur;
    var titre = opts.titre ? '<span class="evp-title">' + esc(opts.titre) + '</span>' : '';
    var liveParDefaut = opts.live !== false && type !== 'video';

    root.innerHTML =
      '<div class="evp-stage"></div>' +
      (frameOnly ? '' : '<div class="evp-shield"></div>') +
      '<div class="evp-top"><span class="evp-badge' + (liveParDefaut ? '' : ' replay') + '"><i></i><b>' + (liveParDefaut ? 'EN DIRECT' : 'REPLAY') + '</b></span>' + titre + '</div>' +
      (frameOnly
        ? '<button class="evp-fsbtn" type="button" aria-label="Plein écran">' + I.fs + '</button>'
        : '<button class="evp-big" type="button" aria-label="Lecture">' + I.play + '</button>' +
          '<div class="evp-spin"></div>' +
          '<button class="evp-unmute" type="button">' + I.mute + 'Touchez pour activer le son</button>' +
          '<div class="evp-err"><div class="evp-errtxt">⚠️ Flux indisponible pour le moment</div><button type="button">🔄 Réessayer</button></div>' +
          '<div class="evp-bar">' +
            '<div class="evp-seek"><div class="track"><div class="buf"></div><div class="cur"></div><div class="dot"></div></div></div>' +
            '<div class="evp-row">' +
              '<button class="evp-btn evp-play" type="button" aria-label="Lecture / pause">' + I.play + '</button>' +
              '<span class="evp-volwrap"><button class="evp-btn evp-mute" type="button" aria-label="Son">' + I.vol + '</button><input class="evp-vol" type="range" min="0" max="1" step="0.05" value="1" aria-label="Volume"></span>' +
              '<span class="evp-time">0:00 / 0:00</span>' +
              '<span class="evp-sp"></span>' +
              '<button class="evp-golive" type="button">⏩ REVENIR AU DIRECT</button>' +
              ((document.pictureInPictureEnabled && (type === 'video' || type === 'hls')) ? '<button class="evp-btn evp-pip" type="button" aria-label="Mini-lecteur">' + I.pip + '</button>' : '') +
              '<button class="evp-btn evp-fs" type="button" aria-label="Plein écran">' + I.fs + '</button>' +
            '</div>' +
          '</div>');
    conteneur.appendChild(root);

    var $ = function (s) { return root.querySelector(s); };
    var stage = $('.evp-stage');
    var badge = $('.evp-badge'), badgeTxt = $('.evp-badge b');
    var fsBtns = root.querySelectorAll('.evp-fs, .evp-fsbtn');
    var detruit = false, timers = [], cleanups = [];
    function onEv(el, ev, fn, o) { el.addEventListener(ev, fn, o); cleanups.push(function () { el.removeEventListener(ev, fn, o); }); }
    function every(fn, ms) { var t = setInterval(fn, ms); timers.push(t); return t; }

    // ---------- Plein écran (commun) ----------
    function enFs() { return document.fullscreenElement === root || document.webkitFullscreenElement === root || root.classList.contains('evp-fs'); }
    function basculerFs() {
      var video = stage.querySelector('video');
      if (enFs()) {
        if (document.exitFullscreen) document.exitFullscreen();
        else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
        else root.classList.remove('evp-fs');
        try { screen.orientation && screen.orientation.unlock && screen.orientation.unlock(); } catch (e) {}
        return;
      }
      var rq = root.requestFullscreen || root.webkitRequestFullscreen;
      if (rq) {
        var p = rq.call(root);
        var apres = function () { try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(function () {}); } catch (e) {} };
        if (p && p.then) p.then(apres, function () {}); else apres();
      } else if (video && video.webkitEnterFullscreen) { video.webkitEnterFullscreen(); } // iPhone : lecteur natif obligatoire
      else { root.classList.add('evp-fs'); }
    }
    function majFsIcone() {
      var on = enFs();
      for (var i = 0; i < fsBtns.length; i++) fsBtns[i].innerHTML = on ? I.fsx : I.fs;
    }
    for (var f = 0; f < fsBtns.length; f++) onEv(fsBtns[f], 'click', function (e) { e.stopPropagation(); basculerFs(); });
    onEv(document, 'fullscreenchange', majFsIcone);
    onEv(document, 'webkitfullscreenchange', majFsIcone);

    var api = {
      destroy: function () {
        if (detruit) return; detruit = true;
        timers.forEach(clearInterval); timers.forEach(clearTimeout);
        cleanups.forEach(function (c) { try { c(); } catch (e) {} });
        if (moteur && moteur.destroy) { try { moteur.destroy(); } catch (e) {} }
        try { if (document.fullscreenElement === root) document.exitFullscreen(); } catch (e) {}
        if (root.parentNode) root.parentNode.removeChild(root);
        if (conteneur._evp === api) conteneur._evp = null;
      }
    };
    conteneur._evp = api;

    // ============================================================
    // Facebook / Twitch : cadre EVO autour du lecteur de la plateforme
    // ============================================================
    if (frameOnly) {
      stage.innerHTML = '<iframe src="' + esc(info.src) + '" title="Live EVO ARENA" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
      return api;
    }

    // ============================================================
    // Interface commune aux moteurs « vidéo » et « YouTube »
    // ============================================================
    var etat = { paused: true, muted: false, volume: 1, t: 0, dur: 0, buf: 0, live: liveParDefaut, behind: false };
    var moteur = null;
    var btnPlay = $('.evp-play'), btnMute = $('.evp-mute'), vol = $('.evp-vol'), temps = $('.evp-time');
    var seek = $('.evp-seek'), barBuf = $('.buf'), barCur = $('.cur'), dot = $('.dot');
    var dernierAct = Date.now(), glisse = false;

    function ui() {
      root.classList.toggle('paused', etat.paused);
      root.classList.toggle('islive', !!etat.live);
      root.classList.toggle('behind', !!etat.behind);
      btnPlay.innerHTML = etat.paused ? I.play : I.pause;
      btnMute.innerHTML = (etat.muted || etat.volume === 0) ? I.mute : I.vol;
      if (!glisse) vol.value = etat.muted ? 0 : etat.volume;
      badge.classList.toggle('replay', !etat.live);
      badgeTxt.textContent = etat.live ? 'EN DIRECT' : 'REPLAY';
      if (!etat.live && etat.dur > 0) {
        var pc = Math.min(100, etat.t / etat.dur * 100);
        barCur.style.width = pc + '%'; dot.style.left = pc + '%';
        barBuf.style.width = Math.min(100, etat.buf / etat.dur * 100) + '%';
        temps.textContent = fmt(etat.t) + ' / ' + fmt(etat.dur);
      }
    }
    function occupe(b) { root.classList.toggle('busy', !!b); }
    function erreur(msg) { root.classList.add('err'); occupe(false); if (msg) $('.evp-errtxt').textContent = msg; }
    function pasErreur() { root.classList.remove('err'); }
    function demanderSon(b) { root.classList.toggle('needsound', !!b); }

    function basculerLecture() { if (!moteur) return; etat.paused ? moteur.play() : moteur.pause(); }
    function basculerMute() {
      if (!moteur) return;
      var muet = etat.muted || etat.volume === 0;
      if (muet) { moteur.setMuted(false); if (etat.volume === 0) moteur.setVolume(0.6); demanderSon(false); }
      else moteur.setMuted(true);
    }
    function activite() { dernierAct = Date.now(); root.classList.remove('idle'); }
    every(function () { if (Date.now() - dernierAct > 3000 && !glisse) root.classList.add('idle'); }, 500);
    ['pointermove', 'pointerdown', 'keydown', 'touchstart'].forEach(function (ev) { onEv(root, ev, activite, { passive: true }); });

    // Boutons
    onEv(btnPlay, 'click', function (e) { e.stopPropagation(); basculerLecture(); });
    onEv($('.evp-big'), 'click', function (e) { e.stopPropagation(); basculerLecture(); });
    onEv(btnMute, 'click', function (e) { e.stopPropagation(); basculerMute(); });
    onEv($('.evp-unmute'), 'click', function (e) { e.stopPropagation(); if (moteur) { moteur.setMuted(false); if (etat.volume === 0) moteur.setVolume(1); } demanderSon(false); });
    onEv(vol, 'input', function () { var v = parseFloat(vol.value); if (!moteur) return; moteur.setVolume(v); moteur.setMuted(v === 0); demanderSon(false); });
    onEv($('.evp-golive'), 'click', function (e) { e.stopPropagation(); if (moteur && moteur.goLive) moteur.goLive(); });
    var bp = $('.evp-pip');
    if (bp) onEv(bp, 'click', function (e) {
      e.stopPropagation();
      var v = stage.querySelector('video'); if (!v) return;
      if (document.pictureInPictureElement) document.exitPictureInPicture().catch(function () {});
      else v.requestPictureInPicture().catch(function () {});
    });
    onEv($('.evp-err button'), 'click', function (e) { e.stopPropagation(); pasErreur(); occupe(true); if (moteur && moteur.reessayer) moteur.reessayer(); });

    // Clic sur l'image : souris = lecture/pause ; tactile = 1er toucher affiche les contrôles, 2e toucher lecture/pause
    var shield = $('.evp-shield');
    onEv(shield, 'click', function (e) {
      var tactile = e.pointerType === 'touch' || (window.matchMedia && matchMedia('(hover:none)').matches);
      if (tactile && root.classList.contains('idle')) { activite(); return; }
      activite(); basculerLecture();
    });
    onEv(shield, 'dblclick', function (e) { e.preventDefault(); basculerFs(); });

    // Clavier
    onEv(root, 'keydown', function (e) {
      if (e.target && e.target.tagName === 'INPUT') return;
      var k = e.key;
      if (k === ' ' || k === 'k') { e.preventDefault(); basculerLecture(); }
      else if (k === 'm') basculerMute();
      else if (k === 'f') basculerFs();
      else if (k === 'ArrowRight' && !etat.live && moteur) moteur.seek(Math.min(etat.dur, etat.t + 5));
      else if (k === 'ArrowLeft' && !etat.live && moteur) moteur.seek(Math.max(0, etat.t - 5));
      else if (k === 'ArrowUp' && moteur) { e.preventDefault(); moteur.setVolume(Math.min(1, etat.volume + .1)); moteur.setMuted(false); }
      else if (k === 'ArrowDown' && moteur) { e.preventDefault(); moteur.setVolume(Math.max(0, etat.volume - .1)); }
    });

    // Barre de progression (replay uniquement)
    function ratio(e) { var r = seek.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); }
    onEv(seek, 'pointerdown', function (e) {
      if (etat.live || !etat.dur) return; e.stopPropagation(); glisse = true; seek.classList.add('drag');
      try { seek.setPointerCapture(e.pointerId); } catch (x) {}
      etat.t = ratio(e) * etat.dur; ui();
    });
    onEv(seek, 'pointermove', function (e) { if (!glisse) return; etat.t = ratio(e) * etat.dur; ui(); });
    var finGlisse = function (e) { if (!glisse) return; glisse = false; seek.classList.remove('drag'); if (moteur) moteur.seek(ratio(e) * etat.dur); };
    onEv(seek, 'pointerup', finGlisse); onEv(seek, 'pointercancel', function () { glisse = false; seek.classList.remove('drag'); });

    // ============================================================
    // MOTEUR 1 — vidéo directe + HLS
    // ============================================================
    function moteurVideo() {
      var v = document.createElement('video');
      v.playsInline = true; v.setAttribute('playsinline', ''); v.setAttribute('webkit-playsinline', '');
      v.preload = 'auto'; v.controls = false; v.disablePictureInPicture = false;
      v.setAttribute('controlslist', 'nodownload noremoteplayback');
      v.muted = !!opts.muet;
      stage.appendChild(v);
      var hls = null, hlsLive = false, essais = 0;

      function lire() {
        etat.paused = v.paused; etat.muted = v.muted; etat.volume = v.volume;
        etat.t = v.currentTime || 0;
        var d = v.duration;
        etat.live = (type === 'hls' && hlsLive) || d === Infinity || (type === 'hls' && !isFinite(d));
        etat.dur = isFinite(d) ? d : 0;
        if (v.buffered && v.buffered.length) { try { etat.buf = v.buffered.end(v.buffered.length - 1); } catch (e) {} }
        if (etat.live) {
          var fin = 0; try { fin = v.seekable.length ? v.seekable.end(v.seekable.length - 1) : 0; } catch (e) {}
          etat.behind = fin > 0 && (fin - etat.t) > 15;
        } else etat.behind = false;
        ui();
      }
      ['play', 'pause', 'volumechange', 'durationchange', 'loadedmetadata', 'timeupdate', 'progress', 'seeked'].forEach(function (ev) { onEv(v, ev, lire); });
      onEv(v, 'waiting', function () { occupe(true); });
      onEv(v, 'seeking', function () { occupe(true); });
      onEv(v, 'canplay', function () { occupe(false); pasErreur(); });
      onEv(v, 'playing', function () { occupe(false); pasErreur(); essais = 0; });
      onEv(v, 'error', function () { if (type !== 'hls') erreur('⚠️ Cette vidéo ne peut pas être lue'); });

      function essayerLecture() {
        var p = v.play();
        if (p && p.catch) p.catch(function () {
          // Le navigateur refuse le son automatique -> on démarre sans son et on propose de l'activer
          if (!v.muted) { v.muted = true; var p2 = v.play(); if (p2 && p2.catch) p2.catch(function () { etat.paused = true; ui(); }); }
          if (!opts.muet) demanderSon(true);
        });
      }
      function charger() {
        pasErreur(); occupe(true);
        if (type === 'hls' && !v.canPlayType('application/vnd.apple.mpegurl')) {
          chargerHls().then(function () {
            if (detruit) return;
            if (!(window.Hls && Hls.isSupported())) { erreur('⚠️ Ce navigateur ne sait pas lire ce flux'); return; }
            if (hls) { hls.destroy(); }
            hls = new Hls({ lowLatencyMode: true, backBufferLength: 30 });
            hls.on(Hls.Events.LEVEL_LOADED, function (ev, data) { hlsLive = !!(data && data.details && data.details.live); lire(); });
            hls.on(Hls.Events.MANIFEST_PARSED, essayerLecture);
            hls.on(Hls.Events.ERROR, function (ev, data) {
              if (!data || !data.fatal) return;
              if (data.type === Hls.ErrorTypes.NETWORK_ERROR && essais < 6) { essais++; occupe(true); var t = setTimeout(function () { if (hls) hls.startLoad(); }, 2500); timers.push(t); }
              else if (data.type === Hls.ErrorTypes.MEDIA_ERROR && essais < 6) { essais++; hls.recoverMediaError(); }
              else erreur('⚠️ Le direct n\'est pas disponible pour le moment');
            });
            hls.loadSource(info.src); hls.attachMedia(v);
          }).catch(function () { erreur('⚠️ Impossible de charger le lecteur'); });
        } else { v.src = info.src; essayerLecture(); }
      }
      charger();
      // Quand l'onglet revient au premier plan, on reprend (le direct s'arrête parfois en arrière-plan)
      onEv(document, 'visibilitychange', function () { if (document.visibilityState === 'visible' && !etat.paused && v.paused) essayerLecture(); });
      every(lire, 1000);

      return {
        play: function () { essayerLecture(); },
        pause: function () { v.pause(); },
        setMuted: function (b) { v.muted = !!b; },
        setVolume: function (x) { v.volume = Math.max(0, Math.min(1, x)); },
        seek: function (t) { try { v.currentTime = t; } catch (e) {} },
        goLive: function () {
          try { var fin = (hls && hls.liveSyncPosition) || (v.seekable.length ? v.seekable.end(v.seekable.length - 1) : 0); if (fin) v.currentTime = fin; } catch (e) {}
          essayerLecture();
        },
        reessayer: function () { essais = 0; if (hls) { try { hls.stopLoad(); hls.startLoad(); } catch (e) { charger(); } } else { v.load(); essayerLecture(); } },
        destroy: function () { try { v.pause(); } catch (e) {} if (hls) { try { hls.destroy(); } catch (e) {} } v.removeAttribute('src'); try { v.load(); } catch (e) {} }
      };
    }

    // ============================================================
    // MOTEUR 2 — YouTube (interface YouTube masquée, pilotée par postMessage)
    // ============================================================
    function moteurYoutube() {
      var id = info.ytId || (info.src.match(/embed\/([a-zA-Z0-9_-]{11})/) || [])[1];
      var origine = /^https?:$/.test(location.protocol) ? '&origin=' + encodeURIComponent(location.origin) : '';
      var ifr = document.createElement('iframe');
      ifr.title = 'Live EVO ARENA';
      ifr.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      ifr.src = 'https://www.youtube.com/embed/' + id + '?autoplay=1&mute=1&controls=0&rel=0&playsinline=1&modestbranding=1&disablekb=1&iv_load_policy=3&fs=0&enablejsapi=1' + origine;
      stage.appendChild(ifr);
      occupe(true); demanderSon(!opts.muet);
      etat.muted = true;
      var pret = false;
      function cmd(func, args) { try { ifr.contentWindow.postMessage(JSON.stringify({ event: 'command', func: func, args: args || [] }), '*'); } catch (e) {} }
      function ecoute() { try { ifr.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), '*'); } catch (e) {} }
      onEv(ifr, 'load', ecoute);
      every(function () { if (!pret) ecoute(); }, 700);
      onEv(window, 'message', function (e) {
        if (e.source !== ifr.contentWindow) return;
        var d = e.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (x) { return; } }
        if (!d || !d.event) return;
        pret = true;
        var i = d.info; if (i == null) return;
        if (d.event === 'onStateChange') i = { playerState: i };
        if (typeof i !== 'object') return;
        if (i.playerState !== undefined) {
          var s = i.playerState;
          etat.paused = (s === 2 || s === 0 || s === 5 || s === -1);
          occupe(s === 3 || s === -1);
          if (s === 1) pasErreur();
        }
        if (i.muted !== undefined) { etat.muted = !!i.muted; if (!etat.muted) demanderSon(false); }
        if (i.volume !== undefined) etat.volume = i.volume / 100;
        if (i.currentTime !== undefined) etat.t = i.currentTime;
        if (i.duration !== undefined) etat.dur = i.duration || 0;
        if (i.videoLoadedFraction !== undefined && etat.dur) etat.buf = i.videoLoadedFraction * etat.dur;
        etat.live = liveParDefaut;
        ui();
      });
      return {
        play: function () { cmd('playVideo'); etat.paused = false; ui(); },
        pause: function () { cmd('pauseVideo'); etat.paused = true; ui(); },
        setMuted: function (b) { cmd(b ? 'mute' : 'unMute'); etat.muted = !!b; ui(); },
        setVolume: function (x) { cmd('setVolume', [Math.round(x * 100)]); etat.volume = x; ui(); },
        seek: function (t) { cmd('seekTo', [t, true]); },
        goLive: function () { cmd('seekTo', [1e9, true]); cmd('playVideo'); },
        reessayer: function () { ifr.src = ifr.src; },
        destroy: function () { ifr.src = 'about:blank'; }
      };
    }

    moteur = (type === 'youtube') ? moteurYoutube() : moteurVideo();
    ui();
    return api;
  }

  window.EvoPlayer = { mount: mount };
})();
