# SECURITY_REPORT — EVO WORLD ARENA V16

Statuts : ✅ implémenté **et vérifié par test automatisé** (base mémoire / navigateur simulé) · 🟡 implémenté, **non vérifié en réel** · 🔴 non fait / action requise.

| Contrôle | Statut | Détail |
|---|---|---|
| Données privées séparées | ✅ logique / 🟡 règles | Contact et naissance dans `Joueurs_prive` ; profil public sans contact (règles refusent les champs privés en création/modification, même pour un admin). Règles à valider avec l'émulateur. |
| Lecture des données privées | 🟡 | Propriétaire + admin uniquement ; aucune écriture client. |
| Connexion par numéro sans fuite d'e-mail | ✅ logique / 🟡 réel | `phoneSignIn` vérifie le mot de passe côté serveur et renvoie un jeton ; `requestPasswordReset` répond pareil que le compte existe ou non. Limitation de tentatives (8/15 min par numéro, 40/10 min par IP). Nécessite le rôle IAM « Service Account Token Creator ». |
| Double transaction | ✅ | Verrou `registrations`, référence Mobile Money unique (`payment_refs`), validation concurrente : une seule passe. |
| Double récompense (parrainage / gains / abonnement) | ✅ | Documents `referral_rewards` créés une fois ; rang de gain unique ; abonnement +30 jours une seule fois. |
| Montants non modifiables côté client | ✅ | Le serveur calcule le montant ; le navigateur n'envoie ni montant ni statut (contrôlé en navigateur). |
| Contrôle des rôles / validation serveur | ✅ | Toutes les actions admin exigent `admins/{uid}` dans la transaction. |
| Preuves de paiement | 🟡 | Storage : écriture dans son dossier seulement, image < 5 Mo, lecture propriétaire/admin, pas de modification/suppression. |
| Journal d'audit | ✅ financier / 🟡 reste | Actions financières écrites par le serveur. Les autres journaux admin (`admin_logs`) sont écrits par le navigateur de l'admin : un admin malveillant pourrait y inscrire de fausses lignes (risque résiduel). |
| Règles financières non rétroactives | ✅ | Règles figées par tournoi à la 1re inscription payante confirmée. |
| Factures infalsifiables | ✅ logique | Numérotation unique séquentielle, signature HMAC avec `INVOICE_SECRET` (serveur seulement), vérification publique sans donnée personnelle, facture ≠ reçu. |
| Antifraude parrainage | ✅ | Auto-parrainage, même numéro, paiement ou compte du filleul lié au numéro du parrain, plafond 30 filleuls, validation admin tracée. Limite : un fraudeur avec deux numéros distincts n'est pas détecté. |
| Secrets | ✅ | Aucun secret dans le ZIP ni dans le frontend (scan effectué). `INVOICE_SECRET` = secret Firebase. `functions/.env` : clé Web publique seulement. |
| Restriction des API | 🔴 | À faire dans la console Google Cloud : restreindre la clé Web aux domaines autorisés et aux API nécessaires. |
| App Check | 🔴 | Option serveur prête (`ENFORCE_APPCHECK=1`) ; le client ne l'active pas encore. |
| Date de naissance | 🟡 | Déclarative, non vérifiée : la protection des mineurs repose sur cette déclaration. |
| Politique de contenu (CSP) | 🔴 | Non configurée ; scripts Firebase et QR chargés depuis des CDN. |
| Validation Mobile Money | 🟡 | Vérification **manuelle** par l'admin : le système n'est pas connecté aux opérateurs ; une capture ne suffit jamais. |
