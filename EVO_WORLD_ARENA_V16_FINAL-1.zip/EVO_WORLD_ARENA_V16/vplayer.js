// ============================================================
// EVO VIDEO — lecteur vidéo des posts (remplace le lecteur moche du navigateur)
//
//  • Dans le fil  : style Instagram — pas de barre du navigateur, bouton play central,
//                   fine barre de progression, bouton son, bouton plein écran,
//                   lecture auto (muette) quand la vidéo est à l'écran, double-tap = like.
//  • Plein écran  : style TikTok — vidéo en grand, on glisse vers le haut/bas pour changer de vidéo,
//                   colonne à droite (avatar +, ❤️, 💬, ↗️), pseudo + texte en bas, panneau de commentaires.
//
//  Aucun changement à faire ailleurs : tout <div class="evv"> ajouté à la page est activé automatiquement.
//  Utilise les fonctions de saucial.html : allPosts, likePost, partagerPost, basculerSuivi, ouvrirProfil…
// ============================================================
(function () {
  if (window.EvoVideo) return;

  var I = {
    play:  '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>',
    vol:   '<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 4V5L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z"/></svg>',
    mute:  '<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 4V5L7 9H3zm13.6 3 2.7-2.7-1.4-1.4-2.7 2.7-2.7-2.7-1.4 1.4 2.7 2.7-2.7 2.7 1.4 1.4 2.7-2.7 2.7 2.7 1.4-1.4z"/></svg>',
    expand:'<svg viewBox="0 0 24 24"><path d="M4 4h6v2H6v4H4V4zm10 0h6v6h-2V6h-4V4zM4 14h2v4h4v2H4v-6zm14 0h2v6h-6v-2h4v-4z"/></svg>',
    heart: '<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-9.6-9.2C.9 8.4 2.7 5 6 5c2 0 3.4 1.1 4 2.2h4C14.6 6.1 16 5 18 5c3.3 0 5.1 3.4 3.6 6.8C19.5 16.3 12 21 12 21z" transform="translate(0 -.5)"/></svg>',
    comment:'<svg viewBox="0 0 24 24"><path d="M12 3C6.5 3 2 6.6 2 11c0 2.4 1.3 4.5 3.4 6L4.500 21l4.300-2.100c1 .2 2 .3 3.200.3 5.500 0 10-3.600 10-8S17.500 3 12 3z"/></svg>',
    share: '<svg viewBox="0 0 24 24"><path d="M14 4v4.500C8 9 4.500 12.500 3.500 19c2.500-3.200 5.500-4.600 10.500-4.600V19l7.500-7.500L14 4z"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6.400 5 5 6.400 10.600 12 5 17.600 6.400 19l5.600-5.600 5.600 5.600 1.400-1.400L13.400 12 19 6.400 17.600 5 12 10.600z"/></svg>',
    plus:  '<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',
    send:  '<svg viewBox="0 0 24 24"><path d="M3 20.500 22 12 3 3.500V10l13 2-13 2z"/></svg>'
  };

  var CSS = [
    // ---------- Lecteur dans le fil ----------
    '.post-media.pm-video{display:block;max-height:none;position:relative}',
    '.evv{position:relative;width:100%;aspect-ratio:4/5;max-height:78vh;background:#000;overflow:hidden;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;touch-action:manipulation}',
    '.evv video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000;display:block}',
    '.evv-tap{position:absolute;inset:0;z-index:2;cursor:pointer}',
    '.evv svg,.evt svg{width:100%;height:100%;fill:currentColor;display:block}',
    '.evv-big{position:absolute;left:50%;top:50%;width:66px;height:66px;margin:-33px 0 0 -33px;border-radius:50%;background:rgba(0,0,0,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);color:#fff;padding:17px 14px 17px 20px;z-index:3;pointer-events:none;transition:opacity .2s,transform .2s;border:1.5px solid rgba(255,255,255,.25)}',
    '.evv.playing .evv-big{opacity:0;transform:scale(.7)}',
    '.evv.loading .evv-big{opacity:.5}',
    '.evv-bar{position:absolute;left:0;right:0;bottom:0;z-index:4;display:flex;align-items:center;gap:10px;padding:26px 10px 8px;background:linear-gradient(to top,rgba(0,0,0,.75),transparent);color:#fff;font-size:.62rem;font-weight:600}',
    '.evv-time{min-width:34px;font-variant-numeric:tabular-nums;opacity:.9;text-shadow:0 1px 2px #000}',
    '.evv-seek{flex:1;height:22px;display:flex;align-items:center;cursor:pointer;touch-action:none}',
    '.evv-seek span{position:relative;display:block;width:100%;height:3px;border-radius:3px;background:rgba(255,255,255,.3);transition:height .15s}',
    '.evv-seek i{position:absolute;left:0;top:0;bottom:0;width:0;border-radius:3px;background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed))}',
    '.evv-seek i::after{content:"";position:absolute;right:-6px;top:50%;width:12px;height:12px;margin-top:-6px;border-radius:50%;background:#fff;box-shadow:0 0 6px rgba(0,0,0,.6);transform:scale(0);transition:transform .15s}',
    '.evv-seek.drag span,.evv-seek:hover span{height:5px}',
    '.evv-seek.drag i::after,.evv-seek:hover i::after{transform:scale(1)}',
    '.evv-btn{width:32px;height:32px;padding:7px;border:none;border-radius:50%;background:rgba(0,0,0,.4);color:#fff;cursor:pointer;flex:none}',
    '.evv-btn:active{transform:scale(.9)}',
    '.evv-heart{position:absolute;left:50%;top:50%;width:96px;height:96px;margin:-48px 0 0 -48px;color:#ff2d55;z-index:5;pointer-events:none;opacity:0;filter:drop-shadow(0 4px 14px rgba(255,45,85,.6))}',
    '.evv-heart.go{animation:evvHeart .8s ease forwards}',
    '@keyframes evvHeart{0%{opacity:0;transform:scale(.3)}25%{opacity:1;transform:scale(1.15)}55%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(1.3) translateY(-30px)}}',
    '.evv-dur{position:absolute;top:10px;left:10px;z-index:4;background:rgba(0,0,0,.55);color:#fff;font-size:.6rem;font-weight:700;padding:3px 8px;border-radius:10px;pointer-events:none;transition:opacity .2s}',
    '.evv.playing .evv-dur{opacity:0}',

    // ---------- Plein écran style TikTok ----------
    '.evt{position:fixed;inset:0;z-index:99990;background:#000;color:#fff;font-family:inherit;-webkit-tap-highlight-color:transparent;opacity:0;transition:opacity .2s}',
    '.evt.on{opacity:1}',
    '.evt-scroll{position:absolute;inset:0;overflow-y:scroll;scroll-snap-type:y mandatory;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;scrollbar-width:none}',
    '.evt-scroll::-webkit-scrollbar{display:none}',
    '.evt-s{position:relative;width:100%;height:100vh;height:100dvh;scroll-snap-align:start;scroll-snap-stop:always;background:#000;overflow:hidden}',
    '.evt-s video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000}',
    '.evt-s.cover video{object-fit:cover}',
    '.evt-tap{position:absolute;inset:0;z-index:2}',
    '.evt-shade{position:absolute;left:0;right:0;bottom:0;height:42%;background:linear-gradient(to top,rgba(0,0,0,.75),transparent);z-index:3;pointer-events:none}',
    '.evt-top{position:fixed;top:0;left:0;right:0;z-index:20;display:flex;align-items:center;justify-content:space-between;padding:calc(10px + env(safe-area-inset-top)) 12px 10px;pointer-events:none;background:linear-gradient(to bottom,rgba(0,0,0,.55),transparent)}',
    '.evt-top>*{pointer-events:auto}',
    '.evt-title{font-weight:800;font-size:.85rem;letter-spacing:.5px;text-shadow:0 1px 4px #000}',
    '.evt-ic{width:38px;height:38px;padding:8px;border:none;border-radius:50%;background:rgba(0,0,0,.4);color:#fff;cursor:pointer}',
    '.evt-rail{position:absolute;right:8px;bottom:calc(86px + env(safe-area-inset-bottom));z-index:6;display:flex;flex-direction:column;align-items:center;gap:16px}',
    '.evt-av{position:relative;width:48px;height:48px;margin-bottom:6px;cursor:pointer}',
    '.evt-av>div{width:48px;height:48px;border-radius:50%;border:2px solid #fff;overflow:hidden;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.8rem;color:#000}',
    '.evt-av img{width:100%;height:100%;object-fit:cover}',
    '.evt-av b{position:absolute;left:50%;bottom:-9px;width:20px;height:20px;margin-left:-10px;border-radius:50%;background:#ff2d55;color:#fff;padding:3px;border:none;cursor:pointer}',
    '.evt-av b.hide{display:none}',
    '.evt-act{display:flex;flex-direction:column;align-items:center;gap:3px;background:none;border:none;color:#fff;cursor:pointer;font-size:.7rem;font-weight:700;text-shadow:0 1px 3px rgba(0,0,0,.8);padding:0}',
    '.evt-act svg{width:36px;height:36px;filter:drop-shadow(0 1px 3px rgba(0,0,0,.6));transition:transform .2s,fill .2s}',
    '.evt-act:active svg{transform:scale(.85)}',
    '.evt-act.liked svg{fill:#ff2d55;animation:evtPop .35s ease}',
    '@keyframes evtPop{0%{transform:scale(.6)}60%{transform:scale(1.3)}100%{transform:scale(1)}}',
    '.evt-info{position:absolute;left:12px;right:78px;bottom:calc(26px + env(safe-area-inset-bottom));z-index:6;text-shadow:0 1px 4px rgba(0,0,0,.9)}',
    '.evt-user{font-weight:800;font-size:.95rem;cursor:pointer;display:inline-block}',
    '.evt-clan{font-size:.65rem;color:var(--c1,#00ff88);margin-top:1px}',
    '.evt-txt{font-size:.82rem;line-height:1.4;margin-top:6px;max-height:4.2em;overflow:hidden;word-break:break-word}',
    '.evt-snd{font-size:.68rem;margin-top:8px;opacity:.9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.evt-prog{position:absolute;left:0;right:0;bottom:0;z-index:7;height:22px;display:flex;align-items:flex-end;padding-bottom:calc(0px + env(safe-area-inset-bottom));cursor:pointer;touch-action:none}',
    '.evt-prog span{position:relative;display:block;width:100%;height:3px;background:rgba(255,255,255,.25);transition:height .15s}',
    '.evt-prog i{position:absolute;left:0;top:0;bottom:0;width:0;background:#fff}',
    '.evt-prog.drag span{height:8px}',
    '.evt-pause{position:absolute;left:50%;top:50%;width:84px;height:84px;margin:-42px 0 0 -42px;z-index:5;color:#fff;opacity:0;pointer-events:none;padding:18px 14px 18px 22px;background:rgba(0,0,0,.35);border-radius:50%;transition:opacity .2s}',
    '.evt-s.paused .evt-pause{opacity:.95}',
    '.evt-heart{position:absolute;width:110px;height:110px;margin:-55px 0 0 -55px;color:#ff2d55;z-index:8;pointer-events:none;animation:evvHeart .8s ease forwards;filter:drop-shadow(0 4px 14px rgba(255,45,85,.6))}',

    // ---------- Panneau commentaires ----------
    '.evt-sheet{position:fixed;left:0;right:0;bottom:0;z-index:30;height:68vh;background:#15151f;border-radius:18px 18px 0 0;transform:translateY(100%);transition:transform .28s ease;display:flex;flex-direction:column;box-shadow:0 -10px 40px rgba(0,0,0,.6)}',
    '.evt-sheet.on{transform:none}',
    '.evt-sh-h{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;font-weight:800;font-size:.85rem;border-bottom:1px solid rgba(255,255,255,.08)}',
    '.evt-sh-h button{width:30px;height:30px;padding:6px;border:none;background:none;color:#fff;cursor:pointer}',
    '.evt-sh-l{flex:1;overflow-y:auto;padding:8px 16px}',
    '.evt-c{padding:9px 0;font-size:.8rem;line-height:1.4;border-bottom:1px solid rgba(255,255,255,.04)}',
    '.evt-c b{color:var(--c1,#00ff88);font-size:.75rem;display:block;margin-bottom:2px}',
    '.evt-c-e{color:#777;text-align:center;padding:40px 0;font-size:.8rem}',
    '.evt-sh-f{display:flex;gap:8px;padding:10px 12px calc(10px + env(safe-area-inset-bottom));border-top:1px solid rgba(255,255,255,.08)}',
    '.evt-sh-f input{flex:1;min-width:0;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:22px;padding:10px 14px;color:#fff;font-size:.85rem;outline:none;font-family:inherit}',
    '.evt-sh-f input:focus{border-color:var(--c1,#00ff88)}',
    '.evt-sh-f button{width:42px;height:42px;padding:10px;border:none;border-radius:50%;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;cursor:pointer;flex:none}'
  ].join('\n');

  var st = document.createElement('style');
  st.textContent = CSS;
  document.head.appendChild(st);

  // ---------- Outils ----------
  function esc(s) {
    if (typeof window.escapeHtml === 'function') return window.escapeHtml(s);
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; });
  }
  function fmt(t) {
    if (!isFinite(t) || t < 0) t = 0;
    var m = Math.floor(t / 60), s = Math.floor(t % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }
  function nb(n) {
    n = n || 0;
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace('.0', '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace('.0', '') + 'K';
    return String(n);
  }
  function getPost(id) {
    try { return (allPosts || []).find(function (p) { return p.id === id; }); } catch (e) { return null; }
  }
  function arr(p, k) { try { return arrGet(p, k); } catch (e) { return []; } }
  function me() { try { return userConnecte; } catch (e) { return null; } }
  function toast(m, t) { try { showToast(m, t); } catch (e) {} }
  function tryPlay(v) {
    var pr = v.play();
    if (pr && pr.catch) pr.catch(function () {
      if (!v.muted) { v.muted = true; var p2 = v.play(); if (p2 && p2.catch) p2.catch(function () {}); }
    });
  }
  // Barre de progression avec glisser pour avancer/reculer
  function bindSeek(bar, video, cls) {
    var active = false;
    function pos(e) {
      var r = bar.getBoundingClientRect();
      var x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
      var ratio = Math.max(0, Math.min(1, x / r.width));
      if (video.duration) video.currentTime = ratio * video.duration;
    }
    bar.addEventListener('pointerdown', function (e) {
      e.stopPropagation(); active = true; bar.classList.add('drag');
      try { bar.setPointerCapture(e.pointerId); } catch (x) {}
      pos(e);
    });
    bar.addEventListener('pointermove', function (e) { if (active) { e.preventDefault(); pos(e); } });
    function end() { active = false; bar.classList.remove('drag'); }
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end);
    bar.addEventListener('click', function (e) { e.stopPropagation(); });
  }

  var EV = { muted: true };

  // ---------- Lecteur du fil ----------
  var io = null;
  function ensureIO() {
    if (io || !('IntersectionObserver' in window)) return;
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var el = en.target, v = el.querySelector('video');
        if (!v) return;
        if (document.getElementById('evtRoot')) { v.pause(); return; }
        if (en.isIntersecting && en.intersectionRatio >= 0.6) {
          if (!el._userPaused) { v.muted = EV.muted; tryPlay(v); }
        } else {
          v.pause(); el._userPaused = false;
        }
      });
    }, { threshold: [0, 0.6, 1] });
  }

  function html(src, postId, poster) {
    return '<div class="evv" data-evv="' + esc(postId || '') + '">' +
      '<video playsinline webkit-playsinline muted loop preload="metadata"' + (poster ? ' poster="' + esc(poster) + '"' : '') + ' src="' + esc(src) + '#t=0.1"></video>' +
      '<div class="evv-dur"></div>' +
      '<div class="evv-tap"></div>' +
      '<div class="evv-big">' + I.play + '</div>' +
      '<div class="evv-heart">' + I.heart + '</div>' +
      '<div class="evv-bar">' +
        '<span class="evv-time">0:00</span>' +
        '<div class="evv-seek"><span><i></i></span></div>' +
        '<button type="button" class="evv-btn evv-mute" aria-label="Son">' + I.mute + '</button>' +
        '<button type="button" class="evv-btn evv-full" aria-label="Plein écran">' + I.expand + '</button>' +
      '</div></div>';
  }

  function initOne(el) {
    if (el._evv) return;
    el._evv = true;
    var v = el.querySelector('video');
    var tap = el.querySelector('.evv-tap');
    var fill = el.querySelector('.evv-seek i');
    var time = el.querySelector('.evv-time');
    var dur = el.querySelector('.evv-dur');
    var mute = el.querySelector('.evv-mute');
    var heart = el.querySelector('.evv-heart');
    var id = el.getAttribute('data-evv');

    function setMuteIcon() { mute.innerHTML = v.muted ? I.mute : I.vol; }
    setMuteIcon();

    v.addEventListener('loadedmetadata', function () {
      if (v.videoWidth && v.videoHeight) {
        var r = v.videoWidth / v.videoHeight;
        r = Math.max(0.8, Math.min(1.78, r));
        el.style.aspectRatio = String(r);
      }
      dur.textContent = fmt(v.duration);
      time.textContent = fmt(v.duration);
    });
    v.addEventListener('timeupdate', function () {
      if (!v.duration) return;
      fill.style.width = (v.currentTime / v.duration * 100) + '%';
      time.textContent = fmt(v.duration - v.currentTime);
    });
    v.addEventListener('play', function () {
      // une seule vidéo à la fois
      document.querySelectorAll('.evv video').forEach(function (o) { if (o !== v) o.pause(); });
      el.classList.add('playing'); el.classList.remove('loading');
    });
    v.addEventListener('pause', function () { el.classList.remove('playing'); });
    v.addEventListener('waiting', function () { el.classList.add('loading'); });
    v.addEventListener('playing', function () { el.classList.remove('loading'); });
    v.addEventListener('volumechange', setMuteIcon);

    bindSeek(el.querySelector('.evv-seek'), v);

    mute.addEventListener('click', function (e) {
      e.stopPropagation();
      EV.muted = !EV.muted;
      document.querySelectorAll('.evv video').forEach(function (o) { o.muted = EV.muted; });
      if (v.paused && !EV.muted) { el._userPaused = false; tryPlay(v); }
    });
    el.querySelector('.evv-full').addEventListener('click', function (e) { e.stopPropagation(); EV.open(id, v.currentTime); });

    function burst() {
      heart.classList.remove('go'); void heart.offsetWidth; heart.classList.add('go');
    }
    var last = 0, timer = null;
    tap.addEventListener('click', function (e) {
      e.stopPropagation();
      var now = Date.now();
      if (now - last < 300) {
        clearTimeout(timer); last = 0;
        burst();
        var p = getPost(id), u = me();
        if (p && u && arr(p, 'Liked_by').indexOf(u.id) === -1) { try { likePost(id); } catch (x) {} }
        else if (!u) toast('⚠️ Connecte-toi pour aimer', 'error');
        return;
      }
      last = now;
      timer = setTimeout(function () {
        if (v.paused) { el._userPaused = false; v.muted = EV.muted; tryPlay(v); }
        else { el._userPaused = true; v.pause(); }
      }, 260);
    });

    ensureIO();
    if (io) io.observe(el);
  }

  function scan(root) {
    (root || document).querySelectorAll('.evv').forEach(initOne);
  }

  // ---------- Plein écran TikTok ----------
  var cur = null; // {root, posts, scroller, onPop}

  function slideHtml(p) {
    var u = me();
    var avatar = '';
    try { avatar = avatarsCache[p.User_id] || ''; } catch (e) {}
    var clan = '';
    try {
      (allClans || []).some(function (c) {
        var m = arr(c, 'Membres');
        if (m.indexOf(p.User_id) > -1 || m.indexOf(p.Psuedo) > -1) { clan = '⚔️ ' + (c.Nom || '') + (c.Tag ? ' [' + c.Tag + ']' : ''); return true; }
      });
    } catch (e) {}
    var liked = u && arr(p, 'Liked_by').indexOf(u.id) > -1;
    var showFollow = false;
    try { showFollow = u && p.User_id !== u.id && arr(u, 'Following_ids').indexOf(p.User_id) === -1; } catch (e) {}
    return '<div class="evt-s" data-id="' + esc(p.id) + '">' +
      '<video playsinline webkit-playsinline loop preload="auto" src="' + esc(p.Media_url) + '"></video>' +
      '<div class="evt-shade"></div>' +
      '<div class="evt-tap"></div>' +
      '<div class="evt-pause">' + I.play + '</div>' +
      '<div class="evt-rail">' +
        '<div class="evt-av" data-a="profil"><div>' + (avatar ? '<img src="' + esc(avatar) + '" alt="">' : esc((p.Psuedo || '??').substring(0, 2).toUpperCase())) + '</div>' +
          '<b data-a="follow" class="' + (showFollow ? '' : 'hide') + '">' + I.plus + '</b></div>' +
        '<button class="evt-act' + (liked ? ' liked' : '') + '" data-a="like">' + I.heart + '<span data-k="likes">' + nb(p.Likes) + '</span></button>' +
        '<button class="evt-act" data-a="comment">' + I.comment + '<span data-k="comments">' + nb(p.Comment) + '</span></button>' +
        '<button class="evt-act" data-a="share">' + I.share + '<span>Partager</span></button>' +
        '<button class="evt-act" data-a="mute"><span class="evt-mi" style="width:30px;height:30px;display:block">' + (EV.muted ? I.mute : I.vol) + '</span></button>' +
      '</div>' +
      '<div class="evt-info">' +
        '<div class="evt-user" data-a="profil">@' + esc(p.Psuedo || 'Anonyme') + '</div>' +
        (clan ? '<div class="evt-clan">' + esc(clan) + '</div>' : '') +
        (p.Contenu ? '<div class="evt-txt">' + esc(p.Contenu) + '</div>' : '') +
        '<div class="evt-snd">♪ Son original — ' + esc(p.Psuedo || 'Anonyme') + '</div>' +
      '</div>' +
      '<div class="evt-prog"><span><i></i></span></div>' +
    '</div>';
  }

  function syncSlide(s) {
    var p = getPost(s.getAttribute('data-id'));
    if (!p) return;
    var u = me();
    var liked = u && arr(p, 'Liked_by').indexOf(u.id) > -1;
    var b = s.querySelector('[data-a="like"]');
    b.classList.toggle('liked', !!liked);
    s.querySelector('[data-k="likes"]').textContent = nb(p.Likes);
    s.querySelector('[data-k="comments"]').textContent = nb(p.Comment);
  }

  EV.open = function (id, startTime) {
    if (cur) return;
    var posts = [];
    try { posts = (allPosts || []).filter(function (p) { return p.Media_type === 'video' && p.Media_url; }); } catch (e) {}
    var idx = posts.findIndex(function (p) { return p.id === id; });
    if (idx < 0) return;

    document.querySelectorAll('.evv video').forEach(function (o) { o.pause(); });

    var root = document.createElement('div');
    root.className = 'evt'; root.id = 'evtRoot';
    root.innerHTML =
      '<div class="evt-top"><button class="evt-ic" data-a="close" aria-label="Fermer">' + I.close + '</button>' +
      '<div class="evt-title">EVO ARENA</div><span style="width:38px"></span></div>' +
      '<div class="evt-scroll">' + posts.map(slideHtml).join('') + '</div>' +
      '<div class="evt-sheet" id="evtSheet"><div class="evt-sh-h"><span id="evtShTitle">Commentaires</span><button data-a="sheetClose">' + I.close + '</button></div>' +
        '<div class="evt-sh-l" id="evtShList"></div>' +
        '<form class="evt-sh-f" id="evtShForm"><input id="evtShInput" type="text" maxlength="300" placeholder="Ajouter un commentaire…" autocomplete="off"><button type="submit" aria-label="Envoyer">' + I.send + '</button></form></div>';
    document.body.appendChild(root);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { root.classList.add('on'); });

    var scroller = root.querySelector('.evt-scroll');
    var slides = [].slice.call(root.querySelectorAll('.evt-s'));
    var sheetPost = null;
    cur = { root: root };

    // Retour Android / geste retour = fermer
    history.pushState({ evt: 1 }, '');
    cur.onPop = function () { close(true); };
    window.addEventListener('popstate', cur.onPop);

    function activeVideo() {
      var h = scroller.clientHeight;
      var s = slides[Math.round(scroller.scrollTop / h)];
      return s ? s.querySelector('video') : null;
    }

    slides.forEach(function (s) {
      var v = s.querySelector('video');
      var fill = s.querySelector('.evt-prog i');
      v.muted = EV.muted;
      v.addEventListener('loadedmetadata', function () {
        if (v.videoWidth && v.videoHeight && v.videoWidth / v.videoHeight < 0.8) s.classList.add('cover');
      });
      v.addEventListener('timeupdate', function () { if (v.duration) fill.style.width = (v.currentTime / v.duration * 100) + '%'; });
      v.addEventListener('play', function () { s.classList.remove('paused'); });
      v.addEventListener('pause', function () { if (v._byUser) s.classList.add('paused'); });
      bindSeek(s.querySelector('.evt-prog'), v);

      var last = 0, timer = null;
      s.querySelector('.evt-tap').addEventListener('click', function (e) {
        var now = Date.now();
        if (now - last < 300) {
          clearTimeout(timer); last = 0;
          var h = document.createElement('div');
          h.className = 'evt-heart'; h.innerHTML = I.heart;
          var r = s.getBoundingClientRect();
          h.style.left = (e.clientX - r.left) + 'px'; h.style.top = (e.clientY - r.top) + 'px';
          s.appendChild(h); setTimeout(function () { h.remove(); }, 850);
          var p = getPost(s.getAttribute('data-id')), u = me();
          if (p && u && arr(p, 'Liked_by').indexOf(u.id) === -1) doLike(s);
          else if (!u) toast('⚠️ Connecte-toi pour aimer', 'error');
          return;
        }
        last = now;
        timer = setTimeout(function () {
          if (v.paused) { v._byUser = false; tryPlay(v); } else { v._byUser = true; v.pause(); }
        }, 260);
      });
    });

    function doLike(s) {
      var id2 = s.getAttribute('data-id'), p = getPost(id2), u = me();
      if (!u) { toast('⚠️ Connecte-toi pour aimer', 'error'); return; }
      var b = s.querySelector('[data-a="like"]'), c = s.querySelector('[data-k="likes"]');
      var was = b.classList.contains('liked');
      b.classList.toggle('liked', !was);
      c.textContent = nb(Math.max(0, (p ? p.Likes || 0 : 0) + (was ? -1 : 1)));
      var pr; try { pr = likePost(id2); } catch (e) {}
      Promise.resolve(pr).then(function () { setTimeout(function () { if (cur) syncSlide(s); }, 900); });
    }

    // lecture de la vidéo visible
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var v = en.target.querySelector('video');
        if (en.isIntersecting && en.intersectionRatio >= 0.6) {
          v._byUser = false; v.muted = EV.muted; tryPlay(v);
        } else { v.pause(); if (en.intersectionRatio === 0) v.currentTime = 0; }
      });
    }, { root: scroller, threshold: [0, 0.6, 1] });
    slides.forEach(function (s) { obs.observe(s); });
    cur.obs = obs;

    scroller.scrollTop = idx * scroller.clientHeight;
    var v0 = slides[idx].querySelector('video');
    if (startTime) v0.addEventListener('loadedmetadata', function () { try { v0.currentTime = startTime; } catch (e) {} }, { once: true });

    // ----- Commentaires -----
    function renderComments(p) {
      var l = root.querySelector('#evtShList');
      var cs = arr(p, 'Commentaires');
      root.querySelector('#evtShTitle').textContent = (p.Comment || cs.length || 0) + ' commentaire(s)';
      if (!cs.length) { l.innerHTML = '<div class="evt-c-e">Aucun commentaire.<br>Sois le premier !</div>'; return; }
      l.innerHTML = cs.map(function (raw) {
        var c = {}; try { c = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { c = { message: raw }; }
        return '<div class="evt-c"><b>' + esc(c.Psuedo || 'Membre') + '</b>' + esc(c.message || '') + '</div>';
      }).join('');
      l.scrollTop = l.scrollHeight;
    }
    function openSheet(s) {
      sheetPost = s.getAttribute('data-id');
      var p = getPost(sheetPost); if (!p) return;
      renderComments(p);
      root.querySelector('#evtSheet').classList.add('on');
    }
    function closeSheet() { root.querySelector('#evtSheet').classList.remove('on'); sheetPost = null; root.querySelector('#evtShInput').blur(); }
    root.querySelector('#evtShForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var inp = root.querySelector('#evtShInput');
      var txt = inp.value.trim();
      var u = me();
      if (!u) { toast('⚠️ Connecte-toi pour commenter', 'error'); return; }
      if (!txt || !sheetPost) return;
      var pid = sheetPost;
      inp.value = '';
      EvoDB.get(COLLECTIONS.POSTS, pid).then(function (doc) {
        var cs = arrGet(doc, 'Commentaires');
        cs.push(JSON.stringify({ Psuedo: u.Psuedo, message: txt, date: new Date().toISOString() }));
        return EvoDB.update(COLLECTIONS.POSTS, pid, { Commentaires: arrSet(cs), Comment: cs.length });
      }).then(function (doc) {
        var p = getPost(pid);
        if (p) { p.Commentaires = doc.Commentaires; p.Comment = doc.Comment; }
        if (cur) {
          if (p && sheetPost === pid) renderComments(p);
          var s = root.querySelector('.evt-s[data-id="' + pid + '"]'); if (s) syncSlide(s);
        }
        try { chargerPosts(); } catch (x) {}
      }).catch(function (err) { toast('❌ Erreur: ' + err.message, 'error'); });
    });

    // ----- Clics sur les boutons -----
    root.addEventListener('click', function (e) {
      var t = e.target.closest('[data-a]'); if (!t) return;
      var a = t.getAttribute('data-a');
      var s = t.closest('.evt-s');
      if (a === 'close') { close(); }
      else if (a === 'sheetClose') { closeSheet(); }
      else if (a === 'like') { doLike(s); }
      else if (a === 'comment') { openSheet(s); }
      else if (a === 'share') { try { partagerPost(s.getAttribute('data-id')); } catch (x) {} }
      else if (a === 'mute') {
        EV.muted = !EV.muted;
        slides.forEach(function (sl) { sl.querySelector('video').muted = EV.muted; sl.querySelector('.evt-mi').innerHTML = EV.muted ? I.mute : I.vol; });
        var av = activeVideo(); if (av && av.paused && !av._byUser) tryPlay(av);
      }
      else if (a === 'follow') {
        e.stopPropagation();
        var p = getPost(s.getAttribute('data-id'));
        if (!me()) { toast('⚠️ Connecte-toi pour suivre', 'error'); return; }
        t.classList.add('hide');
        try { basculerSuivi(p.User_id); } catch (x) {}
      }
      else if (a === 'profil') {
        var p2 = getPost(s.getAttribute('data-id'));
        close();
        setTimeout(function () { try { ouvrirProfil(p2.User_id); } catch (x) {} }, 60);
      }
    });

    cur.closeFn = close;
    function close(fromPop) {
      if (!cur) return;
      window.removeEventListener('popstate', cur.onPop);
      cur.obs.disconnect();
      slides.forEach(function (s) { var v = s.querySelector('video'); v.pause(); v.removeAttribute('src'); v.load(); });
      var r = cur.root; cur = null;
      r.classList.remove('on');
      setTimeout(function () { r.remove(); }, 200);
      document.body.style.overflow = '';
      if (!fromPop && history.state && history.state.evt) history.back();
    }
  };

  EV.close = function () { if (cur) cur.closeFn(); };
  EV.html = html;
  EV.scan = scan;

  window.EvoVideo = EV;

  // Active automatiquement tout lecteur ajouté à la page (fil, profil d'un joueur, etc.)
  function start() {
    scan(document);
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        if (muts[i].addedNodes.length) { scan(document); break; }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
