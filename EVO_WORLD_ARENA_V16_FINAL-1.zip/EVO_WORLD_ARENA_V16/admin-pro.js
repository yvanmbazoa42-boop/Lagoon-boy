// EVO ARENA — outils admin supplémentaires : 📊 STATS (tableau de bord + exports CSV) et 📣 ANNONCE (bandeau affiché à tous les joueurs)
(function () {
  'use strict';
  function esc(s) { return (typeof escapeHtml === 'function') ? escapeHtml(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(m, t) { try { showToast(m, t || 'info'); } catch (e) {} }
  function fmt(n) { return (Number(n) || 0).toLocaleString('fr-FR'); }
  // Protection contre l'injection de formules dans Excel/Sheets (=, +, -, @ en début de cellule)
  function cellule(v) { v = String(v == null ? '' : v).replace(/[\r\n;]+/g, ' '); return /^[=+\-@]/.test(v) ? "'" + v : v; }
  function telecharger(nom, lignes) {
    var blob = new Blob(['﻿' + lignes.join('\n')], { type: 'text/csv;charset=utf-8;' });
    var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = nom; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 4000);
  }

  var tabs = document.querySelector('.tabs');
  if (!tabs) return;
  var apres = document.getElementById('payout') || tabs.nextElementSibling;

  function ajouterOnglet(id, libelle, html, auOuverture) {
    var t = document.createElement('div'); t.className = 'tab'; t.textContent = libelle;
    t.onclick = function (ev) { openTab(id, ev); if (auOuverture) auOuverture(); };
    tabs.appendChild(t);
    var c = document.createElement('div'); c.id = id; c.className = 'tab-content'; c.innerHTML = html;
    (apres && apres.parentNode ? apres.parentNode : document.body).appendChild(c);
  }

  // ---------------------------------------------------------------- STATS
  var css = document.createElement('style');
  css.textContent = '.kpi-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}.kpi{background:rgba(255,255,255,.04);border:1px solid rgba(var(--c1-rgb,0,255,136),.2);border-radius:12px;padding:12px;text-align:center}.kpi b{display:block;font-size:1.25rem;color:var(--c1,#00ff88)}.kpi span{font-size:.65rem;color:#94a3b8;letter-spacing:.5px}.barre{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:.72rem}.barre .nom{flex:0 0 112px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.barre .piste{flex:1;background:#1a1a2e;border-radius:6px;height:12px;overflow:hidden}.barre .rempli{height:100%;background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed));border-radius:6px}.barre .val{flex:0 0 auto;color:#fbbf24;font-weight:700}.pro-btn{width:100%;margin-top:8px;padding:11px;border:none;border-radius:10px;font-weight:800;cursor:pointer;color:#000;background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed))}.pro-btn.sec{background:#334155;color:#fff}.pro-field{width:100%;box-sizing:border-box;margin:4px 0}';
  document.head.appendChild(css);

  var dernierJoueurs = [], dernierTournois = [];
  async function chargerStats() {
    var zone = document.getElementById('statsZone'); if (!zone) return;
    zone.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:15px">Chargement…</div>';
    try {
      var r = await Promise.all([
        EvoDB.list(COLLECTIONS.TOURNAMENTS, [Q.limit(200)]),
        EvoDB.list(COLLECTIONS.PLAYERS, [Q.limit(500)])
      ]);
      var T = dernierTournois = r[0].documents || [], J = dernierJoueurs = r[1].documents || [];
      await fusionnerContacts(J);
      var inscrits = 0, attente = 0, cagnotte = 0, actifs = 0, parJeu = {};
      T.forEach(function (t) {
        var n = arrGet(t, 'Inscrits').length; inscrits += n; attente += arrGet(t, 'En_attente').length;
        var c = calculerCagnotte(t); cagnotte += c; if (t.Statut === 'actif') actifs++;
        var g = (GAMES.find(function (x) { return x.id === t.Jeux_id; }) || {}); var k = g.name || t.Nom || 'Autre';
        parJeu[k] = parJeu[k] || { n: 0, c: 0 }; parJeu[k].n += n; parJeu[k].c += c;
      });
      var soldes = J.reduce(function (a, j) { return a + (j.Solde || 0); }, 0);
      var elimines = J.filter(function (j) { return j.Eliminated === true; }).length;
      var max = Math.max.apply(null, [1].concat(Object.keys(parJeu).map(function (k) { return parJeu[k].n; })));
      var barres = Object.keys(parJeu).sort(function (a, b) { return parJeu[b].n - parJeu[a].n; }).map(function (k) {
        return '<div class="barre"><span class="nom">' + esc(k) + '</span><span class="piste"><span class="rempli" style="display:block;width:' + Math.round(parJeu[k].n / max * 100) + '%"></span></span><span class="val">' + parJeu[k].n + ' · ' + fmt(parJeu[k].c) + '</span></div>';
      }).join('') || '<div style="color:#555;text-align:center;padding:10px">Aucune donnée</div>';
      var top = J.slice().sort(function (a, b) { return (b.Match_gagnes || 0) - (a.Match_gagnes || 0); }).slice(0, 5).map(function (j, i) {
        return '<div class="barre"><span class="nom">' + (i + 1) + '. ' + esc(j.Psuedo || '—') + '</span><span class="val">' + (j.Match_gagnes || 0) + ' victoires</span></div>';
      }).join('');
      zone.innerHTML =
        '<div class="kpi-grid">' +
        '<div class="kpi"><b>' + fmt(J.length) + '</b><span>JOUEURS INSCRITS</span></div>' +
        '<div class="kpi"><b>' + fmt(T.length) + '</b><span>TOURNOIS (' + actifs + ' actifs)</span></div>' +
        '<div class="kpi"><b>' + fmt(inscrits) + '</b><span>INSCRIPTIONS VALIDÉES</span></div>' +
        '<div class="kpi"><b style="color:' + (attente ? '#f59e0b' : 'var(--c1,#00ff88)') + '">' + fmt(attente) + '</b><span>DEMANDES EN ATTENTE</span></div>' +
        '<div class="kpi"><b>' + fmt(cagnotte) + '</b><span>FCFA ENCAISSÉS (cagnottes)</span></div>' +
        '<div class="kpi"><b>' + fmt(soldes) + '</b><span>FCFA SOLDES JOUEURS</span></div>' +
        '</div>' +
        '<h3 style="color:#93c5fd;font-size:.8rem;margin:12px 0 4px">🎮 INSCRITS · CAGNOTTE PAR JEU</h3>' + barres +
        '<h3 style="color:#93c5fd;font-size:.8rem;margin:12px 0 4px">🏅 TOP 5 VICTOIRES</h3>' + (top || '<div style="color:#555">—</div>') +
        '<div style="color:#64748b;font-size:.65rem;margin-top:8px">' + elimines + ' joueur(s) éliminé(s) · données limitées à 500 joueurs et 200 tournois</div>';
    } catch (e) { zone.innerHTML = '<div style="color:#f59e0b;text-align:center;padding:15px">⚠️ ' + esc(e.message || 'Erreur de chargement') + '</div>'; }
  }

  function exporterJoueurs() {
    if (!dernierJoueurs.length) { toast('⚠️ Ouvre d\'abord les stats (aucun joueur chargé)', 'error'); return; }
    var l = ['Pseudo;WhatsApp;Téléphone;Solde;Victoires;Défaites;Vies;Statut'];
    dernierJoueurs.forEach(function (j) { l.push([j.Psuedo, j.WhatsApp, j.Tel, j.Solde || 0, j.Match_gagnes || 0, j.Match_perdus || 0, j.Vies, j.Statut].map(cellule).join(';')); });
    telecharger('joueurs_evoarena.csv', l); toast('✅ Export joueurs téléchargé', 'success');
  }
  function exporterInscriptions() {
    if (!dernierTournois.length) { toast('⚠️ Ouvre d\'abord les stats', 'error'); return; }
    var l = ['Tournoi;Pseudo;WhatsApp;Téléphone / Mobile Money;Opérateur;Frais;Statut'];
    var parId = {}; dernierJoueurs.forEach(function (j) { parId[j.id] = j; });
    dernierTournois.forEach(function (t) {
      arrGet(t, 'Inscrits').forEach(function (id) {
        var j = parId[id] || {};
        l.push([t.Nom, j.Psuedo || id, j.WhatsApp, j.Tel, '', '', 'validé'].map(cellule).join(';'));
      });
      arrGet(t, 'En_attente').forEach(function (raw) {
        var d = {}; try { d = typeof raw === 'string' ? JSON.parse(raw) : (raw || {}); } catch (e) {}
        var j = parId[d.playerId] || {};
        l.push([t.Nom, d.pseudo || j.Psuedo, j.WhatsApp, d.phone || j.Tel, d.operator, d.frais, 'en attente'].map(cellule).join(';'));
      });
    });
    telecharger('inscriptions_evoarena.csv', l); toast('✅ Export inscriptions téléchargé', 'success');
  }
  window.EvoAdminPro = { chargerStats: chargerStats, exporterJoueurs: exporterJoueurs, exporterInscriptions: exporterInscriptions };

  ajouterOnglet('stats', '📊 STATS',
    '<div class="section"><h2>📊 TABLEAU DE BORD</h2><div id="statsZone"></div>' +
    '<button class="pro-btn" type="button" onclick="EvoAdminPro.chargerStats()">🔄 ACTUALISER</button>' +
    '<button class="pro-btn sec" type="button" onclick="EvoAdminPro.exporterJoueurs()">⬇️ EXPORTER LES JOUEURS (CSV)</button>' +
    '<button class="pro-btn sec" type="button" onclick="EvoAdminPro.exporterInscriptions()">⬇️ EXPORTER LES INSCRIPTIONS (CSV)</button></div>',
    chargerStats);

  // ---------------------------------------------------------------- ANNONCE
  ajouterOnglet('annonce', '📣 ANNONCE',
    '<div class="section"><h2>📣 ANNONCE POUR TOUS LES JOUEURS</h2>' +
    '<div class="info-box">Un bandeau s\'affiche en haut des pages joueur. Chaque joueur peut le fermer ; il revient si tu changes le texte.</div>' +
    '<textarea id="annTexte" class="pro-field" maxlength="300" rows="3" placeholder="Ex : Tournoi Free Fire ce samedi 18h — inscriptions ouvertes !" style="padding:10px;border-radius:8px;background:rgba(var(--bg-rgb,5,5,16),.8);border:1px solid rgba(var(--c1-rgb,0,255,136),.2);color:#e0f2fe;font-family:inherit"></textarea>' +
    '<select id="annType" class="pro-field"><option value="info">📣 Information</option><option value="promo">🎁 Promotion</option><option value="alerte">⚠️ Alerte</option></select>' +
    '<input id="annLien" class="pro-field" type="url" placeholder="🔗 Lien (optionnel, https://…)">' +
    '<input id="annJours" class="pro-field" type="number" min="0" max="90" placeholder="⏳ Durée en jours (0 = sans limite)" value="3">' +
    '<button class="pro-btn" type="button" id="annPublier">📣 PUBLIER</button>' +
    '<button class="pro-btn sec" type="button" id="annRetirer">🗑️ RETIRER L\'ANNONCE</button>' +
    '<div id="annEtat" style="color:#94a3b8;font-size:.72rem;margin-top:8px"></div></div>',
    chargerAnnonceAdmin);

  async function chargerAnnonceAdmin() {
    var etat = document.getElementById('annEtat'); if (!etat) return;
    try {
      var a = await EvoDB.get('Config', 'annonce');
      document.getElementById('annTexte').value = a.Texte || '';
      document.getElementById('annType').value = /^(alerte|promo)$/.test(a.Type) ? a.Type : 'info';
      document.getElementById('annLien').value = a.Lien || '';
      etat.textContent = a.Actif === false ? 'Aucune annonce active.' : '✅ Annonce active' + (a.Date_fin ? ' jusqu\'au ' + new Date(a.Date_fin).toLocaleDateString('fr-FR') : '') + '.';
    } catch (e) { etat.textContent = 'Aucune annonce publiée pour le moment.'; }
  }
  async function ecrire(data) {
    try { await EvoDB.update('Config', 'annonce', data); }
    catch (e) { await EvoDB.create('Config', 'annonce', data); }
  }
  document.getElementById('annPublier').onclick = async function () {
    var texte = document.getElementById('annTexte').value.trim();
    if (texte.length < 3) { toast('⚠️ Écris le texte de l\'annonce', 'error'); return; }
    var lien = document.getElementById('annLien').value.trim();
    if (lien && typeof urlBrute === 'function' && !urlBrute(lien)) { toast('⚠️ Lien invalide (https:// seulement)', 'error'); return; }
    var j = parseInt(document.getElementById('annJours').value, 10) || 0;
    try {
      await ecrire({ Texte: texte.slice(0, 300), Type: document.getElementById('annType').value, Lien: lien, Actif: true, Date_fin: j > 0 ? new Date(Date.now() + j * 864e5).toISOString() : '' });
      toast('✅ Annonce publiée', 'success'); chargerAnnonceAdmin();
    } catch (e) { toast('❌ ' + (e.message || 'Erreur (règles Firestore publiées ?)'), 'error'); }
  };
  document.getElementById('annRetirer').onclick = async function () {
    if (!confirm('Retirer l\'annonce pour tous les joueurs ?')) return;
    try { await ecrire({ Actif: false, Texte: '', Lien: '', Date_fin: '' }); toast('✅ Annonce retirée', 'success'); chargerAnnonceAdmin(); }
    catch (e) { toast('❌ ' + (e.message || 'Erreur'), 'error'); }
  };
})();
