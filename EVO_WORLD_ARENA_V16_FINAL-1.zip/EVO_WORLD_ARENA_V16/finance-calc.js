'use strict';
// Calcul financier PUR et partagé : le serveur l'utilise pour décider, le tableau de bord admin en a une copie identique (finance-calc.js à la racine)
// uniquement pour la PRÉVISUALISATION. Un test vérifie que les deux fichiers sont identiques.
// Modèle : 1) commission plateforme = commissionPct % du net encaissé ; 2) la cagnotte restante est répartie : 1er/2e/3e (+ part réservée plateforme) = 100 %.
(function (root) {
  function r2(x) { return Math.round(x * 100) / 100; }
  function validateFinanceConfig(c) {
    const errors = [];
    if (!c || typeof c !== 'object') return { ok: false, errors: ['Configuration absente.'] };
    const num = (v) => typeof v === 'number' && isFinite(v);
    if (!num(c.commissionPct) || c.commissionPct < 0 || c.commissionPct > 100) errors.push('Commission : un nombre entre 0 et 100.');
    const s = c.split || {};
    ['first', 'second', 'third', 'platform'].forEach(function (k) { if (!num(s[k]) || s[k] < 0 || s[k] > 100) errors.push('Répartition « ' + k + ' » : un nombre entre 0 et 100.'); });
    if (!errors.length) {
      if (s.first <= 0) errors.push('Le 1er doit recevoir plus de 0 %.');
      const total = Math.round((s.first + s.second + s.third + s.platform) * 100);
      if (total !== 10000) errors.push('La somme des répartitions doit être exactement 100 % (actuellement ' + r2(total / 100) + ' %).');
      [c.commissionPct, s.first, s.second, s.third, s.platform].forEach(function (v) { if (Math.round(v * 100) !== v * 100 && Math.abs(Math.round(v * 100) - v * 100) > 1e-9) errors.push('Maximum 2 décimales.'); });
    }
    return { ok: errors.length === 0, errors: errors };
  }
  // net = encaissé - remboursé (FCFA entiers). Les arrondis vont toujours à la plateforme : la somme des parts == net, au franc près.
  function simulateFinance(c, net) {
    net = Math.max(0, Math.floor(net || 0));
    const commission = Math.round(net * c.commissionPct / 100), pool = net - commission;
    const first = Math.floor(pool * c.split.first / 100), second = Math.floor(pool * c.split.second / 100), third = Math.floor(pool * c.split.third / 100);
    const reserve = pool - first - second - third;
    return { net: net, commission: commission, pool: pool, first: first, second: second, third: third, poolReserve: reserve, platformTotal: commission + reserve, check: first + second + third + commission + reserve === net };
  }
  const api = { validateFinanceConfig: validateFinanceConfig, simulateFinance: simulateFinance };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.EvoFinance = api;
})(typeof self !== 'undefined' ? self : this);
