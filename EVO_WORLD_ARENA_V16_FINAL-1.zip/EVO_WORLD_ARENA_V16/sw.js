// EVO ARENA — service worker v15 (mise à jour du 8 nov. 2026) : application instantanée au 2e lancement + utilisable hors-ligne pour les pages.
// Ne met JAMAIS en cache les données (Firestore / connexion / paiements) : tout l'argent reste en direct.
// IMPORTANT : à chaque mise en ligne d'une nouvelle version, change VERSION ci-dessous (ex. 'evo-v15') pour forcer la mise à jour chez tous les joueurs.
const VERSION = 'evo-v15-20261108';
const PAGES = ['index.html', 'saucial.html', 'clans.html', 'live.html', 'Top_100.html', 'profil.html', 'messages.html', 'arbre.html'];
const SHELL = ['offline.html', 'theme.js', 'fonds.js', 'perf.js', 'speed.js', 'splash.js', 'firebase-config.js', 'evo-config.js', 'paiement.js', 'evo-pro.js', 'evo-native.js', 'creer.js', 'manifest.json', 'icons/icon-192.png'].concat(PAGES);

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) {
    return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); }));
  }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

function ok(r) { return r && (r.status === 200 || r.type === 'opaque'); }
function cacheFirst(req) {
  return caches.open(VERSION).then(function (c) {
    return c.match(req).then(function (hit) {
      if (hit) return hit;
      return fetch(req).then(function (r) { if (ok(r)) c.put(req, r.clone()); return r; });
    });
  });
}
// réponse instantanée depuis le cache, et mise à jour discrète en arrière-plan pour la prochaine fois
function staleWhileRevalidate(e) {
  const req = e.request;
  return caches.open(VERSION).then(function (c) {
    return c.match(req).then(function (hit) {
      const reseau = fetch(req).then(function (r) { if (ok(r)) c.put(req, r.clone()); return r; });
      if (hit) { e.waitUntil(reseau.catch(function () {})); return hit; }
      return reseau.catch(function () { return req.mode === 'navigate' ? (c.match('index.html').then(function (h) { return h || c.match('offline.html'); })) : Response.error(); });
    });
  });
}
// pages admin : toujours la version la plus récente (le cache ne sert qu'en secours)
function reseauDAbord(req) {
  return caches.open(VERSION).then(function (c) {
    const t = new Promise(function (_, no) { setTimeout(no, 4000); });
    return Promise.race([fetch(req), t]).then(function (r) { if (ok(r)) c.put(req, r.clone()); return r; })
      .catch(function () { return c.match(req).then(function (h) { return h || Response.error(); }); });
  });
}

self.addEventListener('fetch', function (e) {
  const req = e.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;
  const u = new URL(req.url);
  if (u.origin === location.origin) {
    const p = u.pathname.toLowerCase();
    if (/admin/.test(p) || p === '/sw.js') { if (p === '/sw.js') return; e.respondWith(reseauDAbord(req)); return; }
    if (/\.(webp|png|jpe?g|gif|svg|ico|woff2?)$/.test(p)) { e.respondWith(cacheFirst(req)); return; }
    e.respondWith(staleWhileRevalidate(e)); return;
  }
  // bibliothèques Firebase : versionnées dans l'URL (10.12.2) donc sans risque à garder
  if (u.hostname === 'www.gstatic.com' && u.pathname.indexOf('/firebasejs/') === 0) { e.respondWith(cacheFirst(req)); return; }
  // tout le reste (Firestore, connexion, stockage, paiements…) : réseau normal, jamais en cache
});
