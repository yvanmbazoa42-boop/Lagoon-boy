# FINAL_REPORT — EVO WORLD ARENA V16 (préproduction) — 9 nov. 2026

Ce rapport ne prétend rien qui n'ait été exécuté. Les tests serveur tournent sur une **base mémoire** (pas l'émulateur Firebase) ; les tests d'interface tournent dans Chromium avec un **faux SDK Firebase**. Détails : TEST_REPORT.md.

## 1. TERMINÉ ET TESTÉ (tests automatisés réellement exécutés : 39/39 serveur, 68/68 interface)
- **Données privées** : e-mail/téléphone/WhatsApp/naissance séparés du profil public ; enregistrement serveur (`saveContact`, y compris par un admin pour un joueur qu'il crée) ; index téléphone ; parrainage qui lit l'espace privé ; migration `migrate-private.js` (simulation, copie vérifiée, relançable, aucune donnée perdue — testée sur base mémoire).
- **Paiements unifiés** : migration des anciennes demandes « En attente » (archive, aucun doublon, montant du tournoi) ; validation d'une ancienne demande impossible sans référence Mobile Money unique ; refus avec raison, historique, verrou libéré ; ancien système sans boutons Valider/Refuser.
- **Configuration financière** : validation (somme = 100 %), simulation exacte au franc, historique versionné et immuable, conflit de version détecté, règles figées à la 1re inscription payante, confirmation explicite pour une cagnotte sans règles figées ; écran admin avec bouton désactivé si la somme ≠ 100 %.
- **EVO PREMIUM — SANS PUB** : 1 000 FCFA ; jamais actif avant confirmation ; dates début/fin ; renouvellement (prolonge depuis la fin) ; expiration (logique) ; mineurs refusés ; page `premium.html` (actif / expiré / déconnecté / historique) rendue sur Android 360 px.
- **Parrainage** : code unique, 2 récompenses à la 1re inscription payante confirmée, jamais en double, entrée gratuite utilisable une fois, antifraude (auto-parrainage, même numéro, paiement lié au parrain, plafond 30), validation admin tracée.
- **Factures** : numérotation unique, facture d'inscription ≠ reçu confirmé, signature HMAC, vérification publique sans donnée personnelle (page contrôlée), PDF via impression.
- **Interface** : 22 pages sans erreur JS ni débordement à 360 px ; un bug d'interface réel trouvé et corrigé.

## 2. DÉVELOPPÉ MAIS NON TESTÉ EN ENVIRONNEMENT RÉEL
- `firestore.rules` / `storage.rules` : tests émulateur écrits (`npm run test:rules`) **jamais exécutés** → **non validées par Firebase**.
- Cloud Functions : jamais déployées ni appelées. Surtout `phoneSignIn` (jeton personnalisé, rôle IAM requis), `requestPasswordReset`, `expireSubscriptions` (Blaze), `verifyInvoice`.
- Migration sur ta vraie base ; upload réel des captures et lecture admin ; QR code (bibliothèque cdnjs, réseau coupé) ; PDF serveur **non développé** (impression navigateur seulement).
- Parcours non cliqués de bout en bout dans le navigateur : inscription à un tournoi, gestion des tournois, upload d'une capture, flux téléphone/SMS. Aucun appareil Android physique.
- Écrans admin hérités (`admin.html` : stats, exports CSV) seulement chargés ; l'export CSV « inscriptions » lit encore l'ancienne liste `En_attente` (vide après migration) au lieu des transactions.
- Page de suivi du parrainage = onglet de `mes-paiements.html` (`parrainage.html` y redirige), pas une page distincte.

## 3. NÉCESSITE UNE ACTION DE TA PART (voir DEPLOY_GUIDE.md)
1. Forfait **Blaze**, activer **Storage**, Authentication (e-mail, Google, téléphone).
2. `firebase functions:secrets:set INVOICE_SECRET`.
3. Rôle IAM **Service Account Token Creator** pour le compte des fonctions.
4. Lancer `npm run test:rules` (émulateurs) et corriger si une règle échoue **avant** de déployer.
5. Déployer dans l'ordre : fonctions → migration (simulation puis `--apply`) → site → migration de rattrapage → règles.
6. Créer le premier admin (`admins/{uid}`), puis configurer commission et répartition dans ⚙️ Configuration.
7. Restreindre la clé Web (domaines/API) ; décider d'activer App Check (le client ne l'initialise pas encore).
8. **Décisions juridiques** : valeur légale des documents (ce ne sont pas des factures fiscales ; mention déjà présente), conditions de gain/paris et obligations locales, conservation des preuves de paiement (CGU/confidentialité à relire).
9. Paiements réels : validation toujours manuelle par un admin (pas de connexion aux opérateurs).
