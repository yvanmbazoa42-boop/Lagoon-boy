/* EVO ARENA — comportement « application native » + gestion des permissions (v14i)
 * - Demande les autorisations (notifications, appareil photo, micro) au bon moment, avec une explication claire
 * - Bouton Retour Android/navigateur qui ferme d'abord les fenêtres ouvertes
 * - Retours haptiques (vibration), pas de sélection de texte / menu contextuel / rebond de page
 * - Bandeau hors-ligne, barre d'état, écran de démarrage, clavier, partage natif, installation
 * Fonctionne dans le navigateur (PWA) ET dans l'app Capacitor (APK).
 */
(function () {
  'use strict';
  if (window.EvoPerm) return;
  var W = window, D = document, LS = W.localStorage, NAV = W.navigator;
  var CAP = W.Capacitor || null;
  var NATIF = !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform());
  function plug(n) { try { return (CAP && CAP.Plugins && CAP.Plugins[n]) || null; } catch (e) { return null; } }
  function lsGet(k) { try { return LS.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { LS.setItem(k, v); } catch (e) {} }

  /* ---------- 1. Look « native » ---------- */
  var st = D.createElement('style');
  st.textContent =
    'html{-webkit-tap-highlight-color:transparent;touch-action:manipulation;overscroll-behavior-y:none}' +
    'body{overscroll-behavior-y:none;-webkit-touch-callout:none}' +
    'body,button,a,.btn,.card,.nav-btn,.post,.post-btn,.game-card{-webkit-user-select:none;user-select:none}' +
    'input,textarea,[contenteditable],.selectable,.post-content{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default}' +
    'img,video{-webkit-user-drag:none;user-drag:none}' +
    'button:active,.btn:active,.nav-btn:active,.post-btn:active{transform:scale(.95);opacity:.85}' +
    '.bottom-nav{display:flex!important;position:fixed!important;visibility:visible!important;opacity:1!important}' +
    '.evo-kb #evoFab{display:none!important}' +
    '#evoOff{position:fixed;left:0;right:0;top:0;z-index:100020;padding:calc(6px + env(safe-area-inset-top,0px)) 10px 6px;background:#b91c1c;color:#fff;font:700 .72rem system-ui,sans-serif;text-align:center;transform:translateY(-110%);transition:transform .25s}' +
    '#evoOff.on{transform:none}' +
    '#evoOff.ok{background:#16a34a}' +
    /* feuille de permissions */
    '#evoPermBack{position:fixed;inset:0;z-index:100010;background:rgba(0,0,0,.65);display:flex;align-items:flex-end;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s}' +
    '#evoPermBack.on{opacity:1;pointer-events:auto}' +
    '#evoPerm{width:100%;max-width:520px;max-height:88vh;overflow:auto;background:#0d0d1f;border:1px solid rgba(var(--c1-rgb,0,255,136),.25);border-bottom:none;border-radius:22px 22px 0 0;padding:18px 18px calc(18px + env(safe-area-inset-bottom,0px));transform:translateY(100%);transition:transform .28s cubic-bezier(.2,.9,.3,1);color:#e0f2fe;font-family:system-ui,sans-serif}' +
    '#evoPermBack.on #evoPerm{transform:none}' +
    '#evoPerm .grip{width:40px;height:4px;border-radius:2px;background:rgba(255,255,255,.2);margin:0 auto 14px}' +
    '#evoPerm h3{margin:0 0 4px;font-size:1.05rem;color:var(--c1,#00ff88)}' +
    '#evoPerm p.sub{margin:0 0 14px;font-size:.78rem;color:#9aa3b8;line-height:1.45}' +
    '.evoP-row{display:flex;align-items:center;gap:12px;padding:12px;margin-bottom:8px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06)}' +
    '.evoP-ico{font-size:1.6rem;width:40px;text-align:center}' +
    '.evoP-txt{flex:1;min-width:0}.evoP-txt b{display:block;font-size:.85rem}.evoP-txt span{font-size:.7rem;color:#9aa3b8;line-height:1.35;display:block;margin-top:2px}' +
    '.evoP-btn{border:none;border-radius:20px;padding:8px 14px;font-weight:800;font-size:.72rem;cursor:pointer;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;white-space:nowrap}' +
    '.evoP-btn.ok{background:rgba(var(--c1-rgb,0,255,136),.15);color:var(--c1,#00ff88)}' +
    '.evoP-btn.ko{background:rgba(239,68,68,.18);color:#f87171}' +
    '.evoP-later{display:block;width:100%;margin-top:6px;padding:12px;border:none;background:transparent;color:#9aa3b8;font-size:.78rem;font-weight:700;cursor:pointer}' +
    '.evoP-main{display:block;width:100%;margin-top:10px;padding:13px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;font-weight:900;font-size:.85rem;cursor:pointer}';
  (D.head || D.documentElement).appendChild(st);

  // pas de menu contextuel (appui long) sur les médias / liens, sauf dans les champs de saisie
  D.addEventListener('contextmenu', function (e) {
    var t = e.target; if (!t || !t.closest) return;
    if (t.closest('input,textarea,[contenteditable],.selectable')) return;
    if (t.closest('img,video,a,button,.nav-btn')) e.preventDefault();
  });

  /* ---------- 2. Haptique ---------- */
  function haptic(type) {
    try {
      var H = plug('Haptics');
      if (H && H.impact) { H.impact({ style: type === 'heavy' ? 'HEAVY' : type === 'medium' ? 'MEDIUM' : 'LIGHT' }); return; }
      if (NAV.vibrate) NAV.vibrate(type === 'heavy' ? 28 : type === 'medium' ? 16 : 8);
    } catch (e) {}
  }
  D.addEventListener('pointerdown', function (e) {
    var t = e.target; if (!t || !t.closest) return;
    if (t.closest('.nav-btn')) haptic('light');
    else if (t.closest('button,.btn,.post-btn,.story-card,[data-haptic]')) haptic('light');
  }, { passive: true });

  /* ---------- 3. Bouton Retour : les fenêtres ouvertes se ferment d'abord ---------- */
  var pile = [];
  var retourEnCours = false;
  function pushOverlay(fermer) {
    pile.push(fermer);
    var pousser = function () { try { history.pushState({ evoOv: pile.length }, ''); } catch (e) {} };
    if (retourEnCours) setTimeout(pousser, 150); else pousser(); // on attend la fin d'un retour en cours (sinon il annulerait ce push)
    return function off() { // fermeture « à la main » : on retire l'entrée d'historique sans rappeler fermer()
      var i = pile.indexOf(fermer); if (i < 0) return;
      pile.splice(i, 1); retourEnCours = true;
      try { history.back(); } catch (e) {}
      setTimeout(function () { retourEnCours = false; }, 120);
    };
  }
  W.addEventListener('popstate', function () {
    if (retourEnCours) return;
    var f = pile.pop(); if (f) { try { f(); } catch (e) {} }
  });
  var AppP = plug('App');
  if (AppP && AppP.addListener) {
    try { AppP.addListener('backButton', function (ev) { if (!pile.length && !(ev && ev.canGoBack)) { try { AppP.exitApp(); } catch (e) {} } }); } catch (e) {}
  }

  /* ---------- 4. Hors-ligne ---------- */
  var bandeau = null;
  function bande(txt, ok) {
    if (!bandeau) { bandeau = D.createElement('div'); bandeau.id = 'evoOff'; (D.body || D.documentElement).appendChild(bandeau); }
    bandeau.textContent = txt; bandeau.className = ok ? 'ok' : ''; void bandeau.offsetWidth; bandeau.classList.add('on');
    if (ok) setTimeout(function () { bandeau.classList.remove('on'); }, 2200);
  }
  W.addEventListener('offline', function () { bande('📡 Pas de connexion — mode hors-ligne', false); });
  W.addEventListener('online', function () { bande('✅ Connexion rétablie', true); });
  D.addEventListener('DOMContentLoaded', function () { if (NAV.onLine === false) bande('📡 Pas de connexion — mode hors-ligne', false); });

  /* ---------- 5. Clavier (cache la barre du bas quand on écrit) ---------- */
  // La barre n'est cachée QUE si un champ de saisie est actif ET que l'écran a vraiment rétréci.
  // (Avant : une hauteur de référence périmée pouvait la cacher en permanence.)
  (function () {
    var hRef = Math.max(W.innerHeight, (W.visualViewport && W.visualViewport.height) || 0);
    function champ() { var e = D.activeElement; return !!(e && /^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName) || (e && e.isContentEditable)); }
    function maj() {
      var h = (W.visualViewport && W.visualViewport.height) || W.innerHeight;
      if (h > hRef) hRef = h;
      D.documentElement.classList.toggle('evo-kb', champ() && h < hRef * 0.75); /* ne touche que le bouton + : la barre reste toujours visible */
    }
    if (W.visualViewport) W.visualViewport.addEventListener('resize', maj);
    D.addEventListener('focusout', function () { setTimeout(maj, 150); });
    W.addEventListener('orientationchange', function () { setTimeout(function () { hRef = Math.max(W.innerHeight, (W.visualViewport && W.visualViewport.height) || 0); maj(); }, 400); });
    D.documentElement.classList.remove('evo-kb');
  })();

  /* ---------- 6. Barre d'état + écran de démarrage (app Capacitor) ---------- */
  if (NATIF) {
    try { var SB = plug('StatusBar'); if (SB) { SB.setStyle && SB.setStyle({ style: 'DARK' }); SB.setBackgroundColor && SB.setBackgroundColor({ color: '#050510' }); } } catch (e) {}
    try { var SP = plug('SplashScreen'); if (SP && SP.hide) setTimeout(function () { SP.hide(); }, 250); } catch (e) {}
  }

  /* ---------- 7. Installation (navigateur) + partage natif ---------- */
  var promptInstall = null;
  W.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); promptInstall = e; });
  W.addEventListener('appinstalled', function () { promptInstall = null; });
  function estInstallee() { return NATIF || (W.matchMedia && W.matchMedia('(display-mode: standalone)').matches) || NAV.standalone === true; }
  async function installer() {
    if (!promptInstall) return false;
    promptInstall.prompt();
    try { var r = await promptInstall.userChoice; promptInstall = null; return r && r.outcome === 'accepted'; } catch (e) { return false; }
  }
  async function partager(o) {
    try {
      var S = plug('Share');
      if (S && S.share) { await S.share(o); return true; }
      if (NAV.share) { await NAV.share(o); return true; }
      if (NAV.clipboard && o.url) { await NAV.clipboard.writeText(o.url); return 'copie'; }
    } catch (e) {}
    return false;
  }

  /* ---------- 8. Permissions ---------- */
  function cle(n) { return 'evo_perm_' + n; }
  function stopFlux(s) { try { s.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} }

  var PERMS = {
    notifications: {
      ico: '🔔', titre: 'Notifications',
      txt: 'Sois prévenu quand ton match commence, quand tu gagnes un tournoi ou qu\'on t\'écrit.',
      query: 'notifications',
      lire: async function () {
        var P = plug('PushNotifications');
        if (NATIF && P && P.checkPermissions) { var r = await P.checkPermissions(); return r.receive === 'granted' ? 'granted' : r.receive === 'denied' ? 'denied' : 'prompt'; }
        if (!('Notification' in W)) return 'unsupported';
        return Notification.permission === 'default' ? 'prompt' : Notification.permission;
      },
      demander: async function () {
        var P = plug('PushNotifications');
        if (NATIF && P && P.requestPermissions) {
          var r = await P.requestPermissions();
          if (r.receive === 'granted') { try { await P.register(); } catch (e) {} }
          return r.receive === 'granted' ? 'granted' : 'denied';
        }
        if (!('Notification' in W)) return 'unsupported';
        var p = await Notification.requestPermission();
        return p === 'default' ? 'prompt' : p;
      }
    },
    camera: {
      ico: '📸', titre: 'Appareil photo',
      txt: 'Filme et prends des photos directement dans l\'app pour tes posts et tes stories.',
      query: 'camera',
      lire: function () { return lirePermMedia('camera'); },
      demander: function () { return demanderMedia({ video: true }, 'camera'); }
    },
    micro: {
      ico: '🎤', titre: 'Microphone',
      txt: 'Enregistre le son de tes vidéos (désactivé automatiquement si tu mets une musique).',
      query: 'microphone',
      lire: function () { return lirePermMedia('micro'); },
      demander: function () { return demanderMedia({ audio: true }, 'micro'); }
    }
  };
  async function lirePermMedia(nom) {
    try {
      if (NAV.permissions && NAV.permissions.query) {
        var r = await NAV.permissions.query({ name: PERMS[nom].query });
        return r.state; // granted | denied | prompt
      }
    } catch (e) {}
    return lsGet(cle(nom)) || 'prompt';
  }
  async function demanderMedia(contraintes, nom) {
    if (!NAV.mediaDevices || !NAV.mediaDevices.getUserMedia) return 'unsupported';
    try {
      var s = await NAV.mediaDevices.getUserMedia(contraintes);
      stopFlux(s); lsSet(cle(nom), 'granted'); return 'granted';
    } catch (e) {
      var refus = e && (e.name === 'NotAllowedError' || e.name === 'SecurityError' || e.name === 'PermissionDeniedError');
      if (refus) { lsSet(cle(nom), 'denied'); return 'denied'; }
      return 'unsupported'; // pas de caméra sur l'appareil, etc.
    }
  }
  async function statut(nom) { try { return await PERMS[nom].lire(); } catch (e) { return 'prompt'; } }

  /* feuille du bas (même style qu'Android/iOS) */
  var fond = null, boite = null, offBack = null;
  function feuille(html) {
    if (!fond) {
      fond = D.createElement('div'); fond.id = 'evoPermBack';
      fond.innerHTML = '<div id="evoPerm" role="dialog" aria-modal="true"></div>';
      D.body.appendChild(fond); boite = fond.firstChild;
    }
    boite.innerHTML = '<div class="grip"></div>' + html;
    void fond.offsetWidth; fond.classList.add('on');
    if (!offBack) offBack = pushOverlay(fermerFeuille);
  }
  var resolveFeuille = null;
  function fermerFeuille() {
    if (fond) fond.classList.remove('on');
    offBack = null;
    if (resolveFeuille) { var r = resolveFeuille; resolveFeuille = null; r(); }
  }
  function fermerManuel() { if (offBack) { var o = offBack; offBack = null; o(); } if (fond) fond.classList.remove('on'); if (resolveFeuille) { var r = resolveFeuille; resolveFeuille = null; r(); } }

  var AIDE_REGLAGES = 'Ouvre <b>Paramètres › Applications › EVO ARENA › Autorisations</b> (ou, dans Chrome, l\'icône 🔒 à gauche de l\'adresse › Autorisations), puis active-la.';

  // Demande une autorisation AU MOMENT où on en a besoin, avec une explication avant la fenêtre du système.
  async function ensure(nom, pourquoi) {
    var p = PERMS[nom]; if (!p) return true;
    var s = await statut(nom);
    if (s === 'granted') return true;
    if (s === 'unsupported') return false;
    if (s === 'denied') {
      await new Promise(function (ok) {
        resolveFeuille = ok;
        feuille('<h3>' + p.ico + ' ' + p.titre + ' désactivé</h3><p class="sub">' + (pourquoi || p.txt) + '<br><br>' + AIDE_REGLAGES + '</p>' +
          '<button class="evoP-main" id="evoPOk">J\'ai compris</button>');
        D.getElementById('evoPOk').onclick = fermerManuel;
      });
      return false;
    }
    // « prompt » : écran d'explication puis vraie demande système
    var accepte = await new Promise(function (ok) {
      resolveFeuille = function () { ok(false); };
      feuille('<h3>' + p.ico + ' Autoriser ' + p.titre.toLowerCase() + ' ?</h3><p class="sub">' + (pourquoi || p.txt) + '</p>' +
        '<button class="evoP-main" id="evoPYes">Autoriser</button><button class="evoP-later" id="evoPNo">Pas maintenant</button>');
      D.getElementById('evoPYes').onclick = function () { resolveFeuille = null; ok(true); fermerManuel(); };
      D.getElementById('evoPNo').onclick = fermerManuel;
    });
    if (!accepte) return false;
    var r = await p.demander();
    if (nom === 'notifications' && r === 'granted') enregistrerPush();
    return r === 'granted';
  }

  // Écran d'accueil « autorisations » (une seule fois, après la connexion)
  async function onboarding(force) {
    if (!force && lsGet('evo_perm_onboard')) return;
    var noms = Object.keys(PERMS), etats = {};
    for (var i = 0; i < noms.length; i++) etats[noms[i]] = await statut(noms[i]);
    if (!force && noms.every(function (n) { return etats[n] === 'granted' || etats[n] === 'unsupported'; })) { lsSet('evo_perm_onboard', '1'); return; }
    function rendre() {
      var h = '<h3>Autorise EVO ARENA</h3><p class="sub">Pour une expérience complète, comme une vraie application. Tu peux changer d\'avis à tout moment dans les réglages.</p>';
      noms.forEach(function (n) {
        var p = PERMS[n], s = etats[n];
        if (s === 'unsupported') return;
        h += '<div class="evoP-row"><div class="evoP-ico">' + p.ico + '</div><div class="evoP-txt"><b>' + p.titre + '</b><span>' + p.txt + '</span></div>' +
          '<button class="evoP-btn ' + (s === 'granted' ? 'ok' : s === 'denied' ? 'ko' : '') + '" data-p="' + n + '">' + (s === 'granted' ? '✓ Activé' : s === 'denied' ? 'Refusé' : 'Autoriser') + '</button></div>';
      });
      if (!estInstallee() && promptInstall) h += '<button class="evoP-main" id="evoPInst" style="background:rgba(255,255,255,.08);color:#e0f2fe">📲 Installer l\'application</button>';
      h += '<button class="evoP-main" id="evoPFin">Continuer</button>';
      feuille(h);
      boite.querySelectorAll('[data-p]').forEach(function (b) {
        b.onclick = async function () {
          var n = b.getAttribute('data-p');
          if (etats[n] === 'granted') return;
          if (etats[n] === 'denied') { b.textContent = 'Voir comment'; boite.querySelector('.sub').innerHTML = AIDE_REGLAGES; return; }
          var r = await PERMS[n].demander(); etats[n] = r; if (n === 'notifications' && r === 'granted') enregistrerPush(); rendre();
        };
      });
      var bi = D.getElementById('evoPInst'); if (bi) bi.onclick = async function () { await installer(); rendre(); };
      D.getElementById('evoPFin').onclick = function () { lsSet('evo_perm_onboard', '1'); fermerManuel(); };
    }
    rendre();
  }

  // Notifications push natives : on garde le jeton dans la fiche du joueur (pour les envois futurs)
  function enregistrerPush() {
    var P = plug('PushNotifications'); if (!NATIF || !P) return;
    try {
      P.addListener('registration', async function (t) {
        try {
          var s = JSON.parse(lsGet('evo_session') || 'null');
          if (s && s.id && W.EvoDB && W.COLLECTIONS) await EvoDB.update(COLLECTIONS.PLAYERS, s.id, { Push_token: t.value });
        } catch (e) {}
      });
    } catch (e) {}
  }

  // Lance l'écran d'autorisations quand le joueur est connecté (une seule fois, sans gêner l'écran de connexion)
  function planifierOnboarding() {
    if (lsGet('evo_perm_onboard')) return;
    var essais = 0;
    var iv = setInterval(function () {
      essais++;
      var s = null; try { s = JSON.parse(lsGet('evo_session') || 'null'); } catch (e) {}
      if (s && s.id && !D.hidden && !D.documentElement.classList.contains('evo-kb')) { clearInterval(iv); setTimeout(function () { onboarding(false); }, 1800); }
      else if (essais > 60) clearInterval(iv);
    }, 3000);
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', planifierOnboarding); else planifierOnboarding();


  /* ---------- 8. Lien de diffusion d'écran (stream.html) ouvert depuis WhatsApp : l'app affiche la page ---------- */
  if (NATIF) {
    try {
      var APPP = plug('App');
      var allerStream = function (u) { try { var x = new URL(u); if (x.hostname === location.hostname && /\/stream\.html$/.test(x.pathname)) { if (location.pathname.slice(-11) !== 'stream.html' || location.search !== x.search) location.href = x.pathname.replace(/^\//, '') + x.search; } } catch (e) {} };
      if (APPP && APPP.addListener) APPP.addListener('appUrlOpen', function (e) { if (e && e.url) allerStream(e.url); });
      if (APPP && APPP.getLaunchUrl) APPP.getLaunchUrl().then(function (r) { if (r && r.url) allerStream(r.url); }).catch(function () {});
    } catch (e) {}
  }

  W.EvoPerm = { status: statut, request: function (n) { return PERMS[n].demander(); }, ensure: ensure, onboarding: onboarding };
  W.EvoNative = { isNative: NATIF, haptic: haptic, pushOverlay: pushOverlay, share: partager, install: installer, installed: estInstallee, plugin: plug };
})();
