# TEST_REPORT — EVO WORLD ARENA V16 (9 nov. 2026)

Règle : seuls les résultats réellement obtenus sont indiqués. **Rien ici n'a été validé par Firebase.**

## 1. Réellement exécuté
### 1.1 Tests serveur — `cd functions && npm test` → **39 tests, 39 réussis, 0 échec** (Node 22)
Base mémoire `functions/test/fakedb.js` (imite transactions sérialisées, lectures avant écritures, `create` qui échoue si le document existe). **Ce n'est pas l'émulateur Firebase.**
- 1+2 transaction créée PENDING, montant serveur, preuve -> UNDER_REVIEW, historique
- capture seule ≠ paiement confirmé : refus sans preuve, sans confirmation, mauvais montant
- 3+4+5+6 validation admin : inscrit, facture d'inscription + reçu distincts, signature, vérification
- 7 doublons : double validation concurrente, référence réutilisée, 2e demande même tournoi
- numéros de facture uniques et séquentiels, jamais écrasés
- 8 refus : raison obligatoire, référence libérée, justificatif, pas inscrit
- 9 remboursement : enregistré ≠ transfert ; reçu seulement après confirmation
- 10 parrainage : auto-parrainage, code après 1er paiement, récompense unique, suspicion
- 11 gains : calcul serveur, config obligatoire, pas de double attribution ni double paiement
- 12-14 mineurs, droits admin, preuve invalide, tournoi complet/gratuit, Sans pub
- validation : somme = 100 %, bornes, 1er > 0
- simulation : la somme des parts est toujours égale au net, au franc près
- copie client identique au calcul serveur
- setFinanceConfig : admin seulement, simulation confirmée, version + historique immuable, conflit de version
- PAS RÉTROACTIF : une cagnotte engagée garde les règles figées ; un nouveau tournoi suit la nouvelle configuration
- cagnotte encaissée sans règles figées : refus sans confirmation explicite ; sans aucune configuration : refus
- abonnement : 1000 FCFA, nom EVO PREMIUM, JAMAIS actif avant la confirmation de l'admin
- refus : abonnement jamais activé, nouvelle demande possible
- renouvellement avant l'échéance = prolongation depuis la date de fin ; après expiration = depuis maintenant
- expiration automatique : seuls les abonnements échus sont désactivés
- mineur : abonnement refusé ; double validation impossible
- saveContact : écrit dans Joueurs_prive + index téléphone, JAMAIS dans le profil public
- saveContact : validation des entrées
- saveContact : un numéro déjà rattaché à un autre compte n'est pas réattribué ; changement de numéro libère l'ancien
- findLoginEmail : retrouve le compte par numéro (usage serveur), inconnu -> null
- rateLimit : bloque après le maximum, repart après la fenêtre
- parrainage : le doublon de numéro est détecté dans l'espace PRIVÉ
- splitPlayerDoc : sépare le privé du public, garde tout le reste
- migration : simulation n'écrit rien ; exécution copie, vérifie puis retire du public ; aucune donnée perdue ; idempotente
- saveContact : un admin renseigne le contact d'un joueur qu'il a créé ; un joueur ordinaire ne peut pas viser un autre compte
- flux complet : code unique, filleul enregistré, 2 récompenses à la 1re inscription payante confirmée, jamais en double
- antifraude : code refusé après un paiement ; auto-parrainage ; 2e parrain ; code inconnu
- antifraude : le filleul paie avec le numéro du parrain -> pas de récompense automatique, SUSPECT ; l'admin valide -> récompense UNE fois
- antifraude : même numéro -> SUSPECT ; rejet admin = aucune récompense ; plafond de filleuls par parrain
- entrée gratuite : utilisée une seule fois, solde jamais négatif
- import : montants du TOURNOI (pas de l'ancienne donnée), factures d'inscription, verrous, archive, entrées invalides ignorées
- import : relancer ne crée aucun doublon ; non-admin refusé ; lot trop gros refusé
- transaction héritée : validation impossible sans référence Mobile Money saisie par l'admin ; référence unique ; puis inscrit + reçu + audit
- transaction héritée refusée : raison obligatoire, historique conservé, verrou libéré

### 1.2 Tests d'interface — `python3 tests-ui/ui-smoke.py` → **68 contrôles, 68 réussis**
Vrai navigateur Chromium, viewport **Android 360×740**, user-agent Android, écran tactile. Le SDK Firebase est **remplacé par un faux** (`tests-ui/firebase-stub.js`, base mémoire) : on teste donc l'affichage, le JavaScript des pages et les appels envoyés, **pas** Firebase.
- A : les 22 pages HTML se chargent sans erreur JavaScript et sans débordement horizontal à 360 px (accueil, profil, tournois via index, clans, messages, paiements, factures, admin, vérification, pages légales…).
- B : `premium.html` — offre affichée, formulaire, rejet d'une référence trop courte sans appel serveur, appel `submitPayment` unique avec `kind=SANS_PUB` **sans montant ni statut**, états actif / expiré / déconnecté, historique avec dates.
- C : `facture.html` (reçu vérifié, bouton PDF/impression), `parrainage.html` → suivi avec code.
- D : `verify-invoice.html` — statut + signature, aucun pseudo/uid/téléphone/e-mail.
- E : admin — ancienne demande visible dans la liste unique ; configuration financière : valeurs chargées, simulation, **bouton désactivé si la somme ≠ 100 %**, enregistrement avec version attendue ; non-admin bloqué.
- F : profil — numéro privé affiché pour le joueur lui-même.
Bug réel trouvé et corrigé grâce à ces tests : sur l'écran de configuration, une fonction masquait le bouton du même nom (le bouton Enregistrer ne se désactivait jamais).

### 1.3 Vérifications statiques
`node --check` sur tous les `.js` et tous les scripts en ligne des `.html` ; équilibre des accolades/parenthèses des deux fichiers de règles (**ce n'est pas une validation Firebase**).

## 2. Écrit mais JAMAIS exécuté (pas de réseau, pas de firebase-tools dans l'environnement)
- `functions/test/rules.emulator.test.js` et `functions/test/storage.emulator.test.js` : règles Firestore (privé, config financière, parrainage, abonnement, écritures clientes interdites) et Storage (upload de preuve, lecture, taille/type). Commande : `cd functions && npm run test:rules`.
- Cloud Functions déployées : jamais appelées pour de vrai (dont `phoneSignIn`, `requestPasswordReset`, `expireSubscriptions`).
- Migration `scripts/migrate-private.js` sur une vraie base (testée seulement sur la base mémoire).
- QR code : bibliothèque `qrcodejs` chargée depuis cdnjs, **non testée** (réseau coupé). PDF = « Imprimer / Enregistrer en PDF » du navigateur, pas de PDF serveur.
- Upload réel Storage et lecture admin des preuves, Firebase Auth réel, App Check, index Firestore (`firestore.indexes.json` non confronté à Firebase).
- Appareil Android physique : non testé (émulation Chromium uniquement).
- Aucun paiement réel lancé.
