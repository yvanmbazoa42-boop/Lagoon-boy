# EVO ARENA sur FIREBASE — guide complet (sans serveur, sans installeur)

Les tables (collections) se créent toutes seules à la première écriture : rien à créer à la main sauf l'admin.

## 1. Créer le projet
console.firebase.google.com → **Ajouter un projet** (nom : EVO ARENA ; Google Analytics : désactivé).

## 2. Authentification
Build → **Authentication** → Commencer → onglet « Sign-in method » :
- **E-mail/Mot de passe** : activer (obligatoire). Mot de passe : 6 caractères minimum côté Firebase (le site en demande 8).
- **Google** : activer, choisir un e-mail d'assistance.
- **Facebook** (facultatif) : developers.facebook.com → app → App ID + secret ; colle l'URI de redirection que Firebase affiche.
Plus tard : Authentication → Settings → **Authorized domains** : ajoute le domaine de ton site (ex. `xxx.netlify.app`).

## 3. Base de données
Build → **Firestore Database** → Créer → mode **Production** → région `eur3` (Europe) ou la plus proche.
Onglet **Règles** → remplace tout par ceci, puis **Publier** :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function connecte() { return request.auth != null; }
    match /Joueurs/{id}       { allow read: if true; allow create: if connecte() && request.auth.uid == id; allow update, delete: if connecte(); }
    match /Tournois/{id}      { allow read: if true; allow write: if connecte(); }
    match /matchs/{id}        { allow read: if true; allow write: if connecte(); }
    match /clans/{id}         { allow read: if true; allow write: if connecte(); }
    match /posts/{id}         { allow read: if true; allow write: if connecte(); }
    match /statuts/{id}       { allow read: if true; allow write: if connecte(); }
    match /live_stream/{id}   { allow read: if true; allow write: if connecte(); }
    match /clan_messages/{id} { allow read, write: if connecte(); }
    match /messages/{id}      { allow read, write: if connecte(); }
    match /_ids/{id}          { allow read, write: if false; }
    match /admins/{id}        { allow read: if connecte(); allow write: if false; }
  }
}
```
Aucun index à créer : le site trie lui-même les résultats.

## 4. Relier le site
Paramètres du projet (⚙️) → « Vos applications » → icône **</> Web** → enregistre l'app → copie l'objet `firebaseConfig`.
Ouvre `firebase-config.js` et remplace les valeurs `COLLE_ICI` (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId).

## 5. Photos et vidéos
- **Par défaut (gratuit, sans carte)** : les photos sont réduites et gardées dans la base. **Pas de vidéo.**
- **Photos et vidéos avec Appwrite (utilisé par le site)** : dans `firebase-config.js`, `APPWRITE_ENDPOINT`, `APPWRITE_PROJECT` et `APPWRITE_BUCKET` pointent vers ton bucket Storage Appwrite (`evo-media`). Dans Appwrite : Storage › ton bucket › Settings › autorise la création (Create) pour *Any* et mets la taille max de fichier assez haute pour tes vidéos. Seul le lien est gardé dans Firestore.
- **Photos HD + vidéos avec Firebase Storage** (exige l'offre **Blaze**, carte bancaire, quota gratuit conservé) : Build → Storage → Commencer ; Règles :
```
rules_version = '2';
service firebase.storage { match /b/{bucket}/o { match /files/{allPaths=**} {
  allow read: if true;
  allow write: if request.auth != null && request.resource.size < 50 * 1024 * 1024;
} } }
```
puis mets `UTILISER_STORAGE = true` dans `firebase-config.js`.

## 6. Mettre en ligne
**Sur téléphone (le plus simple)** : app.netlify.com/drop → dépose le dossier (index.html à la racine) → ajoute le domaine `xxx.netlify.app` dans Authentication → Authorized domains.
**Sur ordinateur (Firebase Hosting)** : `npm i -g firebase-tools` → `firebase login` → dans le dossier : `firebase init hosting` (dossier public : `.`, SPA : non) → `firebase deploy`. Le domaine `.web.app` est déjà autorisé.

## 7. Devenir admin
1. Inscris-toi sur le site, puis ouvre `/diagnostic.html` : il affiche ton **UID**.
2. Firestore → Données → **Démarrer une collection** `admins` → ID du document = ton UID → ajoute un champ `note` (texte) = `ok` → Enregistrer.
3. Recharge le site : l'accès admin est actif.
Pour la Régie Live, la collection `live_stream` se crée au premier clic sur « DIFFUSER ».

## 8. Vérification
Ouvre `/diagnostic.html` : tout doit être ✅. Teste : inscription, connexion, post, message de clan, tournoi.

## Sécurité à prévoir plus tard
Tout joueur connecté peut modifier les fiches joueurs (comme avant). Avant de gérer beaucoup d'argent, il faudra des Cloud Functions pour protéger `Solde`.

## 9. Vérification du numéro par SMS (facultative)
- Authentication → Sign-in method → **Téléphone** activé (déjà fait). Domaine du site dans « Domaines autorisés ».
- Sur le profil, le joueur appuie sur « 📱 Vérifier mon numéro par SMS », entre le code reçu, et son profil affiche « Numéro vérifié ✔ » (champ `Tel_verifie`).
- Limite gratuite : **10 SMS par jour** pour tout le projet ; au-delà il faut un compte de facturation (offre Blaze). La connexion reste par numéro + mot de passe : la vérification SMS n'est jamais obligatoire.

## 10. Méthodes de connexion utilisées par le site
À activer dans Authentication → Sign-in method (déjà fait : E-mail/Mot de passe, Téléphone, Google).
- **Numéro ou e-mail + mot de passe** (fournisseur E-mail/Mot de passe) : connexion principale. À l'inscription le joueur donne son numéro et, facultativement, un vrai e-mail. Sans e-mail, Firebase garde un compte interne « numéro@evoarena.cm ».
- **Mot de passe oublié ?** : envoie l'e-mail de réinitialisation Firebase (compte avec e-mail réel). Sans e-mail, le joueur utilise la connexion par SMS ou contacte le support.
- **Google** : bouton « Continuer avec Google » (la fiche joueur se crée seule au premier accès).
- **SMS** : bouton « Connexion par SMS » — fenêtre en 2 étapes (numéro, puis code). Un numéro nouveau crée un compte ; un numéro déjà vérifié sur un profil rouvre ce même compte.
- **Game Center** : réservé aux applications Apple (iOS/macOS), il ne fonctionne pas sur un site web : le site ne l'utilise pas.
