# EVO ARENA v15 — rapport de tests (8 nov. 2026)

## Ce qui a réellement été exécuté ici
`cd functions && npm test` → **10 scénarios, 0 échec** (Node 22, base mémoire `test/fakedb.js` qui imite : transactions sérialisées, lectures avant écritures, `create` qui échoue si le document existe).
    ok 1 - 1+2 transaction créée PENDING, montant serveur, preuve -> UNDER_REVIEW, historique
    ok 2 - capture seule ≠ paiement confirmé : refus sans preuve, sans confirmation, mauvais montant
    ok 3 - 3+4+5+6 validation admin : inscrit, facture d'inscription + reçu distincts, signature, vérification
    ok 4 - 7 doublons : double validation concurrente, référence réutilisée, 2e demande même tournoi
    ok 5 - numéros de facture uniques et séquentiels, jamais écrasés
    ok 6 - 8 refus : raison obligatoire, référence libérée, justificatif, pas inscrit
    ok 7 - 9 remboursement : enregistré ≠ transfert ; reçu seulement après confirmation
    ok 8 - 10 parrainage : auto-parrainage, code après 1er paiement, récompense unique, suspicion
    ok 9 - 11 gains : calcul serveur, config obligatoire, pas de double attribution ni double paiement
    ok 10 - 12-14 mineurs, droits admin, preuve invalide, tournoi complet/gratuit, Sans pub
    # tests 10
    # pass 10
    # fail 0

Couvert par ces tests (logique serveur `functions/lib/core.js`) :
| # exigé | Test | Résultat |
|---|---|---|
| 1 | Création d'une transaction (montant calculé par le serveur, PENDING, historique) | ✅ |
| 2 | Enregistrement d'une preuve → UNDER_REVIEW (chemin, type image, taille contrôlés) | ✅ |
| 3 | Validation admin : refus sans preuve / sans confirmation / mauvais montant ; inscription seulement après validation | ✅ |
| 4-5 | Facture d'inscription ≠ reçu confirmé, numéros EVO-INV-2026-000001 séquentiels, jamais écrasés | ✅ |
| 6 | Vérification : champs publics limités, signature HMAC valide/invalide, facture inconnue | ✅ (logique serveur seulement, voir ci-dessous pour le QR) |
| 7 | Doublons : double validation simultanée (1 seule passe), référence Mobile Money réutilisée, 2e demande même tournoi | ✅ |
| 8 | Refus avec raison obligatoire, référence libérée, justificatif | ✅ |
| 9 | Remboursement enregistré ≠ transfert ; reçu seulement après confirmation avec référence | ✅ |
| 10 | Parrainage : auto-parrainage, code après 1er paiement, récompense unique, entrée gratuite utilisée une fois, suspicion (même numéro) | ✅ |
| 11 | Gains : calcul serveur, config obligatoire, pas de double attribution ni double versement | ✅ |
| 12/14 | Mineurs refusés sur payant, non-admin refusé sur toutes les actions admin | ✅ (logique) |
| — | Abonnement Sans pub : 1000 FCFA, +30 jours après validation | ✅ |

Vérifications de syntaxe (`node --check`) : functions/index.js, tous les scripts en ligne de index.html, mes-paiements, facture, verify-invoice, admin-paiements, sw.js.

## Ce qui n'a PAS été testé (à faire de ton côté)
- **Firebase Emulator Suite** : impossible ici (pas de réseau, pas de firebase-tools). Le test des règles est écrit (`functions/test/rules.emulator.test.js`) mais **jamais exécuté**. `firestore.rules` et `storage.rules` n'ont donc **pas été validés par Firebase**.
- **Cloud Functions déployées** : jamais déployées ni appelées pour de vrai (`index.js` n'a qu'un contrôle de syntaxe). Dépendances `firebase-admin`/`firebase-functions` non installées ici.
- **Navigateur / Android** : aucune page ouverte dans un vrai navigateur ni sur téléphone. Affichage mobile **non testé**.
- **QR code** : bibliothèque qrcodejs chargée depuis cdnjs, non testée. **PDF** : « Imprimer / Enregistrer en PDF » du navigateur, pas de PDF généré par le serveur.
- Upload réel vers Firebase Storage, lecture des preuves par l'admin, App Check, aucun paiement réel (conformément à la consigne).
- Index Firestore : écrits d'après les requêtes des pages ; Firebase te donnera un lien si un index manque.
