// ============================================================
// THÈMES + GRANDS PARAMÈTRES — EVO WORLD ARENA (chargé sur les 8 pages)
// Thèmes, taille du texte, animations, sons, vibrations, autorisations,
// compte, stockage, installation, aide, crédits... tout dans le bouton ⚙️.
// ============================================================
(function () {
  var THEMES = {
    vert:  { nom: 'Vert Néon',  c1: '#00ff88', c2: '#7c3aed', bg: [5, 5, 16],  card: [15, 15, 30] },
    rouge: { nom: 'Rouge Feu',  c1: '#ff2d4f', c2: '#ff8a00', bg: [16, 4, 6],  card: [32, 12, 16] },
    dark:  { nom: 'Dark',       c1: '#f5f5f5', c2: '#8b8b9c', bg: [0, 0, 0],   card: [14, 14, 14] },
    rose:  { nom: 'Rose Cyber', c1: '#ff2bd6', c2: '#00d9ff', bg: [10, 4, 24], card: [26, 12, 46] },
    bleu:   { nom: 'Bleu Océan',      c1: '#3b9dff', c2: '#00e5ff', bg: [3, 8, 22],   card: [10, 20, 42] },
    or:     { nom: 'Or Royal',        c1: '#ffc400', c2: '#ff7a00', bg: [14, 10, 2],  card: [30, 22, 6] },
    violet: { nom: 'Violet Galaxie',  c1: '#b266ff', c2: '#ff4fd8', bg: [12, 3, 26],  card: [28, 12, 50] },
    sunset: { nom: 'Sunset',          c1: '#ff8c1a', c2: '#ff3d81', bg: [18, 8, 4],   card: [36, 18, 10] },
    glace:  { nom: 'Cyan Glacé',      c1: '#00f5ff', c2: '#4f7cff', bg: [2, 10, 14],  card: [8, 24, 32] },
    menthe: { nom: 'Menthe Toxique',  c1: '#c6ff00', c2: '#00e676', bg: [6, 12, 2],   card: [14, 26, 8] }
  };
  // ---- À MODIFIER ----
  var NOM_SITE = 'EVO WORLD ARENA';
  var VERSION = '14k · mise à jour du 8 nov. 2026';
  var LIEN_SITE = location.origin + '/';
  var LIEN_NOTER = '';   // lien Play Store si tu en as un (sinon la note part sur WhatsApp)
  var CREDITS = [
    'Créé et dirigé par le CEO d\'EVO WORLD ARENA',
    'Tournois e-sport mobiles : Free Fire, PUBG Mobile, Call of Duty…',
    'Merci à tous les joueurs de la communauté 🎮'
  ];
  var CONFIDENTIALITE = 'Pour faire fonctionner ton compte, le site enregistre ton pseudo, ton numéro de téléphone, tes résultats, tes publications et tes messages. Ces données servent uniquement au jeu et aux tournois. Pour corriger ou supprimer ton compte, contacte le support depuis ce menu.';

  var K = { theme: 'evo_theme', note: 'evo_note', vib: 'evo_vib', son: 'evo_son', taille: 'evo_taille', calme: 'evo_calme', eco: 'evo_eco', flou: 'evo_flou', fond: 'evo_fond' };
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }

  function hexToRgb(h) { var n = parseInt(h.replace('#', ''), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgbToHex(a) { return '#' + a.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); }
  function lire() { var t = lsGet(K.theme, 'vert'); return THEMES[t] ? t : 'vert'; }

  function appliquer(id, sauver) {
    var t = THEMES[id] || THEMES.vert, s = document.documentElement.style;
    s.setProperty('--c1', t.c1); s.setProperty('--c1-rgb', hexToRgb(t.c1).join(','));
    s.setProperty('--c2', t.c2); s.setProperty('--c2-rgb', hexToRgb(t.c2).join(','));
    s.setProperty('--bg', rgbToHex(t.bg)); s.setProperty('--bg-rgb', t.bg.join(','));
    s.setProperty('--card-rgb', t.card.join(','));
    document.documentElement.setAttribute('data-theme', id);
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t.c1);
    if (sauver) lsSet(K.theme, id);
    var o = document.querySelectorAll('.evo-theme-opt[data-id]');
    for (var i = 0; i < o.length; i++) o[i].classList.toggle('actif', o[i].getAttribute('data-id') === id);
    try { window.dispatchEvent(new CustomEvent('evo-theme-change', { detail: id })); } catch (e) {}
  }
  function appliquerTaille() {
    var t = lsGet(K.taille, 'normal');
    document.documentElement.style.fontSize = t === 'petit' ? '14px' : t === 'grand' ? '18px' : '';
  }
  function appliquerCalme() { document.documentElement.classList.toggle('evo-calme', lsGet(K.calme, '0') === '1'); }
  appliquer(lire(), false); appliquerTaille(); appliquerCalme(); // avant affichage : pas de clignotement

  // ---- Installation de l'app ----
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); window.__evoInstall = e; });

  // ---- Vibration + son au toucher (réglables) ----
  var audioCtx = null;
  function bip() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      var o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.04;
      o.connect(g); g.connect(audioCtx.destination); o.start(); o.stop(audioCtx.currentTime + 0.05);
    } catch (e) {}
  }
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('button,a,.btn,[onclick],.evo-row') : null;
    if (!t) return;
    if (lsGet(K.vib, '1') === '1' && navigator.vibrate) { try { navigator.vibrate(10); } catch (x) {} }
    if (lsGet(K.son, '0') === '1') bip();
  }, true);

  function toast(msg) {
    var d = document.createElement('div');
    d.textContent = msg;
    d.style.cssText = 'position:fixed;left:50%;bottom:130px;transform:translateX(-50%);z-index:2147482000;background:rgba(var(--bg-rgb,5,5,16),.97);color:#fff;border:1px solid var(--c1,#00ff88);padding:10px 16px;border-radius:12px;font-size:.8rem;font-weight:700;max-width:86%;text-align:center';
    document.body.appendChild(d); setTimeout(function () { d.remove(); }, 3200);
  }
  function numeroSupport() { try { return WHATSAPP_CEO; } catch (e) { return ''; } }
  function ouvrirWhatsApp(texte) {
    var n = numeroSupport();
    window.open('https://wa.me/' + (n || '') + '?text=' + encodeURIComponent(texte), '_blank');
  }
  function connecte() { try { return (typeof userConnecte !== 'undefined' && userConnecte) ? userConnecte : null; } catch (e) { return null; } }

  function partager() {
    var texte = '🎮 Rejoins-moi sur ' + NOM_SITE + ' : tournois e-sport, classements et clans !';
    if (navigator.share) { navigator.share({ title: NOM_SITE, text: texte, url: LIEN_SITE }).catch(function () {}); return; }
    var tout = texte + ' ' + LIEN_SITE;
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(tout).then(function () { toast('🔗 Lien copié !'); }, function () { window.open('https://wa.me/?text=' + encodeURIComponent(tout), '_blank'); });
    else window.open('https://wa.me/?text=' + encodeURIComponent(tout), '_blank');
  }
  function envoyerNote(n) {
    lsSet(K.note, String(n));
    if (LIEN_NOTER && n >= 4) { window.open(LIEN_NOTER, '_blank'); return; }
    if (numeroSupport()) ouvrirWhatsApp('⭐ Ma note pour ' + NOM_SITE + ' : ' + n + '/5');
    else toast('Merci pour ta note ' + n + '/5 ⭐');
  }

  // ---- Autorisations ----
  var PERMS = [
    { id: 'notif', nom: 'Notifications', ic: '🔔', api: 'notifications' },
    { id: 'cam', nom: 'Caméra', ic: '📷', api: 'camera' },
    { id: 'mic', nom: 'Micro', ic: '🎤', api: 'microphone' }
  ];
  function libelleEtat(e) { return e === 'granted' ? '✅ Autorisé' : e === 'denied' ? '⛔ Refusé' : e === 'unsupported' ? 'Non disponible' : 'À autoriser'; }
  function lireEtat(p) {
    return new Promise(function (res) {
      if (p.id === 'notif' && !('Notification' in window)) return res('unsupported');
      if (p.id === 'notif' && Notification.permission !== 'default') return res(Notification.permission);
      if (!navigator.permissions || !navigator.permissions.query) return res(p.id === 'notif' ? 'prompt' : 'prompt');
      navigator.permissions.query({ name: p.api }).then(function (r) { res(r.state); }, function () { res('prompt'); });
    });
  }
  function majPermissions() {
    PERMS.forEach(function (p) {
      lireEtat(p).then(function (etat) {
        var el = document.getElementById('evoPerm_' + p.id);
        if (el) { el.textContent = libelleEtat(etat); el.className = 'st ' + (etat === 'granted' ? 'ok' : etat === 'denied' ? 'ko' : ''); }
      });
    });
  }
  function demanderPermission(id) {
    if (id === 'notif') {
      if (!('Notification' in window)) return toast('Notifications non disponibles sur cet appareil');
      Notification.requestPermission().then(function (r) {
        majPermissions();
        if (r === 'granted') { try { new Notification(NOM_SITE, { body: '🔔 Notifications activées', icon: 'icons/icon-192.png' }); } catch (e) {} toast('🔔 Notifications autorisées'); }
        else toast('Notifications refusées — change-les dans les réglages du téléphone');
      });
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return toast('Non disponible sur cet appareil');
    var contraintes = id === 'cam' ? { video: true } : { audio: true };
    navigator.mediaDevices.getUserMedia(contraintes).then(function (s) {
      s.getTracks().forEach(function (t) { t.stop(); }); majPermissions(); toast('✅ Autorisation accordée');
    }).catch(function () { majPermissions(); toast('Refusée — change-la dans les réglages du téléphone'); });
  }

  function viderCache(recharger) {
    var taches = [];
    try { if (window.caches && caches.keys) taches.push(caches.keys().then(function (ks) { return Promise.all(ks.map(function (k) { return caches.delete(k); })); })); } catch (e) {}
    try { if (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) taches.push(navigator.serviceWorker.getRegistrations().then(function (rs) { return Promise.all(rs.map(function (r) { return r.unregister(); })); })); } catch (e) {}
    Promise.all(taches).then(function () { if (recharger) location.reload(); else toast('🧹 Cache vidé'); }, function () { if (recharger) location.reload(); });
  }

  function construireUI() {
    if (document.getElementById('evoSetBtn')) return;
    var css = document.createElement('style');
    css.textContent =
      'html.evo-calme body *{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}' +
      '#evoSetBtn{position:fixed;left:14px;bottom:92px;z-index:9990;width:44px;height:44px;border-radius:50%;border:2px solid var(--c1,#00ff88);background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;font-size:1.25rem;cursor:pointer;box-shadow:0 0 16px rgba(var(--c1-rgb,0,255,136),.55);display:flex;align-items:center;justify-content:center;padding:0}' +
      '#evoSetOverlay{position:fixed;inset:0;z-index:10010;background:rgba(0,0,0,.62);display:none;align-items:flex-end;justify-content:center}' +
      '#evoSetOverlay.open{display:flex}' +
      '#evoSetSheet{width:100%;max-width:520px;height:92vh;overflow-y:auto;overscroll-behavior:contain;background:rgba(var(--bg-rgb,5,5,16),.99);border:1px solid rgba(var(--c1-rgb,0,255,136),.45);border-bottom:none;border-radius:20px 20px 0 0;padding:0 14px 34px;color:#e0f2fe;font-family:inherit;box-sizing:border-box}' +
      '.evo-head{position:sticky;top:0;z-index:2;background:rgba(var(--bg-rgb,5,5,16),.99);padding:14px 2px 10px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,.06)}' +
      '.evo-head h3{margin:0;font-size:1rem;color:var(--c1,#00ff88);letter-spacing:.6px}' +
      '.evo-head .who{font-size:.68rem;color:#9ca3af;margin-top:2px}' +
      '.evo-x{background:none;border:none;color:#9ca3af;font-size:1.4rem;cursor:pointer;padding:4px 8px}' +
      '.evo-sec{font-size:.66rem;font-weight:800;color:var(--c1,#00ff88);letter-spacing:1.2px;margin:20px 2px 8px}' +
      '.evo-themes{display:grid;grid-template-columns:1fr 1fr;gap:8px}' +
      '.evo-theme-opt{display:flex;align-items:center;gap:8px;padding:9px;background:rgba(255,255,255,.04);border:1px solid transparent;border-radius:12px;color:#e0f2fe;font-size:.76rem;font-weight:700;cursor:pointer;font-family:inherit}' +
      '.evo-theme-opt.actif{border-color:var(--c1,#00ff88);background:rgba(var(--c1-rgb,0,255,136),.14)}' +
      '.evo-theme-opt .pastille{width:24px;height:24px;border-radius:50%;flex-shrink:0}' +
      '.evo-row{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;padding:13px 12px;margin:4px 0;background:rgba(255,255,255,.04);border:none;border-radius:12px;color:#e0f2fe;font-size:.85rem;font-weight:600;cursor:pointer;text-align:left;font-family:inherit}' +
      '.evo-row:active{background:rgba(var(--c1-rgb,0,255,136),.14)}' +
      '.evo-row .ic{font-size:1.15rem;width:26px;text-align:center;flex-shrink:0}' +
      '.evo-row .lb{flex:1}' +
      '.evo-row .lb small{display:block;font-size:.65rem;font-weight:500;color:#9ca3af;margin-top:2px}' +
      '.evo-row .st{font-size:.68rem;font-weight:700;color:#fbbf24}.evo-row .st.ok{color:#22c55e}.evo-row .st.ko{color:#ef4444}' +
      '.evo-row .chev{color:#6b7280;font-size:1rem}' +
      '.sw{width:42px;height:24px;border-radius:24px;background:#374151;position:relative;flex-shrink:0;transition:background .2s}' +
      '.sw::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;transition:left .2s}' +
      '.sw.on{background:var(--c1,#00ff88)}.sw.on::after{left:21px}' +
      '.evo-seg{display:flex;gap:6px;margin:4px 0}' +
      '.evo-seg button{flex:1;padding:10px 4px;border-radius:10px;border:1px solid transparent;background:rgba(255,255,255,.04);color:#e0f2fe;font-weight:700;font-size:.78rem;cursor:pointer;font-family:inherit}' +
      '.evo-seg button.actif{border-color:var(--c1,#00ff88);background:rgba(var(--c1-rgb,0,255,136),.14)}' +
      '.evo-stars{display:flex;justify-content:center;gap:8px;padding:6px 0 2px}' +
      '.evo-stars button{background:none;border:none;font-size:1.9rem;cursor:pointer;color:#4b5563;padding:0}' +
      '.evo-stars button.on{color:#fbbf24}' +
      '.evo-box{font-size:.78rem;line-height:1.6;color:#cbd5e1;background:rgba(255,255,255,.04);border-radius:12px;padding:12px;margin:4px 0;display:none}' +
      '.evo-box input{width:100%;box-sizing:border-box;padding:10px;margin:4px 0;border-radius:8px;border:1px solid rgba(var(--c1-rgb,0,255,136),.3);background:rgba(var(--bg-rgb,5,5,16),.9);color:#e0f2fe;font-size:16px}' +
      '.evo-box .go{width:100%;margin-top:6px;padding:11px;border:none;border-radius:10px;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;font-weight:800;cursor:pointer;font-family:inherit}' +
      '.evo-danger{color:#f87171}' +
      '.evo-ver{text-align:center;font-size:.65rem;color:#6b7280;margin-top:18px}';
    document.head.appendChild(css);

    var btn = document.createElement('button');
    btn.id = 'evoSetBtn'; btn.type = 'button'; btn.setAttribute('aria-label', 'Paramètres du site'); btn.textContent = '⚙️';

    function row(id, ic, lb, sub, extra) { return '<button type="button" class="evo-row" id="' + id + '"><span class="ic">' + ic + '</span><span class="lb">' + lb + (sub ? '<small>' + sub + '</small>' : '') + '</span>' + (extra || '<span class="chev">›</span>') + '</button>'; }
    function tog(key, ic, lb, sub) { return '<div class="evo-row" role="switch" data-tog="' + key + '" style="cursor:pointer"><span class="ic">' + ic + '</span><span class="lb">' + lb + (sub ? '<small>' + sub + '</small>' : '') + '</span><span class="sw" id="sw_' + key + '"></span></div>'; }

    var ov = document.createElement('div');
    ov.id = 'evoSetOverlay';
    document.body.appendChild(btn); document.body.appendChild(ov);

    function contenu() {
      var u = connecte();
      var h = '<div id="evoSetSheet"><div class="evo-head"><div><h3>⚙️ PARAMÈTRES</h3>' + (u && u.Psuedo ? '<div class="who">Connecté : ' + String(u.Psuedo).replace(/[<>&]/g, '') + '</div>' : '') + '</div><button type="button" class="evo-x" id="evoSetX">✕</button></div>';

      if (u) {
        h += '<div class="evo-sec">👤 COMPTE</div>' +
          row('evoProfil', '🙍', 'Mon profil', 'Voir et modifier mes infos') +
          row('evoPassBtn', '🔑', 'Changer mon mot de passe') +
          '<div class="evo-box" id="evoPassBox"><input type="password" id="evoPassOld" placeholder="Mot de passe actuel" autocomplete="current-password"><input type="password" id="evoPassNew" placeholder="Nouveau mot de passe (8 caractères min)" autocomplete="new-password"><button type="button" class="go" id="evoPassGo">Enregistrer</button></div>' +
          row('evoNoAds', '🔕', 'Retirer les pubs', '1 000 FCFA / mois') +
          row('evoLogout', '🚪', 'Se déconnecter');
      }

      h += '<div class="evo-sec">🎨 APPARENCE</div><div class="evo-themes">';
      Object.keys(THEMES).forEach(function (id) {
        var t = THEMES[id];
        h += '<button type="button" class="evo-theme-opt" data-id="' + id + '"><span class="pastille" style="background:linear-gradient(135deg,' + t.c1 + ',' + t.c2 + ')"></span>' + t.nom + '</button>';
      });
      h += '</div><div class="evo-sec" style="margin-top:14px">🌸 FOND ANIMÉ EN DIRECT</div><div class="evo-themes" id="evoFonds">';
      if (window.EvoFonds) { var fa = window.EvoFonds.choixJoueur() || window.EvoFonds.actuel(); Object.keys(window.EvoFonds.liste).forEach(function (id) { var f = window.EvoFonds.liste[id]; h += '<button type="button" class="evo-theme-opt' + (fa === id ? ' actif' : '') + '" data-fond="' + id + '"><span class="pastille" style="background:none;font-size:1rem">' + f.ico + '</span>' + f.nom + '</button>'; }); }
      h += '</div><div class="evo-sec" style="margin-top:14px">TAILLE DU TEXTE</div><div class="evo-seg" id="evoTaille"><button type="button" data-t="petit">Petit</button><button type="button" data-t="normal">Normal</button><button type="button" data-t="grand">Grand</button></div>' +
        tog('calme', '🐢', 'Animations réduites', 'Moins de mouvement, plus fluide sur les vieux téléphones') +
        tog('eco', '📶', 'Économie de données', 'Vidéos non lancées d\'avance, moins de données mobiles') +
        tog('flou', '⚡', 'Sans effets de flou', 'Plus rapide sur les téléphones lents') +
        tog('fond', '🔄', 'Actualiser en arrière-plan', 'Sinon tout est mis en pause quand l\'app est cachée') +
        row('evoVitesse', '⚡', 'Vitesse de chargement', (window.EvoSpeed ? window.EvoSpeed.resume() : '')) +
        row('evoLog', '🧾', 'Journal d\'erreurs', 'Copie les dernières erreurs pour me les envoyer') +
        row('evoIntro', '🎬', 'Revoir l\'intro', 'Rejoue le logo de 6 secondes');

      h += '<div class="evo-sec">🔊 SONS & VIBRATIONS</div>' +
        tog('vib', '📳', 'Vibrations au toucher', 'Un petit retour quand tu appuies') +
        tog('son', '🔈', 'Sons au toucher', 'Un petit « clic » sonore');

      h += '<div class="evo-sec">🔐 AUTORISATIONS</div>';
      PERMS.forEach(function (p) { h += row('evoP_' + p.id, p.ic, p.nom, '', '<span class="st" id="evoPerm_' + p.id + '">…</span>'); });
      h += '<div style="font-size:.65rem;color:#6b7280;margin:4px 4px 0">Pour retirer une autorisation : réglages du téléphone → Applications → EVO ARENA. Les notifications de messages quand l\'app est fermée arriveront dans une prochaine version.</div>';

      h += '<div class="evo-sec">💾 DONNÉES & STOCKAGE</div>' +
        row('evoCache', '🧹', 'Vider le cache', 'Libère de la place, ne te déconnecte pas') +
        row('evoMaj', '🔄', 'Vérifier les mises à jour', 'Recharge la dernière version du site') +
        row('evoReset', '♻️', 'Réinitialiser les réglages', 'Thème, texte, sons… remis par défaut');

      h += '<div class="evo-sec">📱 APPLICATION</div>' +
        row('evoInstall', '📲', 'Installer l\'application', 'Ajoute EVO ARENA à ton écran d\'accueil') +
        row('evoShare', '📤', 'Partager le site', 'Invite tes amis');

      h += '<div class="evo-sec">⭐ NOTER LE SITE</div><div class="evo-stars" id="evoStars">';
      for (var i = 1; i <= 5; i++) h += '<button type="button" data-n="' + i + '">★</button>';
      h += '</div>';

      h += '<div class="evo-sec">💬 AIDE</div>' +
        row('evoSupport', '🛟', 'Contacter le support', 'WhatsApp') +
        row('evoBug', '🐞', 'Signaler un problème') +
        row('evoPriv', '🔒', 'Confidentialité') +
        '<div class="evo-box" id="evoPrivBox">' + CONFIDENTIALITE + '</div>' +
        row('evoDel', '🗑️', 'Demander la suppression de mon compte', 'Le support s\'en occupe') ;

      h += '<div class="evo-sec">👑 À PROPOS</div>' +
        row('evoCred', '👑', 'Crédits du site') +
        '<div class="evo-box" id="evoCredBox">' + CREDITS.join('<br>') + '</div>' +
        '<div class="evo-ver">' + NOM_SITE + ' • version ' + VERSION + '</div></div>';
      return h;
    }

    function majSwitchs() {
      var etats = { vib: lsGet(K.vib, '1') === '1', son: lsGet(K.son, '0') === '1', calme: lsGet(K.calme, '0') === '1', eco: lsGet(K.eco, '0') === '1', flou: lsGet(K.flou, '0') === '1', fond: lsGet(K.fond, '0') === '1' };
      Object.keys(etats).forEach(function (k) { var e = document.getElementById('sw_' + k); if (e) e.classList.toggle('on', etats[k]); });
      var t = lsGet(K.taille, 'normal'), b = ov.querySelectorAll('#evoTaille button');
      for (var i = 0; i < b.length; i++) b[i].classList.toggle('actif', b[i].getAttribute('data-t') === t);
    }
    function majEtoiles(n) { var b = ov.querySelectorAll('#evoStars button'); for (var k = 0; k < b.length; k++) b[k].classList.toggle('on', k < n); }
    function ouvrir() {
      ov.innerHTML = contenu(); ov.classList.add('open');
      appliquer(lire(), false); majSwitchs(); majPermissions();
      majEtoiles(parseInt(lsGet(K.note, '0'), 10) || 0);
    }
    function fermer() { ov.classList.remove('open'); }
    function bascule(id) { var e = document.getElementById(id); if (e) e.style.display = e.style.display === 'block' ? 'none' : 'block'; }

    btn.addEventListener('click', function (e) { e.stopPropagation(); ouvrir(); });
    ov.addEventListener('click', function (e) {
      var t = e.target;
      if (t === ov || t.id === 'evoSetX') return fermer();
      var c = t.closest ? t.closest.bind(t) : null; if (!c) return;
      var fo = c('[data-fond]'); if (fo && window.EvoFonds) { window.EvoFonds.definir(fo.getAttribute('data-fond')); var bs = ov.querySelectorAll('[data-fond]'); for (var q = 0; q < bs.length; q++) bs[q].classList.toggle('actif', bs[q] === fo); return; }
      var o = c('.evo-theme-opt'); if (o) { appliquer(o.getAttribute('data-id'), true); return; }
      var tg = c('[data-tog]');
      if (tg) { var k = tg.getAttribute('data-tog'), nv = lsGet(K[k], k === 'vib' ? '1' : '0') === '1' ? '0' : '1'; lsSet(K[k], nv); if (k === 'calme') appliquerCalme(); if (window.evoPerf) window.evoPerf.appliquer(); if (k === 'vib' && nv === '1' && navigator.vibrate) navigator.vibrate(30); if (k === 'son' && nv === '1') bip(); majSwitchs(); return; }
      var tl = c('#evoTaille button'); if (tl) { lsSet(K.taille, tl.getAttribute('data-t')); appliquerTaille(); majSwitchs(); return; }
      var s = c('#evoStars button'); if (s) { var n = parseInt(s.getAttribute('data-n'), 10); majEtoiles(n); envoyerNote(n); return; }
      var r = c('.evo-row, .go'); if (!r) return;
      switch (r.id) {
        case 'evoProfil': location.href = 'profil.html'; break;
        case 'evoPassBtn': bascule('evoPassBox'); break;
        case 'evoPassGo': {
          var o1 = document.getElementById('evoPassOld').value, n1 = document.getElementById('evoPassNew').value;
          if (!o1 || n1.length < 8) { toast('⚠️ Mot de passe : 8 caractères minimum'); break; }
          EvoAuth.changePassword(n1, o1).then(function () { toast('✅ Mot de passe changé'); bascule('evoPassBox'); }, function (er) { toast('❌ ' + (er && er.message ? er.message : 'Erreur')); });
          break; }
        case 'evoNoAds': fermer(); location.href = 'profil.html'; break;
        case 'evoLogout': if (confirm('Te déconnecter ?')) { Promise.resolve().then(function () { return EvoAuth.signOut(); }).catch(function () {}).then(function () { location.href = 'index.html'; }); } break;
        case 'evoVitesse': try { var vl = JSON.parse(localStorage.getItem('evo_vitesse') || '[]').slice(-6).map(function (x) { return x.page + ' : affichage ' + x.fcp + ' ms, prête ' + x.dcl + ' ms' + (x.sw ? ' (cache)' : ''); }).join('\n') || 'Pas encore de mesure'; alert(vl); } catch (x) {} break;
        case 'evoLog': try { var tx = (window.evoPerf ? window.evoPerf.log() : []).map(function (x) { return x.t + ' [' + x.p + '] ' + x.m; }).join('\n') || 'Aucune erreur enregistrée'; if (navigator.clipboard) navigator.clipboard.writeText(tx); alert(tx.slice(0, 600)); } catch (x) {} break;
        case 'evoIntro': try { sessionStorage.removeItem('evo_splash'); } catch (x) {} location.reload(); break;
        case 'evoP_notif': demanderPermission('notif'); break;
        case 'evoP_cam': demanderPermission('cam'); break;
        case 'evoP_mic': demanderPermission('mic'); break;
        case 'evoCache': viderCache(false); break;
        case 'evoMaj': viderCache(true); break;
        case 'evoReset': if (confirm('Remettre tous les réglages par défaut ?')) { [K.theme, K.note, K.vib, K.son, K.taille, K.calme, 'evo_fond_anime'].forEach(lsDel); if (window.EvoFonds) window.EvoFonds.restaurer(); appliquer('vert', false); appliquerTaille(); appliquerCalme(); ouvrir(); toast('♻️ Réglages réinitialisés'); } break;
        case 'evoInstall':
          if (window.__evoInstall) { window.__evoInstall.prompt(); window.__evoInstall = null; }
          else if ((window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone) toast('✅ L\'app est déjà installée');
          else toast('Menu ⋮ du navigateur → « Ajouter à l\'écran d\'accueil »');
          break;
        case 'evoShare': partager(); break;
        case 'evoSupport': ouvrirWhatsApp('Bonjour, j\'ai besoin d\'aide sur ' + NOM_SITE + '.'); break;
        case 'evoBug': { var uu = connecte(); ouvrirWhatsApp('🐞 Problème sur ' + NOM_SITE + ' v' + VERSION + '\nPage : ' + location.pathname + '\nJoueur : ' + (uu && uu.Psuedo ? uu.Psuedo : 'non connecté') + '\nAppareil : ' + navigator.userAgent.slice(0, 90) + '\n\nDécris le problème :'); break; }
        case 'evoPriv': bascule('evoPrivBox'); break;
        case 'evoDel': { var u2 = connecte(); if (confirm('Envoyer une demande de suppression de ton compte au support ?')) ouvrirWhatsApp('Bonjour, je demande la suppression de mon compte ' + NOM_SITE + (u2 && u2.Psuedo ? ' (pseudo : ' + u2.Psuedo + ')' : '') + '.'); break; }
        case 'evoCred': bascule('evoCredBox'); break;
      }
    });
    appliquer(lire(), false);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', construireUI);
  else construireUI();

  window.EVO_THEMES = THEMES;
  window.appliquerThemeEvo = function (id) { appliquer(id, true); };
})();

// ============================================================
// ANIMATION WAVE — barre de navigation (toutes les pages) + cartes de tournoi (admin)
// Désactivée automatiquement par le mode « animations réduites » des paramètres (html.evo-calme).
// ============================================================
(function () {
  var W = "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 28' preserveAspectRatio='none'><path d='M0 14Q50 0 100 14T200 14V28H0Z' fill='black'/></svg>\")";
  var css =
    '.bottom-nav{overflow:visible;isolation:isolate}' +
    '.bottom-nav>*{position:relative;z-index:3}' +
    '.bottom-nav::before,.bottom-nav::after{content:"";position:absolute;left:0;right:0;bottom:0;pointer-events:none;z-index:1;border-radius:0 0 21px 21px;' +
      '-webkit-mask-repeat:repeat-x;mask-repeat:repeat-x;will-change:mask-position,-webkit-mask-position}' +
    '.bottom-nav::before{height:24px;background:linear-gradient(to top,rgba(var(--c2-rgb,124,58,237),.38),rgba(var(--c2-rgb,124,58,237),.04));' +
      '-webkit-mask-image:' + W + ';mask-image:' + W + ';-webkit-mask-size:260px 24px;mask-size:260px 24px;animation:evoWaveA 7s linear infinite}' +
    '.bottom-nav::after{height:16px;background:linear-gradient(to top,rgba(var(--c1-rgb,0,255,136),.4),rgba(var(--c1-rgb,0,255,136),.04));' +
      '-webkit-mask-image:' + W + ';mask-image:' + W + ';-webkit-mask-size:180px 16px;mask-size:180px 16px;animation:evoWaveB 4.5s linear infinite}' +
    '@keyframes evoWaveA{from{-webkit-mask-position:0 0;mask-position:0 0}to{-webkit-mask-position:260px 0;mask-position:260px 0}}' +
    '@keyframes evoWaveB{from{-webkit-mask-position:0 0;mask-position:0 0}to{-webkit-mask-position:-180px 0;mask-position:-180px 0}}' +
    // bulle qui « gonfle » sur l'onglet actif et glisse vers le nouvel onglet
    '.nav-btn.active{background:transparent!important}' +
    '.nav-btn.active .icon{transform:translateY(-13px) scale(1.25)!important;filter:drop-shadow(0 2px 3px rgba(0,0,0,.35))}' +
    '.nav-btn .icon{transition:transform .35s cubic-bezier(.34,1.56,.64,1)}' +
    '.bottom-nav>.evo-bubble{position:absolute;top:-20px;left:0;width:46px;height:46px;margin-left:-23px;border-radius:50%;z-index:2;pointer-events:none;' +
      'background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));border:4px solid var(--bg,#050510);box-shadow:0 0 18px rgba(var(--c1-rgb,0,255,136),.45);' +
      'transition:left .5s cubic-bezier(.34,1.56,.64,1)}' +
    '.bottom-nav>.evo-bubble.pop{animation:evoPop .55s cubic-bezier(.34,1.56,.64,1)}' +
    '@keyframes evoPop{0%{transform:scale(.2)}100%{transform:scale(1)}}' +
    // cartes de tournoi (admin)
    '.tournoi-item{position:relative;overflow:hidden;isolation:isolate}' +
    '.tournoi-item>*{position:relative;z-index:2}' +
    '.tournoi-item::before,.tournoi-item::after{content:"";position:absolute;left:0;right:0;bottom:0;pointer-events:none;z-index:1;' +
      '-webkit-mask-repeat:repeat-x;mask-repeat:repeat-x}' +
    '.tournoi-item::before{height:26px;background:linear-gradient(to top,rgba(251,191,36,.30),rgba(251,191,36,.03));' +
      '-webkit-mask-image:' + W + ';mask-image:' + W + ';-webkit-mask-size:240px 26px;mask-size:240px 26px;animation:evoWaveA 6s linear infinite}' +
    '.tournoi-item::after{height:18px;background:linear-gradient(to top,rgba(var(--c1-rgb,0,255,136),.35),rgba(var(--c1-rgb,0,255,136),.03));' +
      '-webkit-mask-image:' + W + ';mask-image:' + W + ';-webkit-mask-size:160px 18px;mask-size:160px 18px;animation:evoWaveB 4s linear infinite}';
  var s = document.createElement('style');
  s.id = 'evoWaveCss';
  s.textContent = css;
  (document.head || document.documentElement).appendChild(s);

  function bulle() {
    var nav = document.querySelector('.bottom-nav');
    if (!nav || nav.querySelector('.evo-bubble')) return;
    var btns = [].slice.call(nav.querySelectorAll('.nav-btn'));
    var idx = -1;
    btns.forEach(function (b, i) { if (idx < 0 && b.classList.contains('active')) idx = i; });
    if (idx < 0) return;
    var b = document.createElement('div');
    b.className = 'evo-bubble';
    nav.appendChild(b);
    function cx(i) { var r = btns[i].getBoundingClientRect(), n = nav.getBoundingClientRect(); return r.left - n.left - 1 + r.width / 2; }
    var prev = -1;
    try { prev = parseInt(sessionStorage.getItem('evoNavPrev'), 10); } catch (e) {}
    if (isNaN(prev) || prev < 0 || prev >= btns.length || prev === idx) {
      b.style.left = cx(idx) + 'px'; b.classList.add('pop');
    } else {
      b.style.left = cx(prev) + 'px';
      void b.offsetWidth;
      requestAnimationFrame(function () { requestAnimationFrame(function () { b.style.left = cx(idx) + 'px'; }); });
    }
    try { sessionStorage.setItem('evoNavPrev', String(idx)); } catch (e) {}
    window.addEventListener('resize', function () { b.style.transition = 'none'; b.style.left = cx(idx) + 'px'; });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bulle); else bulle();
})();
