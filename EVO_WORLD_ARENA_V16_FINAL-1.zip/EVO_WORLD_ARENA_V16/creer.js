/* EVO ARENA — studio de création façon TikTok (v14i)
 * Parcours : Caméra (60 s / 15 s / Photo / Texte, minuteur, flash, filtres, « Ajouter un son »)
 *          → Galerie (Tous / Vidéos / Photos, sélection multiple)
 *          → Montage (rogner, filtres, texte déplaçable, volume, plusieurs clips, musique)
 *          → Publier (description, #hashtags, couverture, visibilité, commentaires, Publication ou Story, brouillons)
 * Le montage est réellement « cuit » dans la vidéo (filtre + texte + musique + découpe) directement dans le téléphone.
 * Ouverture : EvoCreer.open() ou {mode:'story'}.  Les sons viennent de la collection Firestore « sons » + 8 sons intégrés.
 */
(function () {
  'use strict';
  if (window.EvoCreer) return;
  var W = window, D = document;
  var NAT = W.EvoNative || { pushOverlay: function () { return function () {}; }, haptic: function () {} };
  var PERM = W.EvoPerm || { ensure: async function () { return true; }, status: async function () { return 'granted'; } };

  /* ---------------- utilitaires ---------------- */
  function $(s, r) { return (r || D).querySelector(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(s) { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function toast(m, t) { if (W.showToast) W.showToast(m, t || 'info'); else alert(m); }
  function attendre(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function choisirMime() {
    if (!W.MediaRecorder) return '';
    var l = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    for (var i = 0; i < l.length; i++) { try { if (MediaRecorder.isTypeSupported(l[i])) return l[i]; } catch (e) {} }
    return '';
  }
  function extMime(m) { return /mp4/.test(m) ? 'mp4' : 'webm'; }
  function chercher(v, t) { return new Promise(function (ok) { var d = function () { v.removeEventListener('seeked', d); ok(); }; v.addEventListener('seeked', d); v.currentTime = t; setTimeout(ok, 1500); }); }
  function chargerVideo(url) {
    return new Promise(function (ok, ko) {
      var v = D.createElement('video'); v.preload = 'auto'; v.playsInline = true; v.setAttribute('playsinline', ''); v.src = url;
      v.onerror = function () { ko(new Error('Vidéo illisible')); };
      v.onloadedmetadata = function () {
        if (v.duration === Infinity || isNaN(v.duration)) { v.ontimeupdate = function () { v.ontimeupdate = null; v.currentTime = 0; ok(v); }; v.currentTime = 1e101; }
        else ok(v);
      };
    });
  }
  function chargerImage(url) { return new Promise(function (ok, ko) { var i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { ko(new Error('Image illisible')); }; i.src = url; }); }

  var FILTRES = [
    { n: 'Normal', c: 'none' }, { n: 'Néon', c: 'saturate(1.6) contrast(1.1) hue-rotate(-12deg)' },
    { n: 'Arena', c: 'contrast(1.25) saturate(1.3) brightness(.95)' }, { n: 'Cyber', c: 'hue-rotate(60deg) saturate(1.5)' },
    { n: 'Chaud', c: 'sepia(.35) saturate(1.4)' }, { n: 'Froid', c: 'hue-rotate(180deg) saturate(.9) brightness(1.05)' },
    { n: 'N&B', c: 'grayscale(1) contrast(1.15)' }, { n: 'Vintage', c: 'sepia(.6) contrast(.9) brightness(1.05)' }
  ];
  var COULEURS = ['#ffffff', '#00ff88', '#7c3aed', '#f59e0b', '#ef4444', '#22d3ee', '#000000'];
  var TAGS = ['#EVOARENA', '#FreeFire', '#PUBGMobile', '#CODM', '#Cameroun', '#Esport', '#Clutch', '#Gaming'];
  var FONDS_TEXTE = [['#00ff88', '#7c3aed'], ['#f59e0b', '#ef4444'], ['#22d3ee', '#6366f1'], ['#f43f5e', '#7c3aed'], ['#16a34a', '#0f172a']];

  /* ---------------- sons intégrés (générés dans le téléphone, libres de droits) ---------------- */
  var RECETTES = [
    { id: 'g_arena', t: 'Arena Rush', bpm: 140, r: 45, g: [0, 3, 5, 7, 10], s: 'trap', c: ['#00ff88', '#7c3aed'], e: '⚡' },
    { id: 'g_yde', t: 'Yaoundé Nights', bpm: 104, r: 48, g: [0, 2, 4, 7, 9], s: 'afro', c: ['#f59e0b', '#ef4444'], e: '🌙' },
    { id: 'g_clutch', t: 'Clutch Time', bpm: 130, r: 43, g: [0, 1, 5, 7, 8], s: 'phonk', c: ['#ef4444', '#111827'], e: '🔥' },
    { id: 'g_victory', t: 'Victory Lap', bpm: 124, r: 50, g: [0, 2, 4, 5, 7, 9, 11], s: 'house', c: ['#22d3ee', '#6366f1'], e: '🏆' },
    { id: 'g_momo', t: 'Mobile Money', bpm: 112, r: 46, g: [0, 3, 5, 7, 10], s: 'amapiano', c: ['#a3e635', '#16a34a'], e: '💸' },
    { id: 'g_zone', t: 'Last Zone', bpm: 90, r: 41, g: [0, 2, 3, 7, 8], s: 'cine', c: ['#8b5cf6', '#0f172a'], e: '🎯' },
    { id: 'g_boss', t: 'Boss Fight', bpm: 150, r: 52, g: [0, 4, 7, 12], s: 'chip', c: ['#f43f5e', '#7c3aed'], e: '👾' },
    { id: 'g_chill', t: 'Chill Lobby', bpm: 80, r: 45, g: [0, 3, 7, 10, 14], s: 'lofi', c: ['#38bdf8', '#a78bfa'], e: '☕' }
  ];
  var ONDE = { trap: 'sawtooth', afro: 'sine', phonk: 'sawtooth', house: 'square', amapiano: 'triangle', cine: 'sawtooth', chip: 'square', lofi: 'triangle' };
  var CACHE_SON = {};
  function coverSvg(c, e) {
    return 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + c[0] + '"/><stop offset="1" stop-color="' + c[1] + '"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><text x="50" y="64" font-size="44" text-anchor="middle">' + e + '</text></svg>');
  }
  function wav(buf) {
    var d = buf.getChannelData(0), n = d.length, sr = buf.sampleRate, o = new DataView(new ArrayBuffer(44 + n * 2));
    function s(p, t) { for (var i = 0; i < t.length; i++) o.setUint8(p + i, t.charCodeAt(i)); }
    s(0, 'RIFF'); o.setUint32(4, 36 + n * 2, true); s(8, 'WAVEfmt '); o.setUint32(16, 16, true); o.setUint16(20, 1, true); o.setUint16(22, 1, true);
    o.setUint32(24, sr, true); o.setUint32(28, sr * 2, true); o.setUint16(32, 2, true); o.setUint16(34, 16, true); s(36, 'data'); o.setUint32(40, n * 2, true);
    for (var i = 0; i < n; i++) { var v = Math.max(-1, Math.min(1, d[i])); o.setInt16(44 + i * 2, v < 0 ? v * 0x8000 : v * 0x7FFF, true); }
    return new Blob([o.buffer], { type: 'audio/wav' });
  }
  async function genererSon(r) {
    if (CACHE_SON[r.id]) return CACHE_SON[r.id];
    var sr = 22050, beat = 60 / r.bpm, bars = 8, dur = bars * 4 * beat;
    var OC = W.OfflineAudioContext || W.webkitOfflineAudioContext;
    var oc = new OC(1, Math.ceil(sr * dur), sr), master = oc.createGain(); master.gain.value = .7; master.connect(oc.destination);
    var nb = oc.createBuffer(1, sr, sr), nd = nb.getChannelData(0); for (var i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    function fq(m) { return 440 * Math.pow(2, (m - 69) / 12); }
    function note(t, m, l, type, vol) { var o = oc.createOscillator(), g = oc.createGain(); o.type = type; o.frequency.value = fq(m); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + l); o.connect(g); g.connect(master); o.start(t); o.stop(t + l + .02); }
    function kick(t) { var o = oc.createOscillator(), g = oc.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(40, t + .14); g.gain.setValueAtTime(.9, t); g.gain.exponentialRampToValueAtTime(.001, t + .25); o.connect(g); g.connect(master); o.start(t); o.stop(t + .26); }
    function bruit(t, l, vol, hp) { var s = oc.createBufferSource(); s.buffer = nb; var f = oc.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp; var g = oc.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + l); s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + l); }
    var onde = ONDE[r.s] || 'sine', G = r.g;
    for (var bar = 0; bar < bars; bar++) {
      for (var st = 0; st < 16; st++) {
        var t = (bar * 16 + st) * beat / 4;
        var k = r.s === 'house' ? st % 4 === 0 : r.s === 'trap' ? (st === 0 || st === 10 || (bar % 2 && st === 7)) : (st === 0 || st === 6 || st === 10);
        if (k) kick(t);
        if (st === 4 || st === 12) bruit(t, .12, .45, 1500);
        if (r.s === 'trap' ? (st % 2 === 0 || (st > 12 && bar % 2)) : st % 2 === 0) bruit(t, .04, .16, 7000);
        if (st === 0 || st === 3 || st === 6 || st === 10) note(t, r.r - 12 + G[(bar + st) % G.length], beat * .9, r.s === 'chip' ? 'square' : 'sine', .5);
        if (st % 2 === 0) note(t, r.r + 12 + G[(st / 2 + bar * 2) % G.length], beat * .45, onde, .1);
      }
    }
    var buf = await oc.startRendering(), url = URL.createObjectURL(wav(buf));
    CACHE_SON[r.id] = url; return url;
  }
  var SONS_FS = null;
  async function chargerSonsFirestore() {
    if (SONS_FS) return SONS_FS; SONS_FS = [];
    try {
      var res = await EvoDB.listFast('sons', [Q.limit(100)]);
      (res.documents || []).forEach(function (d) { if (d.Audio_url) SONS_FS.push({ id: 'f_' + d.id, titre: d.Titre || 'Son', artiste: d.Artiste || 'EVO ARENA', cover: d.Cover_url || coverSvg(['#7c3aed', '#00ff88'], '🎵'), url: d.Audio_url, duree: d.Duree || 0, distant: true }); });
    } catch (e) {}
    return SONS_FS;
  }
  function sonsIntegres() { return RECETTES.map(function (r) { return { id: r.id, titre: r.t, artiste: 'EVO Beats · intégré', cover: coverSvg(r.c, r.e), recette: r, duree: Math.round(8 * 4 * 60 / r.bpm) }; }); }

  /* ---------------- brouillons (IndexedDB) ---------------- */
  function idb() { return new Promise(function (ok, ko) { var r = indexedDB.open('evo_creer', 1); r.onupgradeneeded = function () { r.result.createObjectStore('drafts', { keyPath: 'id' }); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ko(r.error); }; }); }
  async function dbTous() { var db = await idb(); return new Promise(function (ok) { var q = db.transaction('drafts').objectStore('drafts').getAll(); q.onsuccess = function () { ok((q.result || []).sort(function (a, b) { return b.date - a.date; })); }; q.onerror = function () { ok([]); }; }); }
  async function dbPut(d) { var db = await idb(); return new Promise(function (ok, ko) { var t = db.transaction('drafts', 'readwrite'); t.objectStore('drafts').put(d); t.oncomplete = ok; t.onerror = function () { ko(t.error); }; }); }
  async function dbDel(id) { var db = await idb(); return new Promise(function (ok) { var t = db.transaction('drafts', 'readwrite'); t.objectStore('drafts').delete(id); t.oncomplete = ok; t.onerror = ok; }); }

  /* ---------------- état ---------------- */
  var S = null, root = null, inpMedia = null, inpAudio = null, inpCover = null, prevAudio = null, musicEl = null;
  function neuf(o) {
    return { dest: (o && o.mode === 'story') ? 'story' : 'post', clips: [], sel: 0, pool: [], selOrdre: [], multi: false, ft: 'all', filtre: 0, textes: [], music: null,
      volOrig: 1, volMusic: .8, desc: '', visib: 'tous', comm: true, covers: [], coverIdx: 0, coverBlob: null, face: 'user', stream: null, rec: null, chunks: [],
      recStart: 0, minuteur: 0, mode: '60', maxDur: 60, ecran: 'cam', stack: [], sheetOff: null, panel: '', draftId: null, enCours: false, torch: false, ring: 0 };
  }
  function dureeClip(c) { return c.type === 'video' ? Math.max(.5, c.end - c.start) : c.dur; }
  function dureeTotale() { return S.clips.reduce(function (a, c) { return a + dureeClip(c); }, 0); }
  async function getUser() {
    try { if (typeof userConnecte !== 'undefined' && userConnecte && userConnecte.id) return userConnecte; } catch (e) {}
    try { var u = await EvoAuth.currentFast(); var d = await EvoDB.getFast(COLLECTIONS.PLAYERS, u.id); return Object.assign({ id: u.id }, d); } catch (e) { return null; }
  }

  /* ---------------- CSS ---------------- */
  var CSS =
    '#evoCreer{position:fixed;inset:0;z-index:100000;background:#000;color:#fff;font-family:system-ui,-apple-system,sans-serif;display:none;overflow:hidden;-webkit-user-select:none;user-select:none}' +
    '#evoCreer *{box-sizing:border-box}#evoCreer.on{display:block}:where(#evoCreer) button{font-family:inherit;color:inherit;border:none;background:none;cursor:pointer}' +
    '#evoCreer .s{position:absolute;inset:0;display:none;background:#000}#evoCreer .s.on{display:block}' +
    '.ec-top{position:absolute;top:0;left:0;right:0;z-index:5;display:flex;align-items:center;justify-content:space-between;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 10px;background:linear-gradient(#000a,transparent)}' +
    '.ec-top.dk{background:#0a0a14;border-bottom:1px solid #ffffff12}' +
    '.ec-ib{width:40px;height:40px;border-radius:50%;background:#0008;font-size:1.1rem}' +
    '.ec-pill{background:#0009;border-radius:20px;padding:9px 16px;font-weight:700;font-size:.8rem;max-width:62vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.ec-title{font-weight:800;font-size:1rem}' +
    '.ec-next{background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000!important;font-weight:900;font-size:.85rem;border-radius:22px;padding:10px 20px}' +
    '.ec-next[disabled]{opacity:.4}' +
    '#ecCamV{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}' +
    '.ec-msg{position:absolute;left:24px;right:24px;top:38%;text-align:center;font-size:.85rem;color:#cbd5e1;line-height:1.5}' +
    '.ec-side{position:absolute;right:8px;top:calc(70px + env(safe-area-inset-top,0px));z-index:5;display:flex;flex-direction:column;gap:14px;align-items:center}' +
    '.ec-tool{display:flex;flex-direction:column;align-items:center;gap:3px;font-size:.62rem;font-weight:700;text-shadow:0 1px 4px #000;min-width:52px}' +
    '.ec-tool i{font-style:normal;font-size:1.35rem;width:42px;height:42px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:#0007}' +
    '.ec-tool.on i{background:var(--c1,#00ff88);color:#000}' +
    '.ec-bot{position:absolute;left:0;right:0;bottom:0;z-index:5;padding:0 16px calc(14px + env(safe-area-inset-bottom,0px));background:linear-gradient(transparent,#000b)}' +
    '.ec-modes{display:flex;justify-content:center;gap:22px;margin-bottom:12px;font-weight:800;font-size:.78rem}' +
    '.ec-modes button{opacity:.55;padding:4px 2px;border-bottom:2px solid transparent}.ec-modes button.on{opacity:1;border-color:#fff}' +
    '.ec-ctrl{display:flex;align-items:center;justify-content:space-between;height:92px}' +
    '.ec-imp,.ec-ok{width:68px;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:.66rem;font-weight:700}' +
    '.ec-imp span{width:44px;height:44px;border-radius:10px;background:#333 center/cover;border:2px solid #fff;display:block}' +
    '.ec-ok{visibility:hidden}.ec-ok.on{visibility:visible}' +
    '.ec-ok b{width:44px;height:44px;border-radius:50%;background:var(--c1,#00ff88);color:#000;display:flex;align-items:center;justify-content:center;font-size:1.3rem}' +
    '.ec-rec{position:relative;width:84px;height:84px}' +
    '.ec-rec svg{position:absolute;inset:0;transform:rotate(-90deg)}' +
    '.ec-rec .core{position:absolute;inset:12px;border-radius:50%;background:#ef4444;transition:.2s}' +
    '.ec-rec.rec .core{inset:26px;border-radius:8px}.ec-rec.photo .core{background:#fff}' +
    '.ec-sub{display:flex;justify-content:center;gap:18px;font-size:.72rem;font-weight:700;opacity:.9;margin-top:6px}' +
    '.ec-count{position:absolute;inset:0;z-index:6;display:none;align-items:center;justify-content:center;font-size:8rem;font-weight:900;text-shadow:0 0 30px #000;pointer-events:none}' +
    '.ec-filt{position:absolute;left:0;right:0;bottom:calc(190px + env(safe-area-inset-bottom,0px));z-index:5;display:none;gap:10px;overflow-x:auto;padding:0 14px}' +
    '.ec-filt.on{display:flex}.ec-filt button{flex:0 0 auto;text-align:center;font-size:.62rem;font-weight:700}' +
    '.ec-filt b{display:block;width:54px;height:54px;border-radius:12px;background:linear-gradient(135deg,#00ff88,#7c3aed,#f59e0b);border:2px solid transparent;margin-bottom:3px}' +
    '.ec-filt .on b{border-color:#fff}' +
    /* galerie */
    '#ec-gal{background:#0a0a14}.ec-tabs{position:absolute;top:calc(64px + env(safe-area-inset-top,0px));left:0;right:0;display:flex;gap:22px;padding:0 16px;border-bottom:1px solid #ffffff14;font-weight:800;font-size:.95rem}' +
    '.ec-tabs button{padding:10px 2px;opacity:.5;border-bottom:3px solid transparent}.ec-tabs button.on{opacity:1;border-color:#fff}' +
    '.ec-grid{position:absolute;top:calc(112px + env(safe-area-inset-top,0px));bottom:calc(68px + env(safe-area-inset-bottom,0px));left:0;right:0;overflow-y:auto;display:grid;grid-template-columns:repeat(3,1fr);gap:2px;align-content:start}' +
    '.ec-t{position:relative;aspect-ratio:9/13;background:#1a1a2e center/cover;overflow:hidden;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:6px;font-weight:700;font-size:.78rem}' +
    '.ec-t video,.ec-t img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}' +
    '.ec-t .d{position:absolute;bottom:5px;right:6px;font-size:.7rem;font-weight:800;text-shadow:0 1px 3px #000}' +
    '.ec-t .c{position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;border:2px solid #fff;background:#0006;font-size:.72rem;font-weight:900;display:flex;align-items:center;justify-content:center}' +
    '.ec-t.sel .c{background:var(--c1,#00ff88);border-color:var(--c1,#00ff88);color:#000}.ec-t.sel::after{content:"";position:absolute;inset:0;background:#fff3}' +
    '.ec-t ic{font-size:1.8rem;font-style:normal}' +
    '.ec-galbar{position:absolute;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:space-between;padding:10px 14px calc(10px + env(safe-area-inset-bottom,0px));background:#0a0a14;border-top:1px solid #ffffff14}' +
    '.ec-galbar .m{display:flex;align-items:center;gap:8px;background:#ffffff14;border-radius:22px;padding:10px 16px;font-weight:800;font-size:.82rem}.ec-galbar .m.on{background:var(--c1,#00ff88);color:#000}' +
    /* montage */
    '.ec-stage{position:absolute;inset:0;background:#000;overflow:hidden}.ec-stage video,.ec-stage img.m{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}' +
    '.ec-tx{position:absolute;transform:translate(-50%,-50%);font-weight:800;text-align:center;line-height:1.15;touch-action:none;max-width:90%;white-space:pre-wrap;word-break:break-word;text-shadow:0 2px 6px #000b;padding:2px 8px;border-radius:8px}' +
    '.ec-panel{position:absolute;left:0;right:0;bottom:calc(92px + env(safe-area-inset-bottom,0px));z-index:5;padding:12px 16px;background:#000c;display:none}.ec-panel.on{display:block}' +
    '.ec-panel label{display:flex;align-items:center;gap:10px;font-size:.74rem;font-weight:700;margin:6px 0}.ec-panel label span{width:104px}.ec-panel input[type=range]{flex:1;accent-color:#00ff88}.ec-panel em{font-style:normal;width:38px;text-align:right;color:#9aa3b8}' +
    '.ec-strip{position:absolute;left:0;right:0;bottom:0;z-index:5;display:flex;gap:8px;overflow-x:auto;padding:10px 12px calc(10px + env(safe-area-inset-bottom,0px));background:linear-gradient(transparent,#000d)}' +
    '.ec-clip{position:relative;flex:0 0 auto;width:52px;height:72px;border-radius:8px;overflow:hidden;background:#222;border:2px solid transparent}.ec-clip.on{border-color:var(--c1,#00ff88)}' +
    '.ec-clip video,.ec-clip img{width:100%;height:100%;object-fit:cover}.ec-clip small{position:absolute;bottom:2px;left:3px;font-size:.58rem;font-weight:800;text-shadow:0 1px 2px #000}' +
    '.ec-clip u{position:absolute;top:1px;right:2px;font-size:.8rem;text-decoration:none;background:#000a;border-radius:50%;width:18px;height:18px;text-align:center;line-height:18px}' +
    '.ec-add{flex:0 0 auto;width:52px;height:72px;border-radius:8px;background:#ffffff18;font-size:1.6rem}' +
    '#ecTxEd{position:absolute;inset:0;z-index:9;background:#000d;display:none;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:20px}#ecTxEd.on{display:flex}' +
    '#ecTxIn{width:100%;max-width:420px;background:transparent;border:none;outline:none;color:#fff;font-size:1.6rem;font-weight:800;text-align:center;resize:none;height:140px;-webkit-user-select:text;user-select:text}' +
    '.ec-cols{display:flex;gap:10px}.ec-cols b{width:30px;height:30px;border-radius:50%;border:3px solid #fff3}.ec-cols b.on{border-color:#fff}' +
    '.ec-row{display:flex;gap:10px}.ec-row button{background:#ffffff1a;border-radius:20px;padding:10px 20px;font-weight:800;font-size:.8rem}' +
    /* publier */
    '#ec-post{background:#0a0a14}.ec-pb{position:absolute;top:calc(62px + env(safe-area-inset-top,0px));bottom:calc(76px + env(safe-area-inset-bottom,0px));left:0;right:0;overflow-y:auto;padding:14px 16px}' +
    '.ec-dr{display:flex;gap:12px;align-items:flex-start}.ec-dr textarea{flex:1;height:118px;background:transparent;border:none;outline:none;color:#fff;font-size:.9rem;resize:none;-webkit-user-select:text;user-select:text;font-family:inherit}' +
    '.ec-cov{position:relative;width:88px;height:128px;border-radius:10px;overflow:hidden;background:#222;flex:0 0 auto}.ec-cov img{width:100%;height:100%;object-fit:cover}' +
    '.ec-cov span{position:absolute;left:0;right:0;bottom:0;background:#000b;font-size:.58rem;font-weight:800;padding:4px;text-align:center}' +
    '.ec-chips{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 14px}.ec-chips button{background:#ffffff14;border-radius:16px;padding:7px 12px;font-size:.74rem;font-weight:700}' +
    '.ec-seg{display:flex;background:#ffffff12;border-radius:12px;padding:3px;margin-bottom:14px}.ec-seg button{flex:1;padding:10px;border-radius:10px;font-weight:800;font-size:.8rem}.ec-seg button.on{background:var(--c1,#00ff88);color:#000}' +
    '.ec-li{display:flex;align-items:center;gap:10px;width:100%;padding:15px 2px;border-top:1px solid #ffffff12;font-size:.88rem;text-align:left}.ec-li span{flex:1}.ec-li b{color:#9aa3b8;font-weight:600;font-size:.8rem;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ec-sw{appearance:none;-webkit-appearance:none;width:46px;height:26px;border-radius:13px;background:#444;position:relative;transition:.2s;flex:0 0 auto}.ec-sw::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.2s}.ec-sw:checked{background:var(--c1,#00ff88)}.ec-sw:checked::after{left:23px}' +
    '.ec-pbar{position:absolute;left:0;right:0;bottom:0;display:flex;gap:10px;padding:12px 16px calc(12px + env(safe-area-inset-bottom,0px));background:#0a0a14;border-top:1px solid #ffffff14}' +
    '.ec-b1,.ec-b2{flex:1;padding:14px;border-radius:12px;font-weight:900;font-size:.9rem}.ec-b1{background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000!important}.ec-b2{background:#ffffff18}' +
    '.ec-b1[disabled]{opacity:.5}' +
    /* feuille */
    '#ecSheet{position:absolute;inset:0;z-index:20;background:#0008;display:none;align-items:flex-end}#ecSheet.on{display:flex}' +
    '#ecSheetBox{width:100%;max-height:82vh;overflow-y:auto;background:#12121f;border-radius:20px 20px 0 0;padding:10px 16px calc(16px + env(safe-area-inset-bottom,0px))}' +
    '.ec-grip{width:40px;height:4px;border-radius:2px;background:#fff3;margin:0 auto 10px}.ec-sh{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.ec-sh b{font-size:1rem}' +
    '.ec-snd{display:flex;align-items:center;gap:12px;padding:8px 0}.ec-snd img{width:54px;height:54px;border-radius:10px;object-fit:cover;flex:0 0 auto}.ec-snd div{flex:1;min-width:0}.ec-snd b{display:block;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ec-snd small{color:#9aa3b8;font-size:.7rem}' +
    '.ec-snd .p{width:38px;height:38px;border-radius:50%;background:#ffffff18;font-size:.9rem}.ec-snd .u{background:var(--c1,#00ff88);color:#000!important;font-weight:800;font-size:.72rem;border-radius:16px;padding:8px 14px}' +
    '.ec-search{width:100%;background:#ffffff12;border:none;outline:none;color:#fff;border-radius:12px;padding:11px 14px;font-size:.85rem;margin-bottom:8px;-webkit-user-select:text;user-select:text}' +
    '.ec-cg{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.ec-cg button{aspect-ratio:9/16;border-radius:8px;overflow:hidden;background:#222;border:2px solid transparent}.ec-cg button.on{border-color:var(--c1,#00ff88)}.ec-cg img{width:100%;height:100%;object-fit:cover}' +
    '.ec-dd{display:flex;gap:12px;align-items:center;padding:10px 0;border-top:1px solid #ffffff10}.ec-dd img,.ec-dd video{width:46px;height:64px;border-radius:8px;object-fit:cover;background:#222}.ec-dd div{flex:1;font-size:.8rem}.ec-dd small{color:#9aa3b8;display:block}' +
    '#ecProg{position:absolute;inset:0;z-index:30;background:#000e;display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;font-weight:800}#ecProg.on{display:flex}' +
    '#ecProg .bar{width:70%;max-width:320px;height:8px;border-radius:4px;background:#ffffff22;overflow:hidden}#ecProg .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed));transition:width .2s}' +
    '#evoFab{position:fixed;right:16px;bottom:calc(88px + env(safe-area-inset-bottom,0px));z-index:98;width:54px;height:54px;border-radius:50%;border:none;background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));color:#000;font-size:2rem;font-weight:900;line-height:1;box-shadow:0 6px 20px rgba(0,0,0,.5),0 0 18px rgba(var(--c1-rgb,0,255,136),.35);cursor:pointer}' +
    '#evoFab:active{transform:scale(.92)}';

  var cssFait = false;
  function injecterCss() { if (cssFait) return; cssFait = true; var s = D.createElement('style'); s.textContent = CSS; D.head.appendChild(s); }

  /* ---------------- construction du DOM ---------------- */
  function construire() {
    injecterCss();
    root = D.createElement('div'); root.id = 'evoCreer';
    root.innerHTML =
      '<section class="s" id="ec-cam"><video id="ecCamV" autoplay muted playsinline></video><div class="ec-msg" id="ecMsg"></div><div class="ec-count" id="ecCount"></div>' +
      '<div class="ec-top"><button class="ec-ib" data-act="fermer">✕</button><button class="ec-pill" data-act="sons" id="ecPill1">♫ Ajouter un son</button><span style="width:40px"></span></div>' +
      '<div class="ec-side"><button class="ec-tool" data-act="flip"><i>🔄</i>Retourner</button><button class="ec-tool" data-act="torch" id="ecTorch"><i>⚡</i>Flash</button><button class="ec-tool" data-act="minuteur" id="ecMin"><i>⏱</i>Minuteur</button><button class="ec-tool" data-act="filtcam"><i>✨</i>Filtres</button></div>' +
      '<div class="ec-filt" id="ecFiltCam"></div>' +
      '<div class="ec-bot"><div class="ec-modes" id="ecModes"><button data-mode="60" class="on">60 s</button><button data-mode="15">15 s</button><button data-mode="photo">PHOTO</button><button data-mode="texte">TEXTE</button></div>' +
      '<div class="ec-ctrl"><button class="ec-imp" data-act="importer"><span id="ecImpT"></span>Importer</button>' +
      '<button class="ec-rec" id="ecRec" data-act="rec"><svg viewBox="0 0 84 84"><circle cx="42" cy="42" r="38" fill="none" stroke="#fff" stroke-width="5" opacity=".9"/><circle id="ecRing" cx="42" cy="42" r="38" fill="none" stroke="#ef4444" stroke-width="5" stroke-dasharray="238.8" stroke-dashoffset="238.8"/></svg><div class="core"></div></button>' +
      '<button class="ec-ok" id="ecOk" data-act="camOk"><b>✓</b><small id="ecNb"></small></button></div>' +
      '<div class="ec-sub"><button data-act="brouillons">📁 Brouillons</button><button data-act="undoClip" id="ecUndo" style="display:none">⌫ Annuler le dernier</button></div></div></section>' +

      '<section class="s" id="ec-gal"><div class="ec-top dk"><button class="ec-ib" data-act="popEcran">✕</button><div class="ec-title">Récents</div><button class="ec-pill" data-act="galTexte">✎ Texte</button></div>' +
      '<div class="ec-tabs" id="ecTabs"><button data-ft="all" class="on">Tous</button><button data-ft="video">Vidéos</button><button data-ft="image">Photos</button></div>' +
      '<div class="ec-grid" id="ecGrid"></div>' +
      '<div class="ec-galbar"><button class="m" data-act="multi" id="ecMulti">☑ Sélection multiple</button><button class="ec-next" data-act="galNext" id="ecGalNext" disabled>Suivant</button></div></section>' +

      '<section class="s" id="ec-edit"><div class="ec-stage" id="ecStage" data-act="playpause"><video id="ecEV" playsinline loop></video><img class="m" id="ecEI" style="display:none"><div id="ecTexts"></div></div>' +
      '<div class="ec-top"><button class="ec-ib" data-act="popEcran">←</button><button class="ec-pill" data-act="sons" id="ecPill2">♫ Ajouter un son</button><button class="ec-next" data-act="editNext">Suivant</button></div>' +
      '<div class="ec-side"><button class="ec-tool" data-act="texte"><i>Aa</i>Texte</button><button class="ec-tool" data-act="panel" data-p="filtres"><i>✨</i>Filtres</button><button class="ec-tool" data-act="panel" data-p="trim" id="ecToolTrim"><i>✂️</i>Rogner</button><button class="ec-tool" data-act="panel" data-p="volume"><i>🔊</i>Volume</button></div>' +
      '<div class="ec-panel" id="ecPanel"></div><div class="ec-strip" id="ecStrip"></div>' +
      '<div id="ecTxEd"><textarea id="ecTxIn" maxlength="120" placeholder="Écris ton texte…"></textarea><div class="ec-cols" id="ecCols"></div><div class="ec-row"><button data-act="txBg">A▭ Fond</button><button data-act="txDel">🗑 Supprimer</button><button data-act="txOk" style="background:var(--c1,#00ff88);color:#000">OK</button></div></div></section>' +

      '<section class="s" id="ec-post"><div class="ec-top dk"><button class="ec-ib" data-act="popEcran">←</button><div class="ec-title">Publier</div><span style="width:40px"></span></div>' +
      '<div class="ec-pb"><div class="ec-dr"><textarea id="ecDesc" maxlength="300" placeholder="Décris ta vidéo, ajoute des #hashtags…"></textarea><button class="ec-cov" data-act="cover"><img id="ecCovImg" alt=""><span>Modifier la couverture</span></button></div>' +
      '<div class="ec-chips" id="ecChips"></div>' +
      '<div class="ec-seg" id="ecSeg"><button data-dest="post" class="on">Publication</button><button data-dest="story">Story · 24 h</button></div>' +
      '<button class="ec-li" data-act="sons"><span>🎵 Son</span><b id="ecSonLbl">Aucun</b>›</button>' +
      '<button class="ec-li" data-act="visib"><span>👁 Qui peut voir</span><b id="ecVisLbl">Tout le monde</b>›</button>' +
      '<label class="ec-li"><span>💬 Autoriser les commentaires</span><input type="checkbox" class="ec-sw" id="ecComm" checked></label></div>' +
      '<div class="ec-pbar"><button class="ec-b2" data-act="brouillon">📁 Brouillon</button><button class="ec-b1" data-act="publier" id="ecPub">Publier</button></div></section>' +

      '<div id="ecSheet" data-act="sheetBg"><div id="ecSheetBox"></div></div>' +
      '<div id="ecProg"><div id="ecProgT">Montage…</div><div class="bar"><i id="ecProgB"></i></div><small id="ecProgP" style="color:#9aa3b8">0 %</small></div>';
    D.body.appendChild(root);

    inpMedia = D.createElement('input'); inpMedia.type = 'file'; inpMedia.accept = 'image/*,video/*'; inpMedia.multiple = true; inpMedia.style.display = 'none';
    inpAudio = D.createElement('input'); inpAudio.type = 'file'; inpAudio.accept = 'audio/*'; inpAudio.style.display = 'none';
    inpCover = D.createElement('input'); inpCover.type = 'file'; inpCover.accept = 'image/*'; inpCover.style.display = 'none';
    root.appendChild(inpMedia); root.appendChild(inpAudio); root.appendChild(inpCover);
    inpMedia.onchange = function () { ajouterAuPool(inpMedia.files); inpMedia.value = ''; };
    inpAudio.onchange = function () { var f = inpAudio.files[0]; inpAudio.value = ''; if (!f) return; utiliserSon({ id: 'u_' + Date.now(), titre: f.name.replace(/\.\w+$/, ''), artiste: 'Mon audio', cover: coverSvg(['#334155', '#00ff88'], '🎧'), url: URL.createObjectURL(f), blob: f }); };
    inpCover.onchange = async function () { var f = inpCover.files[0]; inpCover.value = ''; if (!f) return; S.coverBlob = f; S.coverIdx = -1; $('#ecCovImg').src = URL.createObjectURL(f); fermerSheet(); };

    root.addEventListener('click', function (e) {
      var el = e.target.closest('[data-act]'); if (!el) return;
      if (el.dataset.act === 'sheetBg' && e.target !== el) return;
      if (el.dataset.act === 'playpause' && e.target.closest('.ec-tx')) return;
      var f = A[el.dataset.act]; if (f) f(el, e);
    });
    $('#ecModes').addEventListener('click', function (e) { var b = e.target.closest('[data-mode]'); if (b) changerMode(b.dataset.mode); });
    $('#ecTabs').addEventListener('click', function (e) { var b = e.target.closest('[data-ft]'); if (!b) return; S.ft = b.dataset.ft; root.querySelectorAll('#ecTabs button').forEach(function (x) { x.classList.toggle('on', x === b); }); dessinerGrille(); });
    $('#ecSeg').addEventListener('click', function (e) { var b = e.target.closest('[data-dest]'); if (!b) return; S.dest = b.dataset.dest; majSeg(); });
    $('#ecChips').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; var t = $('#ecDesc'), x = b.textContent, nu = x === '# Hashtag' || x === '@ Mention'; if (nu) x = x.charAt(0); t.value = (t.value + (t.value && !/\s$/.test(t.value) ? ' ' : '') + x + (nu ? '' : ' ')).slice(0, 300); S.desc = t.value; t.focus(); });
    $('#ecCols').addEventListener('click', function (e) { var b = e.target.closest('b'); if (!b) return; txEd.couleur = b.dataset.c; dessinerCouleurs(); });
    $('#ecDesc').addEventListener('input', function () { S.desc = this.value; });
    $('#ecComm').addEventListener('change', function () { S.comm = this.checked; });
    $('#ecChips').innerHTML = ['# Hashtag', '@ Mention'].concat(TAGS).map(function (t) { return '<button>' + t + '</button>'; }).join('');
    $('#ecCols').innerHTML = COULEURS.map(function (c) { return '<b data-c="' + c + '" style="background:' + c + '"></b>'; }).join('');
    musicEl = new Audio(); musicEl.loop = true; prevAudio = new Audio();
    prevAudio.onended = function () { majPlayBtns(null); };
  }

  /* ---------------- navigation entre écrans (compatible bouton Retour) ---------------- */
  function montrer(nom) {
    S.ecran = nom;
    root.querySelectorAll('.s').forEach(function (s) { s.classList.toggle('on', s.id === 'ec-' + nom); });
    if (nom === 'cam') { demarrerCam(); } else { arreterCam(); }
    if (nom !== 'edit') { try { $('#ecEV').pause(); musicEl.pause(); } catch (e) {} }
    if (nom === 'edit') { S.covers = []; if (!S.coverBlob) S.coverIdx = 0; majPillSon(); montrerClip(S.sel, true); }
    if (nom === 'post') preparerPost();
    if (nom === 'gal') dessinerGrille();
    majPillSon();
  }
  function pushEcran(nom) {
    var ent = { prev: S.ecran };
    ent.off = NAT.pushOverlay(function () { if (!S) return; S.stack.pop(); montrer(ent.prev); });
    S.stack.push(ent); montrer(nom);
  }
  function popEcran() { var ent = S.stack.pop(); if (!ent) { demanderFermer(); return; } ent.off(); montrer(ent.prev); }

  /* ---------------- ouverture / fermeture ---------------- */
  var rootOff = null;
  async function ouvrir(o) {
    if (!root) construire();
    var u = await getUser();
    if (!u) { toast('⚠️ Connecte-toi d\'abord pour publier', 'error'); setTimeout(function () { location.href = 'index.html'; }, 900); return; }
    S = neuf(o);
    D.body.style.overflow = 'hidden'; root.classList.add('on'); var fab = $('#evoFab'); if (fab) fab.style.display = 'none';
    S.ecran = 'cam'; $('#ecPub').disabled = false; majCamClips(); montrer('cam'); majSeg(); majModes();
    rootOff = NAT.pushOverlay(function () { rootOff = null; demanderFermer(true); });
    if (o && o.galerie) setTimeout(function () { inpMedia.click(); }, 150);
    if (o && o.brouillon) restaurerBrouillon(o.brouillon);
  }
  function demanderFermer(deja) {
    var contenu = S && (S.clips.length || S.pool.length);
    if (!contenu) { fermer(deja); return; }
    sheet('Abandonner la création ?', '<p style="color:#9aa3b8;font-size:.82rem;margin:0 0 12px">Tes clips seront perdus, sauf si tu les enregistres en brouillon.</p>' +
      '<div class="ec-row" style="flex-direction:column"><button data-act="sauvQuitter" style="background:var(--c1,#00ff88);color:#000;padding:13px;border-radius:12px;font-weight:800">📁 Enregistrer en brouillon</button>' +
      '<button data-act="quitterSans" style="background:#ef444433;color:#f87171;padding:13px;border-radius:12px;font-weight:800">Abandonner</button>' +
      '<button data-act="sheetX" style="padding:13px;font-weight:700;color:#9aa3b8">Continuer</button></div>');
    if (deja && !rootOff) rootOff = NAT.pushOverlay(function () { rootOff = null; demanderFermer(true); });
  }
  function fermer(deja) {
    if (!S) return;
    arreterCam(); stopPrev(); try { musicEl.pause(); $('#ecEV').pause(); } catch (e) {}
    while (S.stack.length) { var e = S.stack.pop(); try { e.off(); } catch (x) {} }
    if (S.sheetOff) { var so = S.sheetOff; S.sheetOff = null; so(); }
    if (rootOff && !deja) { var r = rootOff; rootOff = null; r(); } else rootOff = null;
    root.classList.remove('on'); D.body.style.overflow = ''; S = null;
    var fab = $('#evoFab'); if (fab) fab.style.display = '';
  }

  /* ---------------- caméra ---------------- */
  function msgCam(t) { $('#ecMsg').innerHTML = t || ''; }
  async function demarrerCam() {
    arreterCam(); msgCam('');
    if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) { msgCam('📷 Caméra indisponible sur cet appareil.<br>Touche <b>Importer</b> pour choisir dans ta galerie.'); return; }
    var okCam = await PERM.ensure('camera', 'Pour filmer et prendre des photos directement dans EVO ARENA.');
    if (!S || S.ecran !== 'cam') return;
    if (!okCam) { msgCam('📷 Autorisation de l\'appareil photo requise pour filmer.<br>Tu peux quand même <b>Importer</b> depuis ta galerie.'); return; }
    var micOk = (await PERM.status('micro')) === 'granted' || (await PERM.ensure('micro', 'Pour enregistrer le son de tes vidéos (désactivé quand tu utilises une musique).'));
    if (!S || S.ecran !== 'cam') return;
    try {
      S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: S.face, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: micOk });
    } catch (e) {
      try { S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: S.face }, audio: false }); }
      catch (e2) { msgCam('📷 Impossible d\'ouvrir la caméra.<br>Ferme les autres applications qui l\'utilisent, ou touche <b>Importer</b>.'); return; }
    }
    if (!S || S.ecran !== 'cam') { arreterCam(); return; }
    var v = $('#ecCamV'); v.srcObject = S.stream; v.style.transform = S.face === 'user' ? 'scaleX(-1)' : 'none'; v.style.filter = FILTRES[S.filtre].c; try { v.play(); } catch (e) {}
  }
  function arreterCam() {
    try { if (S && S.rec && S.rec.state !== 'inactive') S.rec.stop(); } catch (e) {}
    if (S && S.stream) { S.stream.getTracks().forEach(function (t) { t.stop(); }); S.stream = null; }
    var v = $('#ecCamV'); if (v) v.srcObject = null;
  }
  function changerMode(m) { if (!S) return; S.mode = m; S.maxDur = m === '15' ? 15 : 60; majModes(); if (m === 'texte') { creerClipTexte(); } }
  function majModes() {
    root.querySelectorAll('#ecModes button').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === S.mode); });
    $('#ecRec').classList.toggle('photo', S.mode === 'photo');
  }
  function majCamClips() {
    var n = S.clips.length; $('#ecOk').classList.toggle('on', n > 0); $('#ecNb').textContent = n ? n + ' clip' + (n > 1 ? 's' : '') : '';
    $('#ecUndo').style.display = n ? '' : 'none';
    var l = S.clips[n - 1]; var t = $('#ecImpT'); t.style.backgroundImage = l && l.type === 'image' ? 'url(' + l.url + ')' : '';
  }
  async function lancerRec() {
    if (S.rec && S.rec.state === 'recording') { S.rec.stop(); return; }
    if (!S.stream) { toast('📷 Caméra non disponible — touche Importer', 'error'); return; }
    if (S.mode === 'photo') { if (S.minuteur) await compteARebours(S.minuteur); return photo(); }
    if (S.minuteur) await compteARebours(S.minuteur);
    if (!S || !S.stream) return;
    if (!W.MediaRecorder) { toast('Enregistrement vidéo non pris en charge ici — utilise Importer', 'error'); return; }
    var deja = S.clips.reduce(function (a, c) { return a + dureeClip(c); }, 0), reste = S.maxDur - deja;
    if (reste < 1) { toast('Durée maximale atteinte (' + S.maxDur + ' s)', 'info'); return; }
    var mt = choisirMime(), flux = S.stream;
    flux.getAudioTracks().forEach(function (t) { t.enabled = !S.music; });
    S.chunks = [];
    try { S.rec = new MediaRecorder(flux, mt ? { mimeType: mt, videoBitsPerSecond: 2500000 } : undefined); } catch (e) { S.rec = new MediaRecorder(flux); }
    S.rec.ondataavailable = function (ev) { if (ev.data && ev.data.size) S.chunks.push(ev.data); };
    S.rec.onstop = function () { finRec(S.rec.mimeType || mt || 'video/webm'); };
    S.rec.start(250); S.recStart = Date.now(); NAT.haptic('medium');
    $('#ecRec').classList.add('rec');
    if (S.music) { try { musicEl.src = await urlSon(S.music); musicEl.currentTime = 0; musicEl.play(); } catch (e) {} }
    (function boucle() {
      if (!S || !S.rec || S.rec.state !== 'recording') return;
      var t = (Date.now() - S.recStart) / 1000; $('#ecRing').style.strokeDashoffset = String(238.8 * (1 - Math.min(1, t / reste)));
      if (t >= reste) { S.rec.stop(); return; }
      requestAnimationFrame(boucle);
    })();
  }
  function finRec(mime) {
    var dur = (Date.now() - S.recStart) / 1000; $('#ecRec').classList.remove('rec'); $('#ecRing').style.strokeDashoffset = '238.8'; try { musicEl.pause(); } catch (e) {}
    if (dur < .6 || !S.chunks.length) { toast('Maintiens un peu plus longtemps pour filmer', 'info'); return; }
    var blob = new Blob(S.chunks, { type: mime }); S.clips.push({ type: 'video', blob: blob, url: URL.createObjectURL(blob), dur: dur, start: 0, end: dur });
    majCamClips(); NAT.haptic('light');
  }
  function photo() {
    var v = $('#ecCamV'); if (!v.videoWidth) return;
    var cv = D.createElement('canvas'); cv.width = v.videoWidth; cv.height = v.videoHeight; var cx = cv.getContext('2d');
    if (S.face === 'user') { cx.translate(cv.width, 0); cx.scale(-1, 1); } cx.drawImage(v, 0, 0);
    cv.toBlob(function (b) { if (!S) return; S.clips.push({ type: 'image', blob: b, url: URL.createObjectURL(b), dur: 4 }); S.sel = S.clips.length - 1; majCamClips(); NAT.haptic('medium'); pushEcran('edit'); }, 'image/jpeg', .92);
  }
  function compteARebours(n) {
    return new Promise(function (ok) {
      var el = $('#ecCount'); el.style.display = 'flex'; var i = n;
      (function tic() { if (!S) return ok(); if (i <= 0) { el.style.display = 'none'; return ok(); } el.textContent = i; NAT.haptic('light'); i--; setTimeout(tic, 1000); })();
    });
  }
  function creerClipTexte() {
    var cv = D.createElement('canvas'); cv.width = 720; cv.height = 1280; var cx = cv.getContext('2d'); var p = FONDS_TEXTE[Math.floor(Math.random() * FONDS_TEXTE.length)];
    var g = cx.createLinearGradient(0, 0, 720, 1280); g.addColorStop(0, p[0]); g.addColorStop(1, p[1]); cx.fillStyle = g; cx.fillRect(0, 0, 720, 1280);
    cv.toBlob(function (b) { if (!S) return; S.clips = [{ type: 'image', blob: b, url: URL.createObjectURL(b), dur: 5 }]; S.sel = 0; S.mode = '60'; majModes(); pushEcran('edit'); setTimeout(function () { ouvrirTexte(); }, 250); }, 'image/jpeg', .9);
  }

  /* ---------------- galerie ---------------- */
  function ajouterAuPool(files) {
    var nouveaux = 0;
    Array.prototype.forEach.call(files || [], function (f) {
      var type = /^video\//.test(f.type) ? 'video' : /^image\//.test(f.type) ? 'image' : null; if (!type) return;
      if (type === 'video' && f.size > 100 * 1024 * 1024) { toast('⚠️ ' + f.name + ' : vidéo trop lourde (100 Mo max)', 'error'); return; }
      var it = { id: 'p' + Date.now() + Math.random().toString(36).slice(2, 6), file: f, type: type, url: URL.createObjectURL(f), dur: 0 };
      S.pool.unshift(it); nouveaux++;
      if (type === 'video') { var v = D.createElement('video'); v.preload = 'metadata'; v.onloadedmetadata = function () { it.dur = isFinite(v.duration) ? v.duration : 0; if (S && S.ecran === 'gal') dessinerGrille(); }; v.src = it.url; }
      if (!S.multi) S.selOrdre = [it.id]; else if (S.selOrdre.length < 10) S.selOrdre.push(it.id);
    });
    if (!nouveaux) return;
    if (S.ecran !== 'gal') pushEcran('gal'); else dessinerGrille();
  }
  function dessinerGrille() {
    if (!S) return;
    var h = '<div class="ec-t" data-act="galCam"><ic>📷</ic>Appareil photo</div><div class="ec-t" data-act="importer"><ic>➕</ic>Ajouter</div>';
    S.pool.forEach(function (it) {
      if (S.ft !== 'all' && it.type !== S.ft) return;
      var n = S.selOrdre.indexOf(it.id), sel = n >= 0;
      h += '<div class="ec-t' + (sel ? ' sel' : '') + '" data-act="tuile" data-id="' + it.id + '">' + (it.type === 'video' ? '<video src="' + it.url + '#t=0.1" muted preload="metadata" playsinline></video>' : '<img src="' + it.url + '" alt="">') +
        (it.type === 'video' && it.dur ? '<span class="d">' + fmt(it.dur) + '</span>' : '') + '<span class="c">' + (sel && S.multi ? n + 1 : sel ? '✓' : '') + '</span></div>';
    });
    $('#ecGrid').innerHTML = h;
    $('#ecMulti').classList.toggle('on', S.multi);
    var nb = S.selOrdre.length; var b = $('#ecGalNext'); b.disabled = !nb; b.textContent = nb > 1 ? 'Suivant (' + nb + ')' : 'Suivant';
  }

  /* ---------------- montage ---------------- */
  function clipsDepuisPool() {
    S.selOrdre.forEach(function (id) {
      var it = S.pool.filter(function (p) { return p.id === id; })[0]; if (!it) return;
      if (it.type === 'video') S.clips.push({ type: 'video', blob: it.file, url: it.url, dur: it.dur || 10, start: 0, end: it.dur || 10, fichier: true });
      else S.clips.push({ type: 'image', blob: it.file, url: it.url, dur: 3, fichier: true });
    });
    S.selOrdre = []; S.pool = [];
  }
  var tempo = 0;
  function montrerClip(i, lire) {
    if (!S || !S.clips.length) return;
    S.sel = Math.max(0, Math.min(i, S.clips.length - 1)); var c = S.clips[S.sel];
    var v = $('#ecEV'), im = $('#ecEI'), f = FILTRES[S.filtre].c;
    v.style.filter = im.style.filter = f; clearInterval(tempo);
    if (c.type === 'video') {
      im.style.display = 'none'; v.style.display = 'block'; v.src = c.url; v.loop = false; v.volume = S.volOrig;
      v.onloadedmetadata = function () { try { v.currentTime = c.start; } catch (e) {} if (lire !== false) jouerPreview(); };
      v.load();
      v.onended = function () { try { v.currentTime = c.start; v.play(); } catch (e) {} };
      tempo = setInterval(function () { if (!v.paused && v.currentTime >= c.end - .05) { v.currentTime = c.start; } }, 80);
    } else { v.pause(); v.style.display = 'none'; im.style.display = 'block'; im.src = c.url; if (lire !== false) jouerMusique(); }
    dessinerStrip(); dessinerTextes(); majTrimBtn(); if (S.panel) dessinerPanel();
  }
  async function jouerMusique() {
    if (!S || !S.music) { musicEl.pause(); return; }
    try { musicEl.src = await urlSon(S.music); musicEl.volume = S.volMusic; musicEl.currentTime = 0; await musicEl.play(); } catch (e) {}
  }
  function jouerPreview() { var v = $('#ecEV'); try { v.play().catch(function () { v.muted = true; v.play().catch(function () {}); }); } catch (e) {} jouerMusique(); }
  function majTrimBtn() { var c = S.clips[S.sel]; var b = $('#ecToolTrim'); if (b) b.querySelector('i').textContent = c && c.type === 'video' ? '✂️' : '⏱'; if (b) b.lastChild.textContent = c && c.type === 'video' ? 'Rogner' : 'Durée'; }
  function dessinerStrip() {
    var h = S.clips.map(function (c, i) {
      return '<div class="ec-clip' + (i === S.sel ? ' on' : '') + '" data-act="clip" data-i="' + i + '">' + (c.type === 'video' ? '<video src="' + c.url + '#t=0.2" muted preload="metadata" playsinline></video>' : '<img src="' + c.url + '" alt="">') + '<small>' + fmt(dureeClip(c)) + '</small>' + (i === S.sel && S.clips.length > 1 ? '<u data-act="clipDel" data-i="' + i + '">✕</u>' : '') + '</div>';
    }).join('') + '<button class="ec-add" data-act="importer">＋</button>';
    $('#ecStrip').innerHTML = h;
  }
  function dessinerTextes() {
    var box = $('#ecTexts'), stage = $('#ecStage'); var w = stage.offsetWidth || 360;
    box.innerHTML = '';
    S.textes.forEach(function (t) {
      var d = D.createElement('div'); d.className = 'ec-tx'; d.textContent = t.txt; d.style.left = t.x * 100 + '%'; d.style.top = t.y * 100 + '%';
      d.style.color = t.fond ? (t.couleur === '#ffffff' ? '#000' : '#fff') : t.couleur; d.style.fontSize = (t.taille * w / 360) + 'px'; if (t.fond) d.style.background = t.couleur;
      brancherDrag(d, t); box.appendChild(d);
    });
  }
  function brancherDrag(d, t) {
    var dx = 0, dy = 0, bouge = false, stage = $('#ecStage');
    d.addEventListener('pointerdown', function (e) { e.stopPropagation(); d.setPointerCapture(e.pointerId); bouge = false; dx = e.clientX; dy = e.clientY; });
    d.addEventListener('pointermove', function (e) {
      if (!d.hasPointerCapture(e.pointerId)) return; if (Math.abs(e.clientX - dx) + Math.abs(e.clientY - dy) > 6) bouge = true;
      if (!bouge) return; var r = stage.getBoundingClientRect(); t.x = Math.max(.05, Math.min(.95, (e.clientX - r.left) / r.width)); t.y = Math.max(.08, Math.min(.92, (e.clientY - r.top) / r.height)); d.style.left = t.x * 100 + '%'; d.style.top = t.y * 100 + '%';
    });
    d.addEventListener('pointerup', function (e) { e.stopPropagation(); if (!bouge) ouvrirTexte(t); });
  }
  var txEd = { cible: null, couleur: '#ffffff', fond: false };
  function dessinerCouleurs() { root.querySelectorAll('#ecCols b').forEach(function (b) { b.classList.toggle('on', b.dataset.c === txEd.couleur); }); }
  function ouvrirTexte(t) {
    txEd.cible = t || null; txEd.couleur = t ? t.couleur : '#ffffff'; txEd.fond = t ? t.fond : false;
    $('#ecTxIn').value = t ? t.txt : ''; $('#ecTxEd').classList.add('on'); dessinerCouleurs(); setTimeout(function () { $('#ecTxIn').focus(); }, 120);
  }
  function panelHtml() {
    var c = S.clips[S.sel];
    if (S.panel === 'filtres') return '<div class="ec-filt on" style="position:static;padding:0">' + FILTRES.map(function (f, i) { return '<button data-act="filtre" data-i="' + i + '" class="' + (i === S.filtre ? 'on' : '') + '"><b style="filter:' + f.c + '"></b>' + f.n + '</button>'; }).join('') + '</div>';
    if (S.panel === 'volume') return '<label><span>Son d\'origine</span><input type="range" min="0" max="1" step=".05" value="' + S.volOrig + '" data-vol="o"><em>' + Math.round(S.volOrig * 100) + '</em></label><label><span>Musique</span><input type="range" min="0" max="1" step=".05" value="' + S.volMusic + '" data-vol="m"><em>' + Math.round(S.volMusic * 100) + '</em></label>';
    if (S.panel === 'trim') {
      if (c.type === 'image') return '<label><span>Durée de la photo</span><input type="range" min="1" max="10" step=".5" value="' + c.dur + '" data-trim="d"><em>' + c.dur + ' s</em></label>';
      return '<label><span>Début</span><input type="range" min="0" max="' + c.dur.toFixed(2) + '" step=".1" value="' + c.start + '" data-trim="s"><em>' + c.start.toFixed(1) + '</em></label><label><span>Fin</span><input type="range" min="0" max="' + c.dur.toFixed(2) + '" step=".1" value="' + c.end + '" data-trim="e"><em>' + c.end.toFixed(1) + '</em></label>';
    }
    return '';
  }
  function dessinerPanel() {
    var p = $('#ecPanel'); if (!S.panel) { p.classList.remove('on'); return; }
    p.innerHTML = panelHtml(); p.classList.add('on');
    p.querySelectorAll('[data-vol]').forEach(function (r) {
      r.oninput = function () { var v = parseFloat(r.value); if (r.dataset.vol === 'o') { S.volOrig = v; $('#ecEV').volume = v; } else { S.volMusic = v; musicEl.volume = v; } r.nextSibling.textContent = Math.round(v * 100); };
    });
    p.querySelectorAll('[data-trim]').forEach(function (r) {
      r.oninput = function () {
        var c = S.clips[S.sel], v = parseFloat(r.value), k = r.dataset.trim;
        if (k === 'd') { c.dur = v; r.nextSibling.textContent = v + ' s'; dessinerStrip(); return; }
        if (k === 's') { c.start = Math.min(v, c.end - .5); r.value = c.start; try { $('#ecEV').currentTime = c.start; } catch (e) {} }
        else { c.end = Math.max(v, c.start + .5); r.value = c.end; try { $('#ecEV').currentTime = Math.max(c.start, c.end - .4); } catch (e) {} }
        r.nextSibling.textContent = (k === 's' ? c.start : c.end).toFixed(1); dessinerStrip();
      };
    });
  }

  /* ---------------- sons ---------------- */
  function majPillSon() {
    var t = S && S.music ? '♫ ' + S.music.titre : '♫ Ajouter un son';
    ['ecPill1', 'ecPill2'].forEach(function (id) { var e = $('#' + id); if (e) e.textContent = t; });
    var l = $('#ecSonLbl'); if (l) l.textContent = S && S.music ? S.music.titre : 'Aucun';
  }
  async function urlSon(m) { if (m.url) return m.url; if (m.recette) { m.url = await genererSon(m.recette); } return m.url; }
  function stopPrev() { try { prevAudio.pause(); } catch (e) {} }
  function majPlayBtns(id) { root.querySelectorAll('.ec-snd .p').forEach(function (b) { b.textContent = b.dataset.id === id ? '⏸' : '▶'; }); }
  var SONS_LISTE = [], SONS_ONGLET = 'top';
  async function ouvrirSons() {
    sheet('Ajouter un son', '<div id="ecSnBody"><div style="padding:30px;text-align:center;color:#9aa3b8">Chargement…</div></div>');
    var fs = await chargerSonsFirestore();
    SONS_LISTE = fs.concat(sonsIntegres()); if (S.music && S.music.id.charAt(0) === 'u') SONS_LISTE.unshift(S.music);
    dessinerSons('');
  }
  function dessinerSons(q) {
    var body = $('#ecSnBody'); if (!body) return;
    var l = SONS_LISTE.filter(function (s) { return !q || (s.titre + ' ' + s.artiste).toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    var h = '<input class="ec-search" id="ecSnQ" placeholder="🔍 Rechercher un son" value="' + esc(q) + '">' +
      '<div class="ec-row" style="margin-bottom:6px"><button data-act="audioFichier" style="flex:1">🎧 Importer mon audio</button>' + (S.music ? '<button data-act="sonRetirer" style="flex:1;color:#f87171">✕ Retirer le son</button>' : '') + '</div>';
    h += l.map(function (s) {
      return '<div class="ec-snd"><img src="' + esc(s.cover) + '" alt=""><div><b>' + esc(s.titre) + (S.music && S.music.id === s.id ? ' ✓' : '') + '</b><small>' + esc(s.artiste) + (s.duree ? ' · ' + fmt(s.duree) : '') + '</small></div>' +
        '<button class="p" data-act="sonPrev" data-id="' + esc(s.id) + '">▶</button><button class="u" data-act="sonUse" data-id="' + esc(s.id) + '">Utiliser</button></div>';
    }).join('') || '<div style="padding:24px;text-align:center;color:#9aa3b8">Aucun son trouvé</div>';
    body.innerHTML = h;
    var inp = $('#ecSnQ'); inp.oninput = function () { var v = inp.value; clearTimeout(inp._t); inp._t = setTimeout(function () { dessinerSons(v); var n = $('#ecSnQ'); n.focus(); n.setSelectionRange(v.length, v.length); }, 250); };
  }
  async function utiliserSon(s) {
    S.music = s; fermerSheet(); stopPrev(); majPillSon();
    toast('🎵 Son ajouté : ' + s.titre, 'success');
    if (S.ecran === 'edit') jouerMusique();
  }

  /* ---------------- feuille générique ---------------- */
  function sheet(titre, html) {
    $('#ecSheetBox').innerHTML = '<div class="ec-grip"></div><div class="ec-sh"><b>' + titre + '</b><button data-act="sheetX" style="font-size:1.2rem;padding:4px 8px">✕</button></div>' + html;
    $('#ecSheet').classList.add('on');
    if (!S.sheetOff) S.sheetOff = NAT.pushOverlay(function () { S.sheetOff = null; $('#ecSheet').classList.remove('on'); stopPrev(); });
  }
  function fermerSheet() { if (!S) return; if (S.sheetOff) { var o = S.sheetOff; S.sheetOff = null; o(); } $('#ecSheet').classList.remove('on'); stopPrev(); }

  /* ---------------- écran « Publier » ---------------- */
  function majSeg() { root.querySelectorAll('#ecSeg button').forEach(function (b) { b.classList.toggle('on', b.dataset.dest === S.dest); }); $('#ecPub').textContent = S.dest === 'story' ? 'Ajouter à ma story' : 'Publier'; }
  var VIS = { tous: 'Tout le monde', abonnes: 'Abonnés', moi: 'Moi uniquement' };
  async function preparerPost() {
    $('#ecDesc').value = S.desc; $('#ecComm').checked = S.comm; $('#ecVisLbl').textContent = VIS[S.visib]; majSeg(); majPillSon();
    if (S.covers.length && S.coverIdx >= 0 || S.coverBlob) { if (S.covers[S.coverIdx]) $('#ecCovImg').src = S.covers[S.coverIdx].url; return; }
    S.covers = []; $('#ecCovImg').removeAttribute('src');
    try { S.covers = await extraireCovers(8); } catch (e) { S.covers = []; }
    if (S && S.covers.length) { S.coverIdx = 0; $('#ecCovImg').src = S.covers[0].url; }
  }
  function dessinerTexteSurCanvas(cx, Wd, Hd) {
    S.textes.forEach(function (t) {
      var px = t.taille * Wd / 360; cx.font = '800 ' + px + 'px system-ui,sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
      var lignes = String(t.txt).split('\n'), lh = px * 1.15, y0 = t.y * Hd - (lignes.length - 1) * lh / 2, x = t.x * Wd;
      lignes.forEach(function (l, i) {
        var y = y0 + i * lh;
        if (t.fond) { var w = cx.measureText(l).width + px * .6; cx.fillStyle = t.couleur; cx.beginPath(); (cx.roundRect ? cx.roundRect(x - w / 2, y - lh / 2, w, lh, px * .25) : cx.rect(x - w / 2, y - lh / 2, w, lh)); cx.fill(); cx.fillStyle = t.couleur === '#ffffff' ? '#000' : '#fff'; cx.fillText(l, x, y); }
        else { cx.lineWidth = px / 7; cx.strokeStyle = 'rgba(0,0,0,.75)'; cx.lineJoin = 'round'; cx.strokeText(l, x, y); cx.fillStyle = t.couleur; cx.fillText(l, x, y); }
      });
    });
  }
  function dessinerSource(cx, src, Wd, Hd, zoom) {
    var sw = src.videoWidth || src.naturalWidth || src.width, sh = src.videoHeight || src.naturalHeight || src.height; if (!sw || !sh) return;
    var sc = Math.max(Wd / sw, Hd / sh) * (zoom || 1), dw = sw * sc, dh = sh * sc;
    cx.fillStyle = '#000'; cx.fillRect(0, 0, Wd, Hd);
    try { cx.filter = FILTRES[S.filtre].c; } catch (e) {}
    cx.drawImage(src, (Wd - dw) / 2, (Hd - dh) / 2, dw, dh);
    try { cx.filter = 'none'; } catch (e) {}
    dessinerTexteSurCanvas(cx, Wd, Hd);
  }
  async function extraireCovers(n) {
    var total = dureeTotale(), out = [], cv = D.createElement('canvas'); cv.width = 360; cv.height = 640; var cx = cv.getContext('2d');
    var cache = {};
    for (var k = 0; k < n; k++) {
      var t = Math.min(total - .05, (total / n) * k + .1), acc = 0, c = null, loc = 0;
      for (var i = 0; i < S.clips.length; i++) { var d = dureeClip(S.clips[i]); if (t < acc + d || i === S.clips.length - 1) { c = S.clips[i]; c.i = i; loc = Math.max(0, t - acc); break; } acc += d; }
      if (!c) break;
      if (c.type === 'video') { var v = cache[c.i] || (cache[c.i] = await chargerVideo(c.url)); await chercher(v, Math.min(c.end - .05, c.start + loc)); dessinerSource(cx, v, 360, 640, 1); }
      else { var im = cache[c.i] || (cache[c.i] = await chargerImage(c.url)); dessinerSource(cx, im, 360, 640, 1); }
      var blob = await new Promise(function (ok) { cv.toBlob(ok, 'image/jpeg', .85); });
      out.push({ blob: blob, url: URL.createObjectURL(blob) });
      if (c.type === 'image' && S.clips.length === 1) break; // une seule photo : une seule couverture suffit
    }
    return out;
  }

  /* ---------------- rendu final (montage cuit dans la vidéo) ---------------- */
  function prog(p, t) { $('#ecProgB').style.width = Math.round(p * 100) + '%'; $('#ecProgP').textContent = Math.round(p * 100) + ' %'; if (t) $('#ecProgT').textContent = t; }
  async function rendreVideo(onP) {
    var Wd = 720, Hd = 1280, cv = D.createElement('canvas'); cv.width = Wd; cv.height = Hd; var cx = cv.getContext('2d');
    var AC = W.AudioContext || W.webkitAudioContext, ac = new AC(); try { await ac.resume(); } catch (e) {}
    var dest = ac.createMediaStreamDestination(), total = dureeTotale(), src = null;
    if (S.music) {
      try { var ab = await (await fetch(await urlSon(S.music))).arrayBuffer(); var buf = await ac.decodeAudioData(ab); src = ac.createBufferSource(); src.buffer = buf; src.loop = true; var gm = ac.createGain(); gm.gain.value = S.volMusic; src.connect(gm); gm.connect(dest); }
      catch (e) { src = null; toast('⚠️ Ce son ne peut pas être intégré, publication sans musique', 'info'); }
    }
    var flux = cv.captureStream(30); dest.stream.getAudioTracks().forEach(function (t) { flux.addTrack(t); });
    var mt = choisirMime(), chunks = [], rec;
    try { rec = new MediaRecorder(flux, mt ? { mimeType: mt, videoBitsPerSecond: 2500000, audioBitsPerSecond: 128000 } : undefined); } catch (e) { rec = new MediaRecorder(flux); }
    rec.ondataavailable = function (ev) { if (ev.data && ev.data.size) chunks.push(ev.data); };
    var fini = new Promise(function (ok) { rec.onstop = ok; });
    rec.start(500); if (src) src.start(0);
    var t0 = performance.now();
    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i], d = dureeClip(c);
      if (c.type === 'video') {
        var v = await chargerVideo(c.url); v.muted = false;
        try { var ms = ac.createMediaElementSource(v), gv = ac.createGain(); gv.gain.value = S.volOrig; ms.connect(gv); gv.connect(dest); } catch (e) {}
        await chercher(v, c.start); var debut = performance.now();
        try { await v.play(); } catch (e) { v.muted = true; try { await v.play(); } catch (e2) {} }
        await new Promise(function (ok) {
          (function f() {
            dessinerSource(cx, v, Wd, Hd, 1); var el = (performance.now() - debut) / 1000;
            onP(Math.min(1, (performance.now() - t0) / 1000 / total));
            if (v.ended || v.currentTime >= c.end - .04 || el > d + 1.5) { v.pause(); return ok(); }
            requestAnimationFrame(f);
          })();
        });
      } else {
        var im = await chargerImage(c.url), deb = performance.now();
        await new Promise(function (ok) {
          (function f() {
            var el = (performance.now() - deb) / 1000; dessinerSource(cx, im, Wd, Hd, 1 + .06 * Math.min(1, el / d));
            onP(Math.min(1, (performance.now() - t0) / 1000 / total));
            if (el >= d) return ok(); requestAnimationFrame(f);
          })();
        });
      }
    }
    rec.stop(); try { if (src) src.stop(); } catch (e) {} await fini; try { ac.close(); } catch (e) {}
    return { blob: new Blob(chunks, { type: (rec.mimeType || mt || 'video/webm').split(';')[0] }), type: 'video' };
  }
  function aDesModifs() { return S.filtre !== 0 || S.textes.length > 0 || !!S.music; }
  async function fabriquer(onP) {
    var un = S.clips.length === 1 ? S.clips[0] : null;
    if (un && !aDesModifs()) {
      if (un.type === 'image') return { blob: un.blob, type: 'image', nom: 'photo.jpg' };
      if (un.start < .15 && un.end >= un.dur - .25) return { blob: un.blob, type: 'video', nom: 'video.' + extMime(un.blob.type), direct: true };
    }
    if (un && un.type === 'image' && !S.music) {
      var cv = D.createElement('canvas'); cv.width = 1080; cv.height = 1920; var im = await chargerImage(un.url); dessinerSource(cv.getContext('2d'), im, 1080, 1920, 1);
      var b = await new Promise(function (ok) { cv.toBlob(ok, 'image/jpeg', .9); }); return { blob: b, type: 'image', nom: 'photo.jpg' };
    }
    var r = await rendreVideo(onP); r.nom = 'video.' + extMime(r.blob.type); return r;
  }

  /* ---------------- publication ---------------- */
  async function publier() {
    if (S.enCours) return; var u = await getUser();
    if (!u) { toast('⚠️ Connecte-toi d\'abord', 'error'); return; }
    if (!S.clips.length) { toast('Ajoute au moins une vidéo ou une photo', 'error'); return; }
    var desc = $('#ecDesc').value.trim(); S.desc = desc;
    S.enCours = true; $('#ecPub').disabled = true; $('#ecProg').classList.add('on'); prog(0, '🎬 Montage de ta vidéo…');
    try { stopPrev(); musicEl.pause(); $('#ecEV').pause(); } catch (e) {}
    var verrou = null; try { if (navigator.wakeLock) verrou = await navigator.wakeLock.request('screen'); } catch (e) {}
    try {
      var sortie = await fabriquer(function (p) { prog(p * .6, '🎬 Montage de ta vidéo…'); });
      prog(.6, '☁️ Envoi en cours…');
      var fichier = new File([sortie.blob], sortie.nom, { type: sortie.blob.type });
      var url = await uploadFichier(fichier, { cote: 1600 });
      prog(.88, '🖼️ Couverture…'); var coverUrl = null;
      if (sortie.type === 'video') {
        var cb = S.coverBlob || (S.covers[S.coverIdx] && S.covers[S.coverIdx].blob) || (S.covers[0] && S.covers[0].blob);
        if (cb) { try { coverUrl = await uploadFichier(new File([cb], 'cover.jpg', { type: 'image/jpeg' }), { cote: 720 }); } catch (e) { coverUrl = null; } }
      }
      prog(.96, '✅ Publication…');
      var nom = u.Psuedo || 'Gameur', son = S.music ? S.music.titre : '';
      if (S.dest === 'story') {
        await EvoDB.create(COLLECTIONS.STATUTS, EvoDB.newId(), { User_id: u.id, Psuedo: nom, Media_url: url, Media_type: sortie.type, Texte: desc.slice(0, 500), Cover_url: coverUrl || '', Son_titre: son });
      } else {
        await EvoDB.create(COLLECTIONS.POSTS, EvoDB.newId(), { User_id: u.id, Psuedo: nom, Contenu: desc, Media_url: url, Media_type: sortie.type, Cover_url: coverUrl || '', Son_titre: son, Visibilite: S.visib, Comm_ok: S.comm, Likes: 0, Comment: 0 });
      }
      if (S.draftId) { try { await dbDel(S.draftId); } catch (e) {} }
      try { if (verrou) verrou.release(); } catch (e) {}
      prog(1, '🎉 C\'est publié !'); NAT.haptic('heavy'); await attendre(700);
      var dest = S.dest; S.enCours = false; $('#ecProg').classList.remove('on'); fermer(false);
      toast(dest === 'story' ? '✅ Story publiée !' : '✅ Publié !', 'success');
      var surSocial = /saucial\.html/i.test(location.pathname);
      if (surSocial) { try { if (W.chargerPosts) W.chargerPosts(); if (W.chargerStatuts) W.chargerStatuts(); } catch (e) {} }
      else setTimeout(function () { location.href = 'saucial.html'; }, 700);
    } catch (e) {
      try { if (verrou) verrou.release(); } catch (x) {}
      console.error('Publication :', e); S.enCours = false; $('#ecProg').classList.remove('on'); $('#ecPub').disabled = false;
      toast('❌ ' + ((e && e.message) || 'Publication impossible'), 'error');
    }
  }

  /* ---------------- brouillons ---------------- */
  async function sauverBrouillon(quitter) {
    if (!S || !S.clips.length) { toast('Rien à enregistrer', 'info'); return; }
    var id = S.draftId || 'd' + Date.now();
    var m = S.music ? { id: S.music.id, titre: S.music.titre, artiste: S.music.artiste, cover: S.music.cover, blob: S.music.blob || null, url: S.music.blob || S.music.recette ? '' : S.music.url } : null;
    try {
      await dbPut({ id: id, date: Date.now(), dest: S.dest, desc: $('#ecDesc') ? $('#ecDesc').value : S.desc, filtre: S.filtre, textes: S.textes, volOrig: S.volOrig, volMusic: S.volMusic, visib: S.visib, comm: S.comm, music: m,
        clips: S.clips.map(function (c) { return { type: c.type, blob: c.blob, dur: c.dur, start: c.start, end: c.end, fichier: !!c.fichier }; }) });
      toast('📁 Brouillon enregistré', 'success'); if (quitter) { fermerSheet(); fermer(false); }
    } catch (e) { toast('❌ Impossible d\'enregistrer le brouillon', 'error'); }
  }
  async function ouvrirBrouillons() {
    var l = await dbTous();
    sheet('Brouillons', l.length ? l.map(function (d) {
      var c = d.clips[0], u = c ? URL.createObjectURL(c.blob) : '';
      return '<div class="ec-dd"><div data-act="brRestaurer" data-id="' + d.id + '" style="display:flex;gap:12px;align-items:center;flex:1;cursor:pointer">' + (c && c.type === 'video' ? '<video src="' + u + '#t=0.2" muted playsinline></video>' : '<img src="' + u + '" alt="">') +
        '<div>' + (d.clips.length) + ' clip' + (d.clips.length > 1 ? 's' : '') + '<small>' + new Date(d.date).toLocaleString('fr-FR') + '</small><small>' + esc((d.desc || '').slice(0, 40)) + '</small></div></div><button data-act="brSuppr" data-id="' + d.id + '" style="padding:8px;font-size:1.1rem">🗑</button></div>';
    }).join('') : '<div style="padding:26px;text-align:center;color:#9aa3b8">Aucun brouillon pour l\'instant</div>');
  }
  async function restaurerBrouillon(id) {
    var l = await dbTous(), d = l.filter(function (x) { return x.id === id; })[0]; if (!d) return;
    S.draftId = d.id; S.dest = d.dest || 'post'; S.desc = d.desc || ''; S.filtre = d.filtre || 0; S.textes = d.textes || []; S.volOrig = d.volOrig == null ? 1 : d.volOrig; S.volMusic = d.volMusic == null ? .8 : d.volMusic; S.visib = d.visib || 'tous'; S.comm = d.comm !== false;
    S.clips = d.clips.map(function (c) { return { type: c.type, blob: c.blob, url: URL.createObjectURL(c.blob), dur: c.dur, start: c.start || 0, end: c.end || c.dur, fichier: c.fichier }; });
    S.music = null;
    if (d.music) {
      var r = RECETTES.filter(function (x) { return x.id === d.music.id; })[0];
      if (r) S.music = { id: r.id, titre: r.t, artiste: 'EVO Beats · intégré', cover: coverSvg(r.c, r.e), recette: r };
      else if (d.music.blob) S.music = { id: d.music.id, titre: d.music.titre, artiste: d.music.artiste, cover: d.music.cover, url: URL.createObjectURL(d.music.blob), blob: d.music.blob };
      else if (d.music.url) S.music = { id: d.music.id, titre: d.music.titre, artiste: d.music.artiste, cover: d.music.cover, url: d.music.url, distant: true };
    }
    fermerSheet(); S.sel = 0; pushEcran('edit');
  }

  /* ---------------- actions (boutons) ---------------- */
  var A = {
    fermer: function () { demanderFermer(); },
    popEcran: function () { popEcran(); },
    sheetX: function () { fermerSheet(); },
    sheetBg: function () { fermerSheet(); },
    quitterSans: function () { fermerSheet(); fermer(false); },
    sauvQuitter: function () { sauverBrouillon(true); },
    flip: function () { S.face = S.face === 'user' ? 'environment' : 'user'; demarrerCam(); },
    torch: async function () {
      try { var t = S.stream.getVideoTracks()[0]; S.torch = !S.torch; await t.applyConstraints({ advanced: [{ torch: S.torch }] }); $('#ecTorch').classList.toggle('on', S.torch); }
      catch (e) { S.torch = false; toast('⚡ Flash indisponible sur cette caméra', 'info'); }
    },
    minuteur: function () { S.minuteur = S.minuteur === 0 ? 3 : S.minuteur === 3 ? 10 : 0; $('#ecMin').classList.toggle('on', S.minuteur > 0); $('#ecMin').lastChild.textContent = S.minuteur ? S.minuteur + ' s' : 'Minuteur'; },
    filtcam: function () { $('#ecFiltCam').classList.toggle('on'); if ($('#ecFiltCam').dataset.ok) return; $('#ecFiltCam').dataset.ok = 1; $('#ecFiltCam').innerHTML = FILTRES.map(function (f, i) { return '<button data-act="filtre" data-i="' + i + '" class="' + (i === 0 ? 'on' : '') + '"><b style="filter:' + f.c + '"></b>' + f.n + '</button>'; }).join(''); },
    filtre: function (el) {
      S.filtre = parseInt(el.dataset.i, 10); var f = FILTRES[S.filtre].c;
      root.querySelectorAll('[data-act="filtre"]').forEach(function (b) { b.classList.toggle('on', parseInt(b.dataset.i, 10) === S.filtre); });
      $('#ecCamV').style.filter = f; $('#ecEV').style.filter = $('#ecEI').style.filter = f;
    },
    rec: function () { lancerRec(); },
    camOk: function () { if (S.clips.length) { S.sel = 0; pushEcran('edit'); } },
    undoClip: function () { var c = S.clips.pop(); if (c) { try { URL.revokeObjectURL(c.url); } catch (e) {} } majCamClips(); },
    importer: function () { inpMedia.click(); },
    galCam: function () { if (S.stack.length) popEcran(); else montrer('cam'); },
    galTexte: function () { creerClipTexte(); },
    multi: function () { S.multi = !S.multi; if (!S.multi && S.selOrdre.length > 1) S.selOrdre = [S.selOrdre[0]]; dessinerGrille(); },
    tuile: function (el) {
      var id = el.dataset.id, i = S.selOrdre.indexOf(id);
      if (S.multi) { if (i >= 0) S.selOrdre.splice(i, 1); else if (S.selOrdre.length < 10) S.selOrdre.push(id); else toast('10 clips maximum', 'info'); }
      else S.selOrdre = i >= 0 ? [] : [id];
      dessinerGrille();
    },
    galNext: function () { if (!S.selOrdre.length) return; var avant = S.clips.length; clipsDepuisPool(); S.sel = avant; var e = S.stack.pop(); if (e) { e.off(); if (e.prev === 'edit') { montrer('edit'); return; } S.ecran = e.prev; } pushEcran('edit'); },
    playpause: function () { var v = $('#ecEV'); if (S.clips[S.sel] && S.clips[S.sel].type === 'video') { if (v.paused) { v.play(); jouerMusique(); } else { v.pause(); musicEl.pause(); } } else { if (musicEl.paused) jouerMusique(); else musicEl.pause(); } },
    clip: function (el, e) { if (e.target.closest('[data-act="clipDel"]')) return; montrerClip(parseInt(el.dataset.i, 10), true); },
    clipDel: function (el, e) { e.stopPropagation(); var i = parseInt(el.dataset.i, 10); S.clips.splice(i, 1); montrerClip(Math.max(0, i - 1), true); },
    texte: function () { ouvrirTexte(); },
    txBg: function () { txEd.fond = !txEd.fond; toast(txEd.fond ? 'Fond activé' : 'Fond désactivé', 'info'); },
    txOk: function () {
      var v = $('#ecTxIn').value.trim(); $('#ecTxEd').classList.remove('on');
      if (txEd.cible) { if (v) { txEd.cible.txt = v; txEd.cible.couleur = txEd.couleur; txEd.cible.fond = txEd.fond; } else S.textes.splice(S.textes.indexOf(txEd.cible), 1); }
      else if (v) S.textes.push({ txt: v, x: .5, y: .45, couleur: txEd.couleur, fond: txEd.fond, taille: 28 });
      dessinerTextes();
    },
    txDel: function () { $('#ecTxEd').classList.remove('on'); if (txEd.cible) { S.textes.splice(S.textes.indexOf(txEd.cible), 1); dessinerTextes(); } },
    panel: function (el) { var p = el.dataset.p; S.panel = S.panel === p ? '' : p; dessinerPanel(); },
    sons: function () { ouvrirSons(); },
    audioFichier: function () { inpAudio.click(); },
    sonRetirer: function () { S.music = null; musicEl.pause(); fermerSheet(); majPillSon(); },
    sonPrev: async function (el) {
      var id = el.dataset.id; if (!prevAudio.paused && prevAudio.dataset.id === id) { prevAudio.pause(); majPlayBtns(null); return; }
      var s = SONS_LISTE.filter(function (x) { return x.id === id; })[0]; if (!s) return; el.textContent = '…';
      try { prevAudio.src = await urlSon(s); prevAudio.dataset.id = id; await prevAudio.play(); majPlayBtns(id); } catch (e) { majPlayBtns(null); toast('Lecture impossible', 'error'); }
    },
    sonUse: async function (el) {
      var s = SONS_LISTE.filter(function (x) { return x.id === el.dataset.id; })[0]; if (!s) return; el.textContent = '…';
      try { await urlSon(s); utiliserSon(s); } catch (e) { toast('Son indisponible', 'error'); }
    },
    editNext: function () { if (!S.clips.length) return; S.panel = ''; dessinerPanel(); pushEcran('post'); },
    cover: function () {
      if (!S.covers.length && !S.coverBlob) { toast('Aperçu en préparation…', 'info'); }
      sheet('Choisir la couverture', '<div class="ec-cg">' + S.covers.map(function (c, i) { return '<button data-act="coverPick" data-i="' + i + '" class="' + (i === S.coverIdx ? 'on' : '') + '"><img src="' + c.url + '" alt=""></button>'; }).join('') + '</div>' +
        '<button data-act="coverFichier" style="width:100%;margin-top:12px;padding:13px;border-radius:12px;background:#ffffff18;font-weight:800">🖼️ Choisir dans la galerie</button>');
    },
    coverPick: function (el) { S.coverIdx = parseInt(el.dataset.i, 10); S.coverBlob = null; $('#ecCovImg').src = S.covers[S.coverIdx].url; fermerSheet(); },
    coverFichier: function () { inpCover.click(); },
    visib: function () {
      sheet('Qui peut voir cette publication ?', Object.keys(VIS).map(function (k) { return '<button class="ec-li" data-act="visibPick" data-k="' + k + '"><span>' + VIS[k] + '</span><b>' + (S.visib === k ? '✓' : '') + '</b></button>'; }).join(''));
    },
    visibPick: function (el) { S.visib = el.dataset.k; $('#ecVisLbl').textContent = VIS[S.visib]; fermerSheet(); },
    brouillon: function () { sauverBrouillon(false); },
    brouillons: function () { ouvrirBrouillons(); },
    brRestaurer: function (el) { restaurerBrouillon(el.dataset.id); },
    brSuppr: async function (el) { await dbDel(el.dataset.id); ouvrirBrouillons(); },
    publier: function () { publier(); }
  };

  /* ---------------- bouton « + » flottant + ouverture par lien ---------------- */
  function fab() {
    if (W.EVO_NO_FAB || D.getElementById('evoFab')) return;
    var b = D.createElement('button'); b.id = 'evoFab'; b.setAttribute('aria-label', 'Créer'); b.textContent = '+'; b.onclick = function () { ouvrir(); };
    D.body.appendChild(b);
  }
  function init() {
    injecterCss(); fab();
    if (/[?&]create=1/.test(location.search)) setTimeout(function () { ouvrir(); }, 700);
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', init); else init();

  W.EvoCreer = { open: ouvrir, close: function () { if (S) fermer(false); }, drafts: ouvrirBrouillons };
})();
