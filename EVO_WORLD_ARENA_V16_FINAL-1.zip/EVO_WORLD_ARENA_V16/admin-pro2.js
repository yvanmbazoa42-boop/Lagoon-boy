// EVO ARENA — outils admin v14 : 🎨 FOND (fond animé par défaut du site), 🔧 MAINTENANCE, 👥 JOUEURS (solde, blocage), 🧾 JOURNAL
// Chargé après admin-pro.js. Tout est écrit côté admin ; chaque action sensible est inscrite dans le journal (collection admin_logs).
(function () {
  'use strict';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(m, t) { try { showToast(m, t || 'info'); } catch (e) {} }
  function fmt(n) { return (Number(n) || 0).toLocaleString('fr-FR'); }
  var tabs = document.querySelector('.tabs'); if (!tabs) return;
  var apres = document.getElementById('payout') || tabs.nextElementSibling;

  function onglet(id, libelle, html, ouverture) {
    var t = document.createElement('div'); t.className = 'tab'; t.textContent = libelle;
    t.onclick = function (ev) { openTab(id, ev); if (ouverture) ouverture(); };
    tabs.appendChild(t);
    var c = document.createElement('div'); c.id = id; c.className = 'tab-content'; c.innerHTML = html;
    (apres && apres.parentNode ? apres.parentNode : document.body).appendChild(c);
  }
  async function ecrireConfig(id, data) {
    try { await EvoDB.update('Config', id, data); } catch (e) { await EvoDB.create('Config', id, data); }
  }
  async function journal(action, cible, detail) {
    try {
      var adm = (typeof adminUserId !== 'undefined' && adminUserId) ? adminUserId : '';
      await EvoDB.create('admin_logs', EvoDB.newId(), { Admin: adm, Action: String(action).slice(0, 60), Cible: String(cible || '').slice(0, 80), Detail: String(detail || '').slice(0, 300), Date: new Date().toISOString() });
    } catch (e) { /* le journal ne doit jamais bloquer l'action */ }
  }

  var st = document.createElement('style');
  st.textContent = '.fond-grille{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}.fond-opt{display:flex;align-items:center;gap:8px;padding:12px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid transparent;color:#e0f2fe;font-weight:700;font-size:.8rem;cursor:pointer;font-family:inherit}.fond-opt.actif{border-color:var(--c1,#00ff88);background:rgba(var(--c1-rgb,0,255,136),.14)}' +
    '.jr-ligne{background:rgba(255,255,255,.04);border-radius:10px;padding:10px;margin:6px 0;font-size:.74rem;color:#cbd5e1}.jr-ligne b{color:var(--c1,#00ff88)}.jr-ligne small{display:block;color:#64748b;margin-top:2px}' +
    '.jo-ligne{background:rgba(255,255,255,.04);border-radius:12px;padding:10px;margin:8px 0}.jo-ligne .nom{font-weight:800;color:#e0f2fe}.jo-ligne .meta{color:#94a3b8;font-size:.68rem;margin:3px 0 8px}.jo-btns{display:flex;gap:6px;flex-wrap:wrap}.jo-btns button{flex:1 1 30%;padding:8px 4px;border-radius:8px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#e0f2fe;font-size:.68rem;font-weight:700;cursor:pointer;font-family:inherit}.jo-btns .danger{color:#f87171;border-color:rgba(248,113,113,.4)}';
  document.head.appendChild(st);

  // ------------------------------------------------------------ 🎨 FOND
  var fondChoisi = 'aucun';
  function rendreFonds() {
    var z = document.getElementById('fondGrille'); if (!z || !window.EvoFonds) return;
    z.innerHTML = Object.keys(EvoFonds.liste).map(function (id) {
      var f = EvoFonds.liste[id];
      return '<button type="button" class="fond-opt' + (id === fondChoisi ? ' actif' : '') + '" data-f="' + id + '">' + f.ico + ' ' + esc(f.nom) + '</button>';
    }).join('');
  }
  async function chargerFond() {
    try { var d = await EvoDB.get('Config', 'fond'); fondChoisi = (window.EvoFonds && EvoFonds.liste[d.Id]) ? d.Id : 'aucun'; } catch (e) { fondChoisi = 'aucun'; }
    rendreFonds();
    var e = document.getElementById('fondEtat'); if (e) e.textContent = 'Fond actuel pour tous les joueurs : ' + ((window.EvoFonds && EvoFonds.liste[fondChoisi]) ? EvoFonds.liste[fondChoisi].nom : 'Aucun');
  }
  onglet('fondSite', '🎨 FOND',
    '<div class="section"><h2>🎨 FOND ANIMÉ DU SITE</h2><div class="info-box">Choisis le fond affiché par défaut chez tous les joueurs. Un joueur qui a choisi son propre fond dans ⚙️ Paramètres garde le sien. Touche un fond pour l\'essayer ici, puis publie.</div>' +
    '<div class="fond-grille" id="fondGrille"></div>' +
    '<button class="pro-btn" type="button" id="fondPublier">✅ PUBLIER POUR TOUS</button>' +
    '<div id="fondEtat" style="color:#94a3b8;font-size:.72rem;margin-top:8px"></div></div>', chargerFond);
  document.getElementById('fondGrille').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-f]') : null; if (!b) return;
    fondChoisi = b.getAttribute('data-f'); rendreFonds(); if (window.EvoFonds) EvoFonds.apercu(fondChoisi);
  });
  document.getElementById('fondPublier').onclick = async function () {
    try { await ecrireConfig('fond', { Id: fondChoisi }); await journal('Fond du site', 'Config/fond', fondChoisi); toast('✅ Fond publié pour tous les joueurs', 'success'); chargerFond(); }
    catch (e) { toast('❌ ' + (e.message || 'Erreur (règles Firestore publiées ?)'), 'error'); }
  };

  // ------------------------------------------------------------ 🔧 MAINTENANCE
  onglet('maintenance', '🔧 MAINTENANCE',
    '<div class="section"><h2>🔧 MODE MAINTENANCE</h2><div class="info-box">Affiche un écran « maintenance » sur les pages joueur (pratique pendant une mise à jour ou une vérification de paiements). L\'admin reste accessible. C\'est un blocage d\'affichage, pas une sécurité serveur.</div>' +
    '<textarea id="mtMessage" maxlength="200" rows="2" class="pro-field" placeholder="Message affiché (ex : Retour dans 30 minutes)" style="padding:10px;border-radius:8px;background:rgba(var(--bg-rgb,5,5,16),.8);border:1px solid rgba(var(--c1-rgb,0,255,136),.3);color:#e0f2fe;width:100%;font-family:inherit"></textarea>' +
    '<button class="pro-btn" type="button" id="mtOn">🔧 ACTIVER LA MAINTENANCE</button>' +
    '<button class="pro-btn sec" type="button" id="mtOff">✅ REMETTRE LE SITE EN LIGNE</button>' +
    '<div id="mtEtat" style="color:#94a3b8;font-size:.72rem;margin-top:8px"></div></div>',
    async function () {
      var e = document.getElementById('mtEtat');
      try { var d = await EvoDB.get('Config', 'maintenance'); e.textContent = d.Actif ? '🔧 Maintenance ACTIVE' : '✅ Site en ligne'; document.getElementById('mtMessage').value = d.Message || ''; }
      catch (x) { e.textContent = '✅ Site en ligne'; }
    });
  async function mt(actif) {
    var msg = document.getElementById('mtMessage').value.trim().slice(0, 200);
    if (actif && !confirm('Activer la maintenance ? Les joueurs ne pourront plus utiliser le site.')) return;
    try { await ecrireConfig('maintenance', { Actif: actif, Message: msg }); await journal(actif ? 'Maintenance ON' : 'Maintenance OFF', 'Config/maintenance', msg); document.getElementById('mtEtat').textContent = actif ? '🔧 Maintenance ACTIVE' : '✅ Site en ligne'; toast(actif ? '🔧 Maintenance activée' : '✅ Site remis en ligne', 'success'); }
    catch (e) { toast('❌ ' + (e.message || 'Erreur'), 'error'); }
  }
  document.getElementById('mtOn').onclick = function () { mt(true); };
  document.getElementById('mtOff').onclick = function () { mt(false); };

  // ------------------------------------------------------------ 👥 JOUEURS
  var joueurs = [];
  onglet('joueursPro', '👥 JOUEURS',
    '<div class="section"><h2>👥 GÉRER LES JOUEURS</h2><input id="joRech" class="pro-field" placeholder="🔎 Pseudo, téléphone ou WhatsApp…">' +
    '<button class="pro-btn" type="button" id="joChercher">🔎 CHERCHER</button><div id="joZone"></div></div>', null);
  function rendreJoueurs() {
    var q = document.getElementById('joRech').value.trim().toLowerCase();
    var l = joueurs.filter(function (j) { return !q || [j.Psuedo, j.Tel, j.WhatsApp, j.Email].some(function (v) { return String(v || '').toLowerCase().indexOf(q) >= 0; }); }).slice(0, 25);
    document.getElementById('joZone').innerHTML = l.length ? l.map(function (j) {
      var banni = j.Statut === 'banni';
      return '<div class="jo-ligne"><div class="nom">' + esc(j.Psuedo || '—') + (banni ? ' 🚫' : '') + '</div><div class="meta">💰 ' + fmt(j.Solde) + ' FCFA · 🏆 ' + (j.Match_gagnes || 0) + ' V · ❤️ ' + (j.Vies == null ? '—' : j.Vies) + ' · ' + esc(j.Tel || j.WhatsApp || '') + '</div>' +
        '<div class="jo-btns"><button data-a="plus" data-id="' + esc(j.id) + '">➕ Solde</button><button data-a="moins" data-id="' + esc(j.id) + '">➖ Solde</button>' +
        '<button class="' + (banni ? '' : 'danger') + '" data-a="ban" data-id="' + esc(j.id) + '">' + (banni ? '✅ Débloquer' : '🚫 Bloquer') + '</button></div></div>';
    }).join('') : '<div style="color:#555;text-align:center;padding:12px">Aucun joueur trouvé</div>';
  }
  async function chercher() {
    var z = document.getElementById('joZone'); z.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:12px">Chargement…</div>';
    try { var r = await EvoDB.list(COLLECTIONS.PLAYERS, [Q.limit(1000)]); joueurs = r.documents || []; await fusionnerContacts(joueurs); rendreJoueurs(); }
    catch (e) { z.innerHTML = '<div style="color:#f59e0b;text-align:center;padding:12px">⚠️ ' + esc(e.message || 'Erreur') + '</div>'; }
  }
  document.getElementById('joChercher').onclick = chercher;
  document.getElementById('joRech').addEventListener('keydown', function (e) { if (e.key === 'Enter') chercher(); });
  document.getElementById('joZone').addEventListener('click', async function (e) {
    var b = e.target.closest ? e.target.closest('[data-a]') : null; if (!b) return;
    var id = b.getAttribute('data-id'), a = b.getAttribute('data-a'), j = joueurs.find(function (x) { return x.id === id; }); if (!j) return;
    try {
      if (a === 'plus' || a === 'moins') {
        var m = parseInt(prompt((a === 'plus' ? 'Ajouter' : 'Retirer') + ' combien de FCFA au solde de ' + (j.Psuedo || '') + ' ?'), 10);
        if (!(m > 0) || m > 5000000) { if (!isNaN(m)) toast('⚠️ Montant invalide', 'error'); return; }
        var motif = (prompt('Motif (obligatoire, inscrit dans le journal) :') || '').trim();
        if (motif.length < 3) { toast('⚠️ Motif obligatoire', 'error'); return; }
        var d = a === 'plus' ? m : -m;
        if (!confirm((d > 0 ? '+' : '') + fmt(d) + ' FCFA pour ' + (j.Psuedo || '') + ' ?\nMotif : ' + motif)) return;
        await EvoDB.update(COLLECTIONS.PLAYERS, id, { Solde: firebase.firestore.FieldValue.increment(d) });
        j.Solde = (j.Solde || 0) + d;
        await journal('Solde ' + (d > 0 ? '+' : '') + d, (j.Psuedo || id), motif);
        toast('✅ Solde mis à jour', 'success');
      } else if (a === 'ban') {
        var banni = j.Statut === 'banni';
        if (!confirm((banni ? 'Débloquer ' : 'Bloquer ') + (j.Psuedo || '') + ' ?')) return;
        await EvoDB.update(COLLECTIONS.PLAYERS, id, { Statut: banni ? 'actif' : 'banni' });
        j.Statut = banni ? 'actif' : 'banni';
        await journal(banni ? 'Débloquer joueur' : 'Bloquer joueur', (j.Psuedo || id), '');
        toast(banni ? '✅ Joueur débloqué' : '🚫 Joueur bloqué', 'success');
      }
      rendreJoueurs();
    } catch (er) { toast('❌ ' + (er.message || 'Erreur'), 'error'); }
  });

  // ------------------------------------------------------------ 🧾 JOURNAL
  onglet('journalAdmin', '🧾 JOURNAL',
    '<div class="section"><h2>🧾 JOURNAL DES ACTIONS ADMIN</h2><div class="info-box">Les 50 dernières actions sensibles (soldes, blocages, maintenance, fond). Non modifiable.</div>' +
    '<button class="pro-btn" type="button" id="jrAct">🔄 ACTUALISER</button><div id="jrZone"></div></div>', chargerJournal);
  async function chargerJournal() {
    var z = document.getElementById('jrZone'); z.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:12px">Chargement…</div>';
    try {
      var r = await EvoDB.list('admin_logs', [Q.orderDesc('createdAt'), Q.limit(50)]);
      z.innerHTML = (r.documents || []).map(function (l) {
        return '<div class="jr-ligne"><b>' + esc(l.Action) + '</b> — ' + esc(l.Cible) + (l.Detail ? '<br>' + esc(l.Detail) : '') + '<small>' + esc(new Date(l.Date || l.createdAt).toLocaleString('fr-FR')) + '</small></div>';
      }).join('') || '<div style="color:#555;text-align:center;padding:12px">Aucune action enregistrée</div>';
    } catch (e) { z.innerHTML = '<div style="color:#f59e0b;text-align:center;padding:12px">⚠️ ' + esc(e.message || 'Erreur (règles Firestore publiées ?)') + '</div>'; }
  }
  document.getElementById('jrAct').onclick = chargerJournal;
})();
