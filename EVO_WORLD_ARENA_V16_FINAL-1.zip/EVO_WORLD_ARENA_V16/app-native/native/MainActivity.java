package com.evoarena.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(EvoScreenCastPlugin.class);   // plugin « diffusion d'écran »
        super.onCreate(savedInstanceState);
    }
}
