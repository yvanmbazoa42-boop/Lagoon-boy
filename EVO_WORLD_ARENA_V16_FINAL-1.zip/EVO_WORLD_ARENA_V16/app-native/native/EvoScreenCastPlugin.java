package com.evoarena.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Plugin Capacitor « EvoScreenCast » : demande l'autorisation Android de capturer l'écran,
 * puis lance ScreenCastService qui envoie l'écran en RTMPS vers Cloudflare Stream.
 *
 * JS : Capacitor.Plugins.EvoScreenCast.start({ url, orientation: 'paysage'|'portrait', kbps, fps })
 *      .stop()  .etat()  et l'événement « etat » : { etat: 'connexion'|'connecte'|'echec'|'arrete', message }
 */
@CapacitorPlugin(name = "EvoScreenCast")
public class EvoScreenCastPlugin extends Plugin {

    @Override
    public void load() {
        ScreenCastService.ecouteur = (etat, message) -> {
            JSObject o = new JSObject();
            o.put("etat", etat);
            o.put("message", message == null ? "" : message);
            notifyListeners("etat", o);
        };
    }

    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url", "");
        if (url == null || !(url.startsWith("rtmps://") || url.startsWith("rtmp://"))) {
            call.reject("Adresse de diffusion invalide");
            return;
        }
        if (ScreenCastService.enCours) {
            call.reject("La diffusion est déjà en cours");
            return;
        }
        // mémorise les réglages pour le service (démarré après l'accord du joueur)
        ScreenCastService.url = url;
        ScreenCastService.paysage = !"portrait".equals(call.getString("orientation", "paysage"));
        ScreenCastService.kbps = call.getInt("kbps", 1200);
        ScreenCastService.fps = call.getInt("fps", 25);
        MediaProjectionManager m = (MediaProjectionManager) getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call, m.createScreenCaptureIntent(), "resultatProjection");
    }

    @ActivityCallback
    private void resultatProjection(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("Autorisation de capture refusée");
            return;
        }
        Intent i = new Intent(getContext(), ScreenCastService.class);
        i.putExtra("code", result.getResultCode());
        i.putExtra("data", result.getData());
        ContextCompat.startForegroundService(getContext(), i);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent i = new Intent(getContext(), ScreenCastService.class);
        i.setAction(ScreenCastService.ACTION_STOP);
        getContext().startService(i);
        call.resolve();
    }

    @PluginMethod
    public void etat(PluginCall call) {
        JSObject o = new JSObject();
        o.put("etat", ScreenCastService.etat);
        o.put("enCours", ScreenCastService.enCours);
        call.resolve(o);
    }
}
