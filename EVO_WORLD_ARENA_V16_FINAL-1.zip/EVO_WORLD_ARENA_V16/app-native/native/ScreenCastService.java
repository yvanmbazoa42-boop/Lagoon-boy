package com.evoarena.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.pedro.common.ConnectChecker;
import com.pedro.library.rtmp.RtmpDisplay;

/**
 * Service au premier plan (obligatoire sur Android 10+ pour capturer l'écran).
 * Capture l'écran avec MediaProjection et l'envoie en RTMP(S) grâce à la bibliothèque RootEncoder.
 * Une notification permanente (avec bouton « Arrêter ») reste visible pendant toute la diffusion.
 */
public class ScreenCastService extends Service implements ConnectChecker {

    public interface Ecouteur { void surEtat(String etat, String message); }

    static final String ACTION_STOP = "com.evoarena.app.STOP_CAST";
    private static final String CANAL = "evo_cast";
    private static final int NOTIF_ID = 4242;

    // réglages transmis par le plugin
    static volatile String url = "";
    static volatile boolean paysage = true;
    static volatile int kbps = 1200, fps = 25;
    // état partagé avec le plugin
    static volatile boolean enCours = false;
    static volatile String etat = "arrete";
    static volatile Ecouteur ecouteur = null;

    private RtmpDisplay display;

    private static void annoncer(String e, String msg) {
        etat = e;
        Ecouteur l = ecouteur;
        if (l != null) { try { l.surEtat(e, msg); } catch (Exception ignore) { } }
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            arreter("arrete", "");
            return START_NOT_STICKY;
        }
        if (intent == null || enCours) return START_NOT_STICKY;

        // 1) le service passe au premier plan AVANT d'utiliser la projection (obligatoire Android 14)
        creerCanal();
        Intent stop = new Intent(this, ScreenCastService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, CANAL)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("EVO ARENA : ton écran est diffusé")
                .setContentText("Touche « Arrêter » pour couper la diffusion")
                .setOngoing(true)
                .addAction(0, "Arrêter", pi)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIF_ID, n);

        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            if (data == null) throw new IllegalStateException("autorisation de capture absente");

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = paysage ? 1280 : 720, h = paysage ? 720 : 1280;

            display = new RtmpDisplay(this, true, this);
            display.setIntentResult(code, data);
            boolean video = display.prepareVideo(w, h, fps, kbps * 1000, 0, dm.densityDpi);
            if (!video) throw new IllegalStateException("encodeur vidéo indisponible sur ce téléphone");
            // son : seulement si le micro est autorisé, et coupé (muet) par défaut
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                if (display.prepareAudio(64 * 1024, 32000, true)) display.disableAudio();
            }
            enCours = true;
            annoncer("connexion", "");
            display.startStream(url);
        } catch (Exception e) {
            arreter("echec", String.valueOf(e.getMessage()));
        }
        return START_NOT_STICKY;
    }

    private void creerCanal() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CANAL, "Diffusion d'écran", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private void arreter(String nouvelEtat, String message) {
        try { if (display != null && display.isStreaming()) display.stopStream(); } catch (Exception ignore) { }
        display = null;
        enCours = false;
        annoncer(nouvelEtat, message);
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        try { if (display != null && display.isStreaming()) display.stopStream(); } catch (Exception ignore) { }
        display = null; enCours = false;
        super.onDestroy();
    }

    // ---- ConnectChecker (rappels de RootEncoder) ----
    @Override public void onConnectionStarted(String u) { annoncer("connexion", ""); }
    @Override public void onConnectionSuccess() { annoncer("connecte", ""); }
    @Override public void onConnectionFailed(String reason) { arreter("echec", reason); }
    @Override public void onNewBitrate(long bitrate) { }
    @Override public void onDisconnect() { if (enCours) arreter("arrete", ""); }
    @Override public void onAuthError() { arreter("echec", "authentification refusée"); }
    @Override public void onAuthSuccess() { }
}
