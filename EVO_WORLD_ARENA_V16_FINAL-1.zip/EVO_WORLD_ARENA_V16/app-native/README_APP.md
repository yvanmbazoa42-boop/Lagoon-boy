# EVO ARENA — transformer le site en vraie application Android

Je n'ai pas pu fabriquer l'APK moi-même ici (pas d'accès réseau ni d'Android SDK). Voici les 2 chemins prêts à l'emploi.

## Chemin A (recommandé, depuis le téléphone, ~15 min) : PWABuilder → application « TWA »
L'app ouvre ton site dans le vrai moteur Chrome, en plein écran, sans barre d'adresse. **La connexion Google / SMS Firebase continue de fonctionner** et le service worker (cache ultra rapide) aussi.
1. Mets d'abord en ligne la v14b+ (site en HTTPS : `https://evoworl-gamearena.wasmer.app`).
2. Ouvre **pwabuilder.com**, colle l'adresse du site, lance l'analyse (le manifest et le service worker sont déjà prêts).
3. « Package for stores » → **Android** → télécharge le paquet (garde précieusement le fichier de clé de signature et son mot de passe : sans lui, impossible de mettre l'app à jour).
4. Installe l'APK pour tester. Pour le Play Store : compte développeur Google Play (frais unique d'inscription), puis envoi du fichier .aab.
5. Pour retirer la barre d'adresse : copie l'empreinte SHA-256 donnée par PWABuilder dans `assetlinks.template.json`, renomme-le `assetlinks.json` et publie-le sur le site à `/.well-known/assetlinks.json`.

## Chemin B : Capacitor (si tu veux des notifications push natives)
Dossier `app-native/`. Le workflow GitHub construit l'APK automatiquement (sans ordinateur) :
1. Crée un dépôt GitHub, envoie-y le contenu du dossier `app-native/` (le dossier `.github` compris).
2. Onglet **Actions** → « Construire l'application Android » → Run workflow.
3. Télécharge l'artefact `EVO-ARENA-apk` et installe `app-debug.apk`.
⚠️ **Limite importante** : dans une WebView Android, la connexion **Google** de Firebase (fenêtre pop-up) ne fonctionne généralement pas, et le SMS peut demander un réglage reCAPTCHA. Pour garder Google/SMS, il faudra ajouter le plugin `@capacitor-firebase/authentication` (travail à faire). C'est pour ça que le chemin A est le plus sûr pour démarrer.
Les notifications push demandent aussi un projet Firebase Cloud Messaging et une fonction serveur d'envoi (non faits).

## Dans les deux cas
- Firebase › Authentication › Domaines autorisés : ajoute le domaine du site.
- Change `VERSION` dans `sw.js` à chaque mise en ligne.
- Le site se comporte déjà comme une app : plein écran, icônes adaptatives (maskable), page hors-ligne, cache instantané, pas de zoom accidentel.

## v14i — comportement « application native » et permissions
- `evo-native.js` (chargé sur toutes les pages) : demande **notifications, appareil photo, microphone** avec une explication AVANT la fenêtre du système, écran d'autorisations affiché une fois après la connexion, bouton Retour qui ferme d'abord les fenêtres ouvertes, vibrations au toucher, pas de sélection de texte ni de menu « appui long », bandeau hors-ligne, barre d'état et écran de démarrage (Capacitor), partage natif.
- `creer.js` (index, saucial, profil) : studio de création façon TikTok, bouton « + » flottant, lien `saucial.html?create=1`.
- La galerie (photos/vidéos/musiques) n'a PAS besoin de permission : Android utilise son sélecteur système, qui donne accès uniquement aux fichiers choisis.
- Chemin B (APK Capacitor) : le workflow déclare maintenant les permissions dans `AndroidManifest.xml` automatiquement.
- Chemin A (PWABuilder/TWA) : Chrome affiche lui-même ses fenêtres d'autorisation, l'écran d'explication d'EVO ARENA apparaît juste avant.
- Pense à republier `firestore.rules` (nouvelle collection `sons`) et à changer `VERSION` dans `sw.js` (déjà fait : `evo-v14-6`).

## v14k — plugin de diffusion d'écran (EvoScreenCast)
- Dossier `native/` : `EvoScreenCastPlugin.java`, `ScreenCastService.java`, `MainActivity.java`. Le workflow les copie dans le projet Android, ajoute la bibliothèque RootEncoder (JitPack), les permissions FOREGROUND_SERVICE(+MEDIA_PROJECTION), le service et l'ouverture des liens `stream.html`.
- **Ce plugin n'existe que dans le Chemin B (Capacitor)** : l'application TWA de PWABuilder (Chemin A) ne peut pas le contenir.
- Mise en place complète : `../serveur/LISEZMOI_FLUX.md`.
