// ============================================================
// EVO ARENA — Configuration et couche d'accès FIREBASE
//   Authentication : E-mail/Mot de passe, Téléphone (SMS), Google
//   Firestore      : toutes les données
//   Storage        : optionnel (photos HD + vidéos), voir UTILISER_STORAGE
// Colle ci-dessous la config « Web app » de ton projet (voir GUIDE_FIREBASE.md).
// ============================================================
const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyBS7f2LUPyOXfr_X0v2PCh1GhbfR18rDgo',
  authDomain: 'evo-world-arena-7319b.firebaseapp.com',
  projectId: 'evo-world-arena-7319b',
  storageBucket: 'evo-world-arena-7319b.firebasestorage.app',
  messagingSenderId: '491894597755',
  appId: '1:491894597755:web:8fe85f7d5064c1a2f91ade'
};
// false = photos stockées en petit format dans la base (gratuit, sans carte bancaire ; PAS de vidéo).
// true  = Firebase Storage (photos HD + vidéos) — exige l'offre Blaze (carte bancaire, quota gratuit conservé).
const UTILISER_STORAGE = false;

// STOCKAGE DES PHOTOS ET VIDÉOS : Appwrite (bucket evo-media). Le lien du fichier est gardé dans Firestore.
const APPWRITE_ENDPOINT = 'https://fra.cloud.appwrite.io/v1';
const APPWRITE_PROJECT = '6aed40f0002ab209e7f2';
const APPWRITE_BUCKET = '6aed41650034a6b22e51';

const COLLECTIONS = {
  PLAYERS: 'Joueurs', TOURNAMENTS: 'Tournois', MATCHES: 'matchs', CLANS: 'clans', POSTS: 'posts',
  ADMINS: 'admins', MESSAGES: 'messages', CLAN_MESSAGES: 'clan_messages', STATUTS: 'statuts', LIVE_STREAM: 'live_stream'
};
const LIVE_DOC_ID = 'principal';

if (FIREBASE_CONFIG.apiKey === 'COLLE_ICI') {
  document.addEventListener('DOMContentLoaded', function () {
    document.body.insertAdjacentHTML('afterbegin', '<div style="background:#b91c1c;color:#fff;padding:10px;font:14px sans-serif;text-align:center">⚠️ Firebase non configuré : colle ta config dans firebase-config.js (voir GUIDE_FIREBASE.md)</div>');
  });
}
// Démarrage sécurisé : si le SDK Firebase n'a pas pu se charger (réseau coupé, bloqueur de pub, mauvais domaine...),
// EvoDB / EvoAuth restent définis et renvoient un message clair au lieu de faire planter toute la page.
let _initErreur = null, _auth = null, _fs = null;
try {
  if (typeof firebase === 'undefined') throw new Error('SDK Firebase non chargé (vérifie ta connexion ou désactive le bloqueur de pub)');
  firebase.initializeApp(FIREBASE_CONFIG);
  _auth = firebase.auth();
  _fs = firebase.firestore();
} catch (e) {
  _initErreur = e; try { console.error('Firebase init:', e); } catch (e2) {}
  window.__evoInitErreur = String((e && e.message) || e);
  if (!_auth) _auth = { onAuthStateChanged: function (cb) { try { setTimeout(function () { cb(null); }, 0); } catch (e3) {} return function () {}; }, getRedirectResult: function () { return Promise.resolve(null); }, currentUser: null, signOut: function () { return Promise.resolve(); } };
  if (!_fs) _fs = { collection: function () { throw Object.assign(new Error('Firebase indisponible : ' + window.__evoInitErreur), { code: 'unavailable' }); }, settings: function () {}, batch: function () { throw Object.assign(new Error('Firebase indisponible'), { code: 'unavailable' }); }, runTransaction: function () { return Promise.reject(Object.assign(new Error('Firebase indisponible : ' + window.__evoInitErreur), { code: 'unavailable' })); } };
}
try { _auth.languageCode = 'fr'; } catch (e) {}
try { _fs.settings({ ignoreUndefinedProperties: true, experimentalAutoDetectLongPolling: true, merge: true }); } catch (e) {}
try { _fs.enablePersistence({ synchronizeTabs: true }).catch(function () {}); } catch (e) {} // cache IndexedDB : relectures locales + hors-ligne
const _authReady = new Promise(function (ok) { const un = _auth.onAuthStateChanged(function () { un(); ok(); }); });
_auth.getRedirectResult().catch(function () {});
_authReady.then(function () {
  try { if (!_auth.currentUser && _HINT_AU_CHARGEMENT && _HINT_AU_CHARGEMENT.id && sessionStorage.getItem('evo_hint_reload') !== '1') { sessionStorage.setItem('evo_hint_reload', '1'); location.reload(); } } catch (e) {}
});

// Mémoire de session : permet d'afficher le nom du joueur tout de suite, avant la fin de la vérification Firebase
const _CLE_SESSION = 'evo_session';
// --- Cache instantané (affiche tout de suite ce qu'on connaît, puis met à jour en arrière-plan) ---
const _P_C = 'evo_c:', _P_L = 'evo_l:';
const _frais = {}, _servi = {};
// Cache en MÉMOIRE VIVE (RAM) : la copie est gardée sous forme de texte dans la RAM → plus de lecture disque à chaque appel.
// Chaque lecture renvoie une copie neuve (aucun risque qu'une page modifie le cache sans le vouloir).
const _ram = {};
function _lsGet(k) { try { let t = _ram[k]; if (t === undefined) { t = localStorage.getItem(k); if (t === null) return null; _ram[k] = t; } return JSON.parse(t); } catch (e) { return null; } }
const _ecrire = window.requestIdleCallback ? function (f) { requestIdleCallback(f, { timeout: 2000 }); } : function (f) { setTimeout(f, 50); };
function _lsSet(k, v) { try { const t = JSON.stringify(v); if (t.length < 600000) { _ram[k] = t; _ecrire(function () { try { if (_ram[k] === t) localStorage.setItem(k, t); } catch (e) {} }); } } catch (e) {} }
function _viderCaches() { try { Object.keys(localStorage).forEach(function (k) { if (k.indexOf(_P_C) === 0 || k.indexOf(_P_L) === 0) localStorage.removeItem(k); }); } catch (e) {} for (const k in _frais) delete _frais[k]; for (const k in _ram) delete _ram[k]; }
function _invalider(col, id) {
  try { if (id) localStorage.removeItem(_P_C + col + '/' + id); Object.keys(localStorage).forEach(function (k) { if (k.indexOf(_P_L + col + '|') === 0) localStorage.removeItem(k); }); } catch (e) {}
  Object.keys(_frais).forEach(function (k) { if (k.indexOf(_P_C + col + '/') === 1 || k.indexOf(_P_L + col + '|') === 1) delete _frais[k]; });
  Object.keys(_ram).forEach(function (k) { if ((id && k === _P_C + col + '/' + id) || k.indexOf(_P_L + col + '|') === 0) delete _ram[k]; });
}
const _HINT_AU_CHARGEMENT = (function () { try { return JSON.parse(localStorage.getItem('evo_session') || 'null'); } catch (e) { return null; } })();
function _lireSession() { try { return JSON.parse(localStorage.getItem(_CLE_SESSION) || 'null'); } catch (e) { return null; } }
_auth.onAuthStateChanged(function (u) {
  try { if (u) { localStorage.setItem(_CLE_SESSION, JSON.stringify({ id: u.uid, name: u.displayName || '' })); try { sessionStorage.removeItem('evo_hint_reload'); } catch (e2) {} } else { localStorage.removeItem(_CLE_SESSION); _viderCaches(); } } catch (e) {}
});

// ------------------------------------------------------------
// Erreurs : on garde le code Firebase (ex. 'auth/wrong-password', 'not-found') + un message en français
// ------------------------------------------------------------
const MESSAGES_ERREUR = {
  'auth/email-already-in-use': 'Ce numéro ou cet e-mail est déjà inscrit.',
  'auth/wrong-password': 'Identifiant ou mot de passe incorrect.',
  'auth/invalid-credential': 'Identifiant ou mot de passe incorrect.',
  'auth/invalid-login-credentials': 'Identifiant ou mot de passe incorrect.',
  'auth/user-not-found': 'Identifiant ou mot de passe incorrect.',
  'auth/invalid-email': 'Adresse e-mail invalide.',
  'auth/weak-password': 'Mot de passe trop faible (6 caractères minimum).',
  'auth/too-many-requests': 'Trop de tentatives. Attends quelques minutes puis réessaie.',
  'auth/network-request-failed': 'Réseau indisponible.',
  'auth/requires-recent-login': 'Reconnecte-toi puis réessaie.',
  'auth/invalid-verification-code': 'Code incorrect.',
  'auth/code-expired': 'Code expiré : demande-en un nouveau.',
  'auth/quota-exceeded': 'Limite de SMS atteinte pour aujourd\'hui. Réessaie demain ou utilise le mot de passe.',
  'auth/operation-not-allowed': 'Cette méthode de connexion n\'est pas activée dans Firebase (Authentication → Sign-in method).',
  'auth/unauthorized-domain': 'Domaine non autorisé : ajoute-le dans Firebase → Authentication → Settings → Authorized domains.',
  'permission-denied': 'Permission refusée par les règles Firestore (voir GUIDE_FIREBASE.md).',
  'unavailable': 'Réseau indisponible.'
};
function _err(e) {
  if (e && e._evo) return e;
  const code = (e && e.code) || 'unknown';
  const n = new Error(MESSAGES_ERREUR[code] || (e && e.message) || String(e));
  n.code = code; n._evo = true; return n;
}
function _erreur(code, message) { const n = new Error(message); n.code = code; n._evo = true; return n; }

// ------------------------------------------------------------
// Firestore : EvoDB — un document = { id, createdAt, updatedAt, ...champs }
// ------------------------------------------------------------
function _champ(f) { return f === 'id' ? firebase.firestore.FieldPath.documentId() : f === 'createdAt' ? '_createdAt' : f === 'updatedAt' ? '_updatedAt' : f; }
function _doc(s) { const d = s.data() || {}; const o = Object.assign({}, d); o.id = s.id; o.createdAt = d._createdAt || null; o.updatedAt = d._updatedAt || null; delete o._createdAt; delete o._updatedAt; return o; }
function _clean(data) { const o = {}; for (const k in (data || {})) { if (k === 'id' || k === 'createdAt' || k === 'updatedAt' || data[k] === undefined) continue; o[k] = data[k]; } return o; }

// Filtres de recherche
const Q = {
  equal: (f, v) => ({ m: 'equal', f, v }), limit: n => ({ m: 'limit', n }),
  orderAsc: f => ({ m: 'asc', f }), orderDesc: f => ({ m: 'desc', f }), select: () => ({ m: 'select' })
};

// Jamais de « Chargement… » infini : 15 s maximum, et 1 nouvel essai si le réseau a hoqueté
function _delai(fabrique, ms) {
  function une() { return Promise.race([fabrique(), new Promise(function (_, no) { setTimeout(function () { no(_erreur('timeout', 'Réseau trop lent, réessaie.')); }, ms || 15000); })]); }
  return une().catch(function (e) { if (e && (e.code === 'unavailable' || e.code === 'timeout')) return une(); throw e; });
}
const EvoDB = {
  newId: () => _fs.collection('_ids').doc().id,
  async get(col, id) {
    try { const s = await _delai(function () { return _fs.collection(col).doc(id).get(); }); if (!s.exists) throw _erreur('not-found', 'Document introuvable.'); return _doc(s); }
    catch (e) { throw _err(e); }
  },
  async create(col, id, data) {
    try {
      await _authReady;
      const ref = _fs.collection(col).doc(id); const s = await ref.get();
      if (s.exists) throw _erreur('already-exists', 'Ce document existe déjà.');
      const now = new Date().toISOString(); const clean = _clean(data);
      await ref.set(Object.assign({}, clean, { _createdAt: now, _updatedAt: now }));
      _invalider(col, id);
      return Object.assign({}, clean, { id: id, createdAt: now, updatedAt: now });
    } catch (e) { throw _err(e); }
  },
  async update(col, id, data) {
    try {
      await _authReady;
      const ref = _fs.collection(col).doc(id);
      await ref.update(Object.assign({}, _clean(data), { _updatedAt: new Date().toISOString() }));
      _invalider(col, id);
      return _doc(await ref.get());
    } catch (e) { throw _err(e); }
  },
  async remove(col, id) { try { await _authReady; await _fs.collection(col).doc(id).delete(); _invalider(col, id); return {}; } catch (e) { throw _err(e); } },
  async list(col, queries) {
    try {
      let lim = 25, ord = null; const eq = [];
      (queries || []).forEach(q => { if (q.m === 'limit') lim = q.n; else if (q.m === 'asc' || q.m === 'desc') ord = q; else if (q.m === 'equal') eq.push(q); });
      let ref = _fs.collection(col); const tableaux = [];
      eq.forEach(e => { if (Array.isArray(e.v)) tableaux.push(e); else ref = ref.where(_champ(e.f), '==', e.v); });
      const triServeur = ord && !eq.length && !tableaux.length && (ord.f === 'createdAt' || ord.f === 'updatedAt');
      if (triServeur) ref = ref.orderBy(_champ(ord.f), ord.m === 'asc' ? 'asc' : 'desc').limit(lim);
      else ref = ref.limit(ord || tableaux.length ? 2000 : lim);
      let docs = (await _delai(function () { return ref.get(); })).docs.map(_doc);
      tableaux.forEach(e => { docs = docs.filter(d => e.v.indexOf(d[e.f]) >= 0); });
      if (ord && !triServeur) {
        const k = ord.f, s = ord.m === 'asc' ? 1 : -1;
        docs.sort((a, b) => { const x = a[k], y = b[k]; if (x === y || (x == null && y == null)) return 0; if (x == null) return -s; if (y == null) return s; return (x < y ? -1 : 1) * s; });
      }
      docs = docs.slice(0, lim);
      return { total: docs.length, documents: docs };
    } catch (e) { throw _err(e); }
  },
  // Lecture INSTANTANÉE : renvoie tout de suite la copie gardée sur l'appareil (1re lecture de la page),
  // puis vérifie sur le serveur et signale « evo-fresh » seulement si quelque chose a changé.
  async getFast(col, id) {
    const k = _P_C + col + '/' + id, c = _lsGet(k), fk = 'g' + k;
    const f = _frais[fk]; if (f && Date.now() - f.t < 4000) return f.d;
    const reseau = EvoDB.get(col, id).then(function (d) { _lsSet(k, d); _frais[fk] = { t: Date.now(), d: d }; return d; });
    if (c && !_servi[fk]) {
      _servi[fk] = 1;
      reseau.then(function (d) { if (JSON.stringify(d) !== JSON.stringify(c)) window.dispatchEvent(new CustomEvent('evo-fresh', { detail: { col: col, id: id, doc: d } })); })
            .catch(function (e) { if (e && e.code === 'not-found') { try { localStorage.removeItem(k); } catch (x) {} } });
      return c;
    }
    return reseau;
  },
  async listFast(col, queries, champs) {
    const k = _P_L + col + '|' + JSON.stringify(queries || []), c = _lsGet(k), fk = 'l' + k;
    const f = _frais[fk]; if (f && Date.now() - f.t < 4000) return f.d;
    function reduire(r) { return champs ? { total: r.total, documents: r.documents.map(function (d) { const o = {}; champs.forEach(function (x) { if (d[x] !== undefined) o[x] = d[x]; }); return o; }) } : r; }
    const reseau = EvoDB.list(col, queries).then(function (r) { _frais[fk] = { t: Date.now(), d: r }; _lsSet(k, reduire(r)); return r; });
    if (c && !_servi[fk]) {
      _servi[fk] = 1;
      reseau.then(function (r) { if (JSON.stringify(reduire(r)) !== JSON.stringify(c)) window.dispatchEvent(new CustomEvent('evo-fresh', { detail: { col: col } })); }).catch(function () {});
      return c;
    }
    return reseau;
  },
  // Temps réel : écoute le dernier document de la collection (peu de lectures). Retourne la fonction pour arrêter l'écoute.
  listen(col, cb) {
    let premier = true;
    return _fs.collection(col).orderBy('_createdAt', 'desc').limit(1).onSnapshot(function () { if (premier) { premier = false; return; } cb(); }, function () {});
  }
};

// ------------------------------------------------------------
// Authentication : EvoAuth — E-mail/Mot de passe, Google, Téléphone (SMS)
// ------------------------------------------------------------
function numeroInternational(n) {
  let d = String(n || '').replace(/\D/g, '');
  if (d.indexOf('237') === 0 && d.length >= 12) return '+' + d;
  if (d.length === 9) return '+237' + d;
  return d ? '+' + d : '';
}
let _recaptcha = null;
function _zoneRecaptcha() {
  if (!document.getElementById('recaptcha-box')) { const z = document.createElement('div'); z.id = 'recaptcha-box'; document.body.appendChild(z); }
}

const EvoAuth = {
  hint: _lireSession,
  async current() {
    await _authReady; const u = _auth.currentUser;
    if (!u) throw _erreur('auth/no-current-user', 'Aucun utilisateur connecté.');
    return { id: u.uid, name: u.displayName || '', email: u.email || '', phone: u.phoneNumber || '' };
  },
  // Rapide : si la mémoire de session connaît le joueur, on répond tout de suite sans attendre Firebase
  async currentFast() {
    const u = _auth.currentUser;
    if (u) return { id: u.uid, name: u.displayName || '', email: u.email || '', phone: u.phoneNumber || '' };
    const h = _lireSession();
    if (h && h.id) return { id: h.id, name: h.name || '', email: '', phone: '' };
    return EvoAuth.current();
  },
  async signUp(email, pass, name) {
    try { const c = await _auth.createUserWithEmailAndPassword(email, pass); if (name) await c.user.updateProfile({ displayName: name }); return { id: c.user.uid, name: name || '', email }; }
    catch (e) { throw _err(e); }
  },
  async signIn(email, pass) {
    try { const c = await _auth.signInWithEmailAndPassword(email, pass); return { id: c.user.uid }; }
    catch (e) { throw _err(e); }
  },
  async signOut() { try { localStorage.removeItem(_CLE_SESSION); } catch (e) {} _viderCaches(); try { await _auth.signOut(); } catch (e) {} return {}; },
  async changePassword(nouveau, ancien) {
    try {
      const u = _auth.currentUser;
      if (ancien) await u.reauthenticateWithCredential(firebase.auth.EmailAuthProvider.credential(u.email, ancien));
      await u.updatePassword(nouveau);
    } catch (e) { throw _err(e); }
  },
  async resetPassword(email) {
    try { await _auth.sendPasswordResetEmail(email); } catch (e) { throw _err(e); }
  },
  // Google : fenêtre de connexion, ou redirection si le navigateur bloque les fenêtres
  async signInGoogle(retour) {
    const p = new firebase.auth.GoogleAuthProvider();
    p.setCustomParameters({ prompt: 'select_account' });
    try { await _auth.signInWithPopup(p); location.href = retour || location.href; }
    catch (e) {
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment') _auth.signInWithRedirect(p);
      else if (e.code !== 'auth/popup-closed-by-user' && e.code !== 'auth/cancelled-popup-request') throw _err(e);
    }
  },
  // Téléphone : étape 1 — envoie le SMS, retourne l'identifiant de vérification
  async sendSms(numero) {
    const tel = numeroInternational(numero);
    if (!/^\+\d{10,15}$/.test(tel)) throw new Error('Numéro invalide. Exemple : 6XX XX XX XX');
    _zoneRecaptcha();
    if (!_recaptcha) _recaptcha = new firebase.auth.RecaptchaVerifier('recaptcha-box', { size: 'invisible' });
    try { return await new firebase.auth.PhoneAuthProvider().verifyPhoneNumber(tel, _recaptcha); }
    catch (e) { try { _recaptcha.clear(); } catch (x) {} _recaptcha = null; throw _err(e); }
  },
  // Téléphone : étape 2 (connexion) — compte créé si le numéro est nouveau
  async signInSms(verificationId, code) {
    try { await _auth.signInWithCredential(firebase.auth.PhoneAuthProvider.credential(verificationId, String(code).trim())); return true; }
    catch (e) { throw _err(e); }
  },
  // Téléphone : étape 2 (vérification du numéro d'un compte déjà connecté)
  async linkSms(verificationId, code) {
    const cred = firebase.auth.PhoneAuthProvider.credential(verificationId, String(code).trim());
    try { await _auth.currentUser.linkWithCredential(cred); }
    catch (e) {
      if (e.code === 'auth/credential-already-in-use') throw new Error('Ce numéro est déjà vérifié sur un autre compte.');
      if (e.code !== 'auth/provider-already-linked') throw _err(e);
    }
    return true;
  }
};

// Anciens noms utilisés par profil.html (vérification du numéro)
// ---- v16 : appel des Cloud Functions depuis n'importe quelle page (charge le module Functions à la demande) ----
function _chargerScript(src) {
  return new Promise(function (ok, ko) {
    const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = function () { ko(new Error('Chargement impossible : ' + src)); };
    document.head.appendChild(s);
  });
}
const EvoFn = {
  async call(name, data) {
    if (typeof firebase.functions !== 'function') await _chargerScript('https://www.gstatic.com/firebasejs/10.12.2/firebase-functions-compat.js');
    try { const r = await firebase.functions().httpsCallable(name)(data || {}); return r.data; }
    catch (e) { throw new Error((e && e.message) ? String(e.message).replace(/^.*?: /, '') : 'Erreur serveur'); }
  }
};
// Connexion par numéro (comptes avec vrai e-mail) : le serveur vérifie le mot de passe et renvoie un jeton ; l'e-mail n'est jamais révélé.
EvoAuth.signInWithToken = async function (token) {
  try { const c = await _auth.signInWithCustomToken(token); return { id: c.user.uid }; } catch (e) { throw _err(e); }
};
const envoyerCodeSms = n => EvoAuth.sendSms(n);
const confirmerCodeSms = (vid, code) => EvoAuth.linkSms(vid, code);

// ------------------------------------------------------------
// Fichiers : EvoStorage — upload(file) retourne directement l'URL du fichier
// ------------------------------------------------------------
async function _versDataUrl(file) {
  if (!/^image\//i.test(file.type)) throw new Error('Pour publier des vidéos, vérifie APPWRITE_ENDPOINT, APPWRITE_PROJECT et APPWRITE_BUCKET dans firebase-config.js.');
  const bmp = await createImageBitmap(file);
  for (const [cote, q] of [[640, .55], [520, .5], [420, .45], [320, .4]]) {
    const r = Math.min(1, cote / Math.max(bmp.width, bmp.height)), cv = document.createElement('canvas');
    cv.width = Math.round(bmp.width * r); cv.height = Math.round(bmp.height * r);
    cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
    const url = cv.toDataURL('image/jpeg', q);
    if (url.length < 90000) return url;
  }
  throw new Error('Image trop lourde : choisis une autre photo.');
}
async function _versAppwrite(file) {
  const fd = new FormData(); fd.append('fileId', 'unique()'); fd.append('file', file);
  const r = await fetch(APPWRITE_ENDPOINT + '/storage/buckets/' + APPWRITE_BUCKET + '/files', { method: 'POST', headers: { 'X-Appwrite-Project': APPWRITE_PROJECT }, body: fd });
  const j = await r.json().catch(function () { return {}; });
  if (!r.ok || !j.$id) throw new Error('Appwrite : ' + ((j && j.message) || 'envoi impossible'));
  return APPWRITE_ENDPOINT + '/storage/buckets/' + APPWRITE_BUCKET + '/files/' + j.$id + '/view?project=' + APPWRITE_PROJECT;
}
const EvoStorage = {
  async upload(file) {
    try {
      let derniere = null;
      if (APPWRITE_ENDPOINT && APPWRITE_PROJECT && APPWRITE_BUCKET) {
        try { return await _versAppwrite(file); } catch (e) { derniere = e; try { console.warn('Appwrite :', e && e.message); } catch (x) {} }
      }
      if (UTILISER_STORAGE) {
        const id = EvoDB.newId();
        if (!firebase.storage) throw new Error('Firebase Storage non chargé (ajoute firebase-storage-compat.js).');
        const ref = firebase.storage().ref('files/' + id);
        await ref.put(file, { contentType: file.type });
        return await ref.getDownloadURL();
      }
      if (/^image\//i.test(file.type)) return await _versDataUrl(file); // photos : dernier recours, gardées dans la base
      throw derniere || new Error('Envoi de la vidéo impossible pour le moment.');
    } catch (e) { throw e.code ? _err(e) : e; }
  }
};
