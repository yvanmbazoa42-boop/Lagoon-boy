# Diffusion d'écran des joueurs → Régie Live : mise en place (≈ 20 min, une seule fois)

Le schéma : **téléphone du joueur → Cloudflare Stream → lien HLS (.m3u8) → Régie Live**.
Cloudflare Stream est un service payant à l'usage (vérifie la grille tarifaire avant d'activer). Le site ne contient jamais ta clé Cloudflare : elle reste dans un petit Worker.

## 1. Cloudflare Stream
1. Crée un compte sur cloudflare.com, puis active **Stream** (menu « Stream »).
2. Note ton **Account ID** (page d'accueil du compte, colonne de droite).
3. Note ton **Customer code** : sur la page Stream, une adresse du type `customer-XXXXXXXX.cloudflarestream.com` ; garde la partie `XXXXXXXX`.
4. **Mon profil › Jetons API › Créer un jeton › Créer un jeton personnalisé** : permission **Compte › Stream › Modifier**. Copie le jeton (il ne s'affiche qu'une fois).

## 2. Le Worker (aucun outil à installer)
1. Cloudflare › **Workers & Pages › Créer › Créer un Worker** (nom : `evo-flux`) › Déployer, puis **Modifier le code**.
2. Efface le code d'exemple, colle tout le contenu de `serveur/worker-flux.js`, **Déployer**.
3. **Paramètres › Variables et secrets** : ajoute
   - `CF_API_TOKEN` (type Secret) = le jeton de l'étape 1.4
   - `ADMIN_SECRET` (type Secret) = un long mot secret inventé (20 caractères ou plus)
   - `CF_ACCOUNT_ID` = ton Account ID
   - `CF_CUSTOMER_CODE` = ton Customer code
4. Copie l'adresse du Worker (`https://evo-flux.TON-COMPTE.workers.dev`).

## 3. Le site
1. Publie le nouveau site (zip v14k) et **republie `firestore.rules`** (Firebase › Firestore › Règles › Publier).
2. Admin › onglet **📺 FLUX › ⚙️ CONFIGURATION** : colle l'adresse du Worker + le mot secret › **ENREGISTRER**, puis **TESTER** (« Worker OK »).

## 4. L'application Android (le plugin est dedans)
1. Mets le contenu de `app-native/` dans ton dépôt GitHub (dossier `native/` compris), lance **Actions › Construire l'application Android**.
2. Télécharge `app-debug.apk`, installe-le sur les téléphones. **Il faut cette version Capacitor** : le chemin PWABuilder/TWA ne peut pas contenir le plugin.
3. Dans `stream.html`, remplis `APK_URL` avec le lien de téléchargement de l'APK (par exemple celui d'une release GitHub) : le bouton « Télécharger l'application » apparaît pour les joueurs qui ne l'ont pas.

## Utilisation
1. Admin › ⚔️ CRÉER MATCH : le message WhatsApp de chaque joueur contient maintenant « 📺 Diffuse ton écran » + son lien personnel.
2. Le joueur ouvre le lien → l'application s'ouvre → il accepte les conditions → Android demande « Commencer à enregistrer ou à caster ? » → il touche **Commencer maintenant** → c'est en direct.
3. Admin › **📺 FLUX** : badge rouge « EN DIRECT », **📋 Copier le lien Régie Live** (lien `.m3u8`), **▶ Aperçu**, **🎯 Publier sur la page live** du match.

## Si ça ne marche pas
- « Mot secret incorrect » : le mot collé dans l'onglet ≠ `ADMIN_SECRET` du Worker.
- Aucun lien dans le message : l'onglet FLUX n'est pas configuré (un toast le signale) ; le match est quand même créé.
- Le joueur voit « Ce lien n'est pas pour ton compte » : il est connecté avec un autre compte que celui du match.
- Pas d'image dans l'aperçu : le joueur n'a pas encore commencé, ou HLS prend 5 à 15 s de retard (normal).
- Le build GitHub échoue : copie-moi le message d'erreur de l'étape « Construire l'APK » (voir NOUVEAUTES_v14k.md).
