// EVO ARENA — mini-serveur Cloudflare Worker : crée / supprime un « live input » Cloudflare Stream pour chaque joueur.
// Pourquoi : la clé API Cloudflare ne doit JAMAIS être dans le site. Seul ce Worker la connaît ; l'onglet admin 📺 FLUX l'appelle avec un mot secret.
// Variables à définir dans le Worker (Settings › Variables, en « Secret » pour les 2 premières) :
//   CF_API_TOKEN      jeton API Cloudflare avec la permission « Stream : Edit »
//   ADMIN_SECRET      un long mot secret de ton choix (le même sera collé dans l'onglet admin)
//   CF_ACCOUNT_ID     identifiant de ton compte Cloudflare
//   CF_CUSTOMER_CODE  « customer code » Stream (celui de https://customer-XXXX.cloudflarestream.com)
export default {
  async fetch(req, env) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    };
    const rep = (obj, status) => new Response(JSON.stringify(obj), { status: status || 200, headers: Object.assign({ 'Content-Type': 'application/json' }, cors) });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (req.method !== 'POST') return rep({ ok: false, erreur: 'POST uniquement' }, 405);
    let b = {};
    try { b = await req.json(); } catch (e) { return rep({ ok: false, erreur: 'JSON invalide' }, 400); }
    if (!env.ADMIN_SECRET || !egal(String(b.secret || ''), String(env.ADMIN_SECRET))) return rep({ ok: false, erreur: 'Mot secret incorrect' }, 401);
    if (!env.CF_API_TOKEN || !env.CF_ACCOUNT_ID || !env.CF_CUSTOMER_CODE) return rep({ ok: false, erreur: 'Worker mal configuré (variables manquantes)' }, 500);

    const api = 'https://api.cloudflare.com/client/v4/accounts/' + env.CF_ACCOUNT_ID + '/stream/live_inputs';
    const h = { Authorization: 'Bearer ' + env.CF_API_TOKEN, 'Content-Type': 'application/json' };
    const chemin = new URL(req.url).pathname.replace(/\/+$/, '');

    if (chemin === '/creer') {
      const r = await fetch(api, { method: 'POST', headers: h, body: JSON.stringify({ meta: { name: String(b.nom || 'EVO ARENA').slice(0, 80) }, recording: { mode: 'off' } }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.success || !j.result || !j.result.rtmps) return rep({ ok: false, erreur: 'Cloudflare : ' + (((j.errors || [])[0] || {}).message || r.status) }, 502);
      const x = j.result;
      return rep({ ok: true, uid: x.uid, ingest: x.rtmps.url, cle: x.rtmps.streamKey, hls: 'https://customer-' + env.CF_CUSTOMER_CODE + '.cloudflarestream.com/' + x.uid + '/manifest/video.m3u8' });
    }
    if (chemin === '/supprimer') {
      const uid = String(b.uid || '').replace(/[^a-zA-Z0-9]/g, '');
      if (!uid) return rep({ ok: false, erreur: 'uid manquant' }, 400);
      const r = await fetch(api + '/' + uid, { method: 'DELETE', headers: h });
      return rep({ ok: r.ok }, r.ok ? 200 : 502);
    }
    return rep({ ok: false, erreur: 'Route inconnue' }, 404);
  }
};
// comparaison à durée constante (évite de deviner le mot secret par le temps de réponse)
function egal(a, b) {
  let d = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return d === 0;
}
