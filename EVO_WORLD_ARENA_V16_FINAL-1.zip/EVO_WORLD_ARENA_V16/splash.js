// ============================================================
// SPLASH CINÉMATIQUE 1,8 s + RENDU "APPLICATION" — EVO WORLD ARENA
// Chargé sur les 8 pages. Le logo ne passe qu'UNE fois par ouverture de l'app
// (pas à chaque changement de page). Durée : DUREE_MS.
// ============================================================
(function () {
  var DUREE_MS = 5000;
  var NOM = 'EVO', SOUS_TITRE = 'WORLD GAMER', SLOGAN = 'JOUE. GAGNE. ENCAISSE.';

  // ---------- Rendu "app" : pas de surbrillance au toucher, pas de pull-to-refresh, pas de zoom accidentel ----------
  var app = document.createElement('style');
  app.textContent =
    'html{-webkit-tap-highlight-color:transparent;overscroll-behavior-y:none;-webkit-text-size-adjust:100%}' +
    'body{overscroll-behavior-y:none;-webkit-touch-callout:none}' +
    'button,a,[onclick],.btn,.tab-auth,nav,[class*="nav"],[class*="tab"]{-webkit-user-select:none;user-select:none;touch-action:manipulation}' +
    'input,textarea,select{-webkit-user-select:text;user-select:text;font-size:max(16px,1em)}' +
    'img{-webkit-user-drag:none}' +
    'html.evo-splashing,html.evo-splashing body{overflow:hidden!important}';
  (document.head || document.documentElement).appendChild(app);

  // Splash coupé pour la vitesse (mettre true pour le réactiver)
  var SPLASH_ACTIF = false;
  if (!SPLASH_ACTIF) return;

  // ---------- Une seule fois par ouverture de l'app ----------
  try { if (sessionStorage.getItem('evo_splash') === '1') return; sessionStorage.setItem('evo_splash', '1'); } catch (e) {}

  var css = document.createElement('style');
  css.textContent =
    '#evoSplash{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;overflow:hidden;' +
      'background:radial-gradient(ellipse at 50% 42%,rgba(var(--c2-rgb,124,58,237),.30) 0%,rgba(var(--bg-rgb,5,5,16),1) 62%),var(--bg,#050510);' +
      'animation:spOut .6s ease ' + (DUREE_MS - 600) + 'ms forwards}' +
    '@keyframes spOut{to{opacity:0;transform:scale(1.06);visibility:hidden;pointer-events:none}}' +
    '#evoSplash .sp-center{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;z-index:2}' +
    '#evoSplash .sp-bolt{width:34vw;max-width:150px;height:auto;overflow:visible}' +
    '#evoSplash .sp-stroke{fill:none;stroke:var(--c1,#00ff88);stroke-width:3.2;stroke-linejoin:round;stroke-linecap:round;stroke-dasharray:1;stroke-dashoffset:1;animation:spDraw 1.3s cubic-bezier(.6,0,.2,1) .35s forwards}' +
    '#evoSplash .sp-fill{opacity:0;animation:spFill .5s ease 1.5s forwards,spGlow 1.4s ease-in-out 2s infinite alternate}' +
    '@keyframes spDraw{to{stroke-dashoffset:0}}' +
    '@keyframes spFill{to{opacity:1}}' +
    '@keyframes spGlow{from{filter:drop-shadow(0 0 6px var(--c1,#00ff88))}to{filter:drop-shadow(0 0 22px var(--c2,#7c3aed))}}' +
    '#evoSplash .sp-title{margin-top:14px;font-size:clamp(2.6rem,15vw,4.4rem);font-weight:900;line-height:1;opacity:0;letter-spacing:1em;filter:blur(10px);' +
      'background:linear-gradient(135deg,var(--c1,#00ff88),var(--c2,#7c3aed));-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;' +
      'animation:spTitle 1.1s cubic-bezier(.2,.8,.2,1) 2.2s forwards}' +
    '@keyframes spTitle{to{opacity:1;letter-spacing:.14em;filter:blur(0)}}' +
    '#evoSplash .sp-sub{margin-top:8px;font-size:clamp(.8rem,3.6vw,1.05rem);font-weight:700;letter-spacing:.55em;color:#e0f2fe;opacity:0;transform:translateY(10px);animation:spUp .8s ease 3.2s forwards}' +
    '#evoSplash .sp-tag{margin-top:22px;font-size:.7rem;font-weight:800;letter-spacing:.3em;color:var(--c1,#00ff88);opacity:0;animation:spUp .8s ease 4.2s forwards}' +
    '@keyframes spUp{to{opacity:1;transform:none}}' +
    '#evoSplash .sp-ring{position:absolute;left:50%;top:50%;width:120px;height:120px;margin:-60px 0 0 -60px;border-radius:50%;border:2px solid var(--c1,#00ff88);opacity:0;z-index:1;animation:spRing 1.3s ease-out 1.5s forwards}' +
    '#evoSplash .sp-ring.r2{border-color:var(--c2,#7c3aed);animation-delay:1.75s}' +
    '@keyframes spRing{0%{opacity:.9;transform:scale(.2)}100%{opacity:0;transform:scale(5)}}' +
    '#evoSplash .sp-flash{position:absolute;inset:0;background:#fff;opacity:0;z-index:3;pointer-events:none;animation:spFlash .45s ease-out 1.5s}' +
    '@keyframes spFlash{0%{opacity:.55}100%{opacity:0}}' +
    '#evoSplash .sp-dot{position:absolute;bottom:-10px;width:4px;height:4px;border-radius:50%;background:var(--c1,#00ff88);box-shadow:0 0 8px var(--c1,#00ff88);opacity:0;animation:spDot 4s linear infinite}' +
    '@keyframes spDot{0%{opacity:0;transform:translateY(0)}15%{opacity:.9}100%{opacity:0;transform:translateY(-105vh)}}' +
    '#evoSplash .sp-bar{position:absolute;left:14%;right:14%;bottom:max(44px,8vh);height:3px;border-radius:3px;background:rgba(255,255,255,.1);overflow:hidden;z-index:2}' +
    '#evoSplash .sp-bar i{display:block;height:100%;width:0;border-radius:3px;background:linear-gradient(90deg,var(--c1,#00ff88),var(--c2,#7c3aed));box-shadow:0 0 10px var(--c1,#00ff88);animation:spBar ' + (DUREE_MS - 900) + 'ms linear .4s forwards}' +
    '@keyframes spBar{to{width:100%}}';
  (document.head || document.documentElement).appendChild(css);

  var dots = '';
  for (var i = 0; i < 22; i++) {
    dots += '<span class="sp-dot" style="left:' + Math.round(Math.random() * 100) + '%;animation-delay:' + (Math.random() * 4).toFixed(2) + 's;animation-duration:' + (3 + Math.random() * 3).toFixed(2) + 's"></span>';
  }
  var bolt = 'M58 2 L12 66 L46 66 L38 118 L90 48 L54 48 Z';
  var el = document.createElement('div');
  el.id = 'evoSplash';
  el.innerHTML = dots +
    '<div class="sp-ring"></div><div class="sp-ring r2"></div>' +
    '<div class="sp-center">' +
      '<svg class="sp-bolt" viewBox="0 0 100 120" aria-hidden="true">' +
        '<defs><linearGradient id="spG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--c1,#00ff88)"/><stop offset="1" style="stop-color:var(--c2,#7c3aed)"/></linearGradient></defs>' +
        '<path class="sp-fill" d="' + bolt + '" fill="url(#spG)"/>' +
        '<path class="sp-stroke" pathLength="1" d="' + bolt + '"/>' +
      '</svg>' +
      '<div class="sp-title">' + NOM + '</div>' +
      '<div class="sp-sub">' + SOUS_TITRE + '</div>' +
      '<div class="sp-tag">' + SLOGAN + '</div>' +
    '</div>' +
    '<div class="sp-flash"></div>' +
    '<div class="sp-bar"><i></i></div>';

  var root = document.documentElement;
  root.classList.add('evo-splashing');
  root.appendChild(el);
  setTimeout(function () {
    root.classList.remove('evo-splashing');
    if (el.parentNode) el.parentNode.removeChild(el);
  }, DUREE_MS + 100);
})();
